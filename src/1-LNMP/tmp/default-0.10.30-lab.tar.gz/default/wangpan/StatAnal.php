<?php
	//统计分析面板
   define('APP_NAME','StatAnal');
   define('APP_PATH','./StatAnal/');
   define('APP_DEBUG',TRUE);
   include './ThinkPHP/ThinkPHP.php';
   
?>