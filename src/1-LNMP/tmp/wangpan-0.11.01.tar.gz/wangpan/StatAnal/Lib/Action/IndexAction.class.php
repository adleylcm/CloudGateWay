<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends Action {
    public function index(){

        //容量统计
        //实例化analyse数据表，find函数，返回id=1的项
    	$data = M('analyse')->find('1');
        //获取数据库中相应项的具体信息
	    $this->cloudUsed = $data['cloudUsed'];
	    $this->cloudTotal = $data['cloudTotal'];
	    $this->localUsed = $data['localUsed'];
	    $this->localTotal = $data['localTotal'];
        
        $log = M('translog')->select();
        $this->assign('log',$log);
        
        //转存频度统计
      //  $this->assign('frequency',M('frequency')->select());
        // $frqModle = M('frequency');
        // $frqData = $frqModle->query('select * from frequency order by date desc limit 0,14');
         $frqModle = M('frequency');
        $this->frqData = M('frequency')->query('select * from frequency order by date desc limit 0,14');
    
        //显示模板
		$this->display();


    }
}
?>