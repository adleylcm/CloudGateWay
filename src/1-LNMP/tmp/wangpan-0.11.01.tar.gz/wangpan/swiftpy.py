import signal
import socket
import os
from os import environ, listdir, makedirs, utime, _exit as os_exit
from os.path import basename, dirname, getmtime, getsize, isdir, join
from Queue import Empty, Queue
from random import shuffle
# from sys import argv, exc_info, exit, stderr, stdout
from threading import current_thread, enumerate as threading_enumerate, Thread
from time import sleep, time
import sys
sys.path.append("/root/python-swiftclient/swiftclient/")
import client
authurl='http://192.168.3.9:5000/v2.0/'
user='swift'
key='111111'
auth = client.Connection(authurl, user, key, tenant_name='service', auth_version="2")

def upone(uppath):
        uploadpath = uppath
        auth.put_object('swift', uploadpath, open(uploadpath, 'rb'))

def dwone(dwpath):
        download = dwpath
        dirpath = dirname(download)
        if dirpath != ".":
                if not os.path.exists(dirpath):
                        os.makedirs(dirpath)
        start_time = time()
        headers, body = auth.get_object('swift', download)
        fp = open(download, 'wb')
        for chunk in body:
                fp.write(chunk)
        fp.close()
        finish_time = time()
        read_length = 0
        for chunk in body:
                read_length += len(chunk)
        time_str = 'total %.3fs, %.3fs MB/s' % (finish_time - start_time, float(read_length) / (finish_time - start_time) / 1000000)
        result = '%s [%s]' % (download, time_str)
        print result

def dele(obpath):
        objectpath = obpath;
        auth.delete_object('swift', objectpath)


##upone('/root/swiftclienttest/ydtest03.txt')
##dele('/root/swiftclienttest/ydtest03.txt')