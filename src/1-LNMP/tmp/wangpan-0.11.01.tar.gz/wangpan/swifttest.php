<?php
	//统计分析面板
   define('APP_NAME','swiftTest');
   define('APP_PATH','./swiftTest/');
   define('APP_DEBUG',TRUE);
   include './ThinkPHP/ThinkPHP.php';
   
?>