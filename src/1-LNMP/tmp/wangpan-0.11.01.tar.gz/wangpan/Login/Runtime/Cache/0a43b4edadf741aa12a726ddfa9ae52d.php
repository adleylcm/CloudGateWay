<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html xml:lang="en" lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>登录 - 云存储网关</title>
	<link rel="shortcut icon" href="./Public/Images/logo.ico" />

	<link href="./Public/login.css" rel="stylesheet" type="text/css">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

</head>
<body id="splash">
    <div class="container">
      <div class="row large-rounded">
        <div id="" class="login ">
  			<div class="modal-header">
    			<h3>登录</h3>
  			</div>
  
  			<form id="" autocomplete="on" class="" action="<?php echo U('Index/loginNext');?>" method="POST">
	  			<input name="csrfmiddlewaretoken" value="IOcI5V90SivPkwbUKQqilWzAvVSGRi0m" type="hidden">
	    		<div class="modal-body clearfix">
		  			<fieldset>
		     			<input id="id_region" name="region" value="http://127.0.0.1:5000/v2.0" type="hidden">
		  				<div class="control-group form-field clearfix ">
		    				<label for="id_username">用户名</label>
		    				<span class="help-block"></span>
		    				<div class="input">
		      					<input id="id_username" name="username" type="text">
		    				</div>
		  				</div>
			  			<div class="control-group form-field clearfix ">
			    			<label for="id_password">密码</label>
			    			<span class="help-block"></span>
			    			<div class="input">
			      				<input id="id_password" name="password" type="password">
			    			</div>
			  			</div>
		  			</fieldset>
	    		</div>
	    		<div class="modal-footer">
	  				<button type="submit" class="btn btn-primary pull-right">登入</button>
				</div>
  			</form>
		</div>
      </div>
    </div>
</body>

</html>