<?php

class IndexAction extends Action {
    public function index(){

	if(!empty($_GET['target'])){
		system("/home/swiftclientapi/swiftapi -p ".$_GET['fpath']);//此处插入操作. zl
		//system("sleep 5 > /home/wwwlogs/swiftapi.log");
		//$this->target=$_GET['target'];
	}
    
    $this->assign('policy',M('policy')->select());
    
	$IDGET = $_GET['fid'];//获取所点击文件夹的id，搜索fpid=$_GET['fid']的文件以显示
	$map['fpid'] = $IDGET;//查询条件语句，
	if (!$IDGET){         //判断是否根目录
		$this->assign('fileinfo',M('fileinfo')->where('fpid=1')->select())->display();//连贯操作，M函数，把数据库中相应表实例化为一个类:http://doc.thinkphp.cn/manual/continuous_operation.html,http://www.thinkphp.cn/simple/functions_m.html
	}else{
		$this->assign('fileinfo',M('fileinfo')->where($map)->select())->display();
	}
}

//修改转存策略函数
    public function confModify(){
        $policy = M('policy');  //实例化policy表

//读取表单提交的数据
        $data['fileSizeth'] = $_POST['pconfsize'];
        $data['expires'] = $_POST['pconexpires'];  
        $data['fileType'] = $_POST['pconftype'];
        $data['freq'] = $_POST['pconfreq'];
        
        $map['id'] = array('eq','0');       //数据查询语句，固定格式
        $policy->where($map)->data($data)->save();  //更新数据库相应项
        $this->success('转存策略修改成功',U('Index/index'));
//        print($data['fileSizeth']);
//        die;
    }
//	public function f1(){
//		echo xx;
//		exec("ls /tmp");
//	}
}
?>