<?php
	//定义项目名称
   define('APP_NAME','APP');
   //定义项目路径，必须以“/”结束
   define('APP_PATH','./APP/');
   //开启调试模式
   define('APP_DEBUG',TRUE);
   //加载框架入口文件
   include './ThinkPHP/ThinkPHP.php';
   
?>