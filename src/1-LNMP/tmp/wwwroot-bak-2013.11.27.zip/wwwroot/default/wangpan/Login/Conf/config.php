<?php
return array(
	//'配置项'=>'配置值'
    'URL_HTML_SUFFIX'=>'',
    'URL_MODEL'=>0,//设置URK模式为普通模式
);
?>