<?php
	//登陆面板
   define('APP_NAME','Login');
   define('APP_PATH','./Login/');
   define('APP_DEBUG',TRUE);
   include './ThinkPHP/ThinkPHP.php';
   
?>