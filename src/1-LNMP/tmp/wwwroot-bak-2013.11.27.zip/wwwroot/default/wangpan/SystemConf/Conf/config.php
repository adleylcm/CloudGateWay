<?php
return array(
	//'配置项'=>'配置值'
    'URL_HTML_SUFFIX'=>'',
    'URL_MODEL'=>0,//设置URL模式为普通模式
    //注意配置参数名称不要拼写错误
    //数据库配置信息
    'DB_TYPE' => 'mysql',
    'DB_HOST' => '127.0.0.1',
    'DB_USER' => 'root',
    'DB_PWD' => '111111',
    'DB_PORT' =>3306,
    'DB_NAME' => 'gateway',
    'DB_PREFIX' => ''
);
?>