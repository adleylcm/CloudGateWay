<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends Action {
    public function index(){
      $this->assign('policy',M('policy')->select());  //读取policy表对象
      $this->display();                               //显示页面模板
        }
        
//  系统配置修改函数        
    public function confModify(){
        $policy = M('policy');  //实例化policy表

//读取表单提交的数据
        $data['fileSizeth'] = $_POST['pconfsize'];
        $data['expires'] = $_POST['pconexpires'];  
        $data['fileType'] = $_POST['pconftype'];
        $data['freq'] = $_POST['pconfreq'];
        
        $map['id'] = array('eq','0');       //数据查询语句，固定格式
        $policy->where($map)->data($data)->save();  //更新数据库相应项
        $this->success('转存策略修改成功',U('Index/index'));
//        print($data['fileSizeth']);
//        die;
    }
    public function confModify2(){
        $policy = M('policy');  //实例化policy表
        $data['ipaddr'] = $_POST['cloudadd'];
        $data['user'] = $_POST['clouduser'];
        $data['passwd'] = $_POST['cloudpswd'];
        $map['id'] = array('eq','0'); 
        $policy->where($map)->data($data)->save();  //更新数据库相应项
        $this->success('云存储账号修改成功',U('Index/index'));
    }
    public function confModify3(){
        $this->success();
    }
}
?>