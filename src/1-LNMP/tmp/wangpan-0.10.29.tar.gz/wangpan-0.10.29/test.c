#include <stdio.h>

int main(){
	printf("C test\n");
	return 0;
}
