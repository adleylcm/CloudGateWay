<?php
	//系统配置
   define('APP_NAME','SystemConf');
   define('APP_PATH','./SystemConf/');
   define('APP_DEBUG',TRUE);
//   define('NO_CACHE_RUNTIME',TRUE);
   include './ThinkPHP/ThinkPHP.php';
   
?>