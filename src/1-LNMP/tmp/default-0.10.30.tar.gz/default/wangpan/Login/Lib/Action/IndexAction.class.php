<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends Action {
    public function index(){
		$this->name = 'login'; // 进行模板变量赋值
        $this->display();
    }
    public function loginNext(){
        //print('success');
        $this->redirect(R('APP://Index/index'));
       // U('Index/index');
    }
}