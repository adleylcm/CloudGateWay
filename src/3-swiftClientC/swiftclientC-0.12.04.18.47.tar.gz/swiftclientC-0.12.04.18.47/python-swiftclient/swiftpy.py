import signal
import socket
import os
# import MySQLdb
from os import environ, listdir, makedirs, utime, _exit as os_exit
from os.path import basename, dirname, getmtime, getsize, isdir, join
from Queue import Empty, Queue
from random import shuffle
# from sys import argv, exc_info, exit, stderr, stdout
from threading import current_thread, enumerate as threading_enumerate, Thread
from time import sleep, time
import sys
sys.path.append("/home/gateway/swiftclientC/python-swiftclient/swiftclient/")
import client
#MySQL connection
# conn = MySQLdb.connect(host='localhost', user='root',passwd='111111',db='gateway')  
# cursor = conn.cursor()  
# count = cursor.execute('select * from policy')   
# result = cursor.fetchone()  

# authurl=result[11]
# user=result[12]
# key=result[13]
authurl='http://192.168.3.9:5000/v2.0/'
user = "swift"
key = "111111"
auth = client.Connection(authurl, user, key, tenant_name='service', auth_version="2")

# #print authurl,   user, key
# cursor.close() 

def upone(uppath):
        uploadpath = uppath
        auth.put_object('swift', uploadpath, open(uploadpath, 'rb'))

def dwone(dwpath):
        download = dwpath
        dirpath = dirname(download)
        if dirpath != ".":
                if not os.path.exists(dirpath):
                        os.makedirs(dirpath)
        headers, body = auth.get_object('swift', download, resp_chunk_size=65536)
        fp = open(download, 'wb')
        for chunk in body:
                fp.write(chunk)
        fp.close()

def dele(obpath):
        objectpath = obpath;
        auth.delete_object('swift', objectpath)