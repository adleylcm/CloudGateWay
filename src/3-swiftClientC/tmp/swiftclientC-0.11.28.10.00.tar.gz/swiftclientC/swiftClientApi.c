/*
 * swiftclientC.c
 *
 *  Created on: 2013年11月5日
 *      Author: QL,YD
 */

#include <python2.7/Python.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "swiftClientApi.h"

int upload(char* uppath){
    //printf("start upload\n");

    Py_Initialize();
    if ( !Py_IsInitialized() )
        return -1;
    //添加swiftpy.py的目录
	PyObject* ptest;
    PyRun_SimpleString("import sys");
    PyRun_SimpleString(SYSPATH);
    PyObject* pModule;
    PyObject* pFunc;
    PyObject* pDict;
    PyObject* args;
    Py_ssize_t s;
    char *pathname = uppath;
    //printf("22232\n" );
	pModule = PyImport_ImportModule("swiftpy");
	if ( !pModule ){
        printf("can't find swiftpy.py\n");
        //getchar();
        return -1;
    }

    //将module中的方法以字典形式读入
    pDict = PyModule_GetDict(pModule);
    if ( !pDict ){
        return -1;
    }

    //在方法字典中通过名字获取对应的方法,找出函数名为uploadobject的函数
    pFunc = PyDict_GetItemString(pDict, "upone");
    if ( !pFunc || !PyCallable_Check(pFunc) ){
        printf("can't find function [upone]");
        //getchar();
        return -1;
    }

    args = PyTuple_New(1);
    //将pathname赋给args
    PyTuple_SetItem(args,0,Py_BuildValue("s",pathname));
 	PyObject_CallObject(pFunc, args);
   // PyRun_SimpleString("print \"Finish upload\"\n");
    Py_Finalize();
    return 0;
}


int download(char* dwpath){
    //printf("start download\n");

    Py_Initialize();
    if ( !Py_IsInitialized() )
        return -1;
    //添加swiftpy.py的目录
    PyRun_SimpleString("import sys");
    PyRun_SimpleString(SYSPATH);
    PyObject* pModule;
    PyObject* pFunc;
    PyObject* pDict;
    PyObject* args;
    Py_ssize_t s;
    char *pathname = dwpath;

    pModule = PyImport_ImportModule("swiftpy");
    if ( !pModule ){
        printf("can't find swiftpy.py");
        //getchar();
        return -1;
    }

    //将module中的方法以字典形式读入
    pDict = PyModule_GetDict(pModule);
    if ( !pDict ){
        return -1;
    }

    //在方法字典中通过名字获取对应的方法,找出函数名为uploadobject的函数
    pFunc = PyDict_GetItemString(pDict, "dwone");
    if ( !pFunc || !PyCallable_Check(pFunc) ){
        printf("can't find function [dwone]");
        getchar();
        return -1;
    }

    args = PyTuple_New(1);
    //将pathname赋给args
    PyTuple_SetItem(args,0,Py_BuildValue("s",pathname));
    PyObject_CallObject(pFunc, args);
    //PyRun_SimpleString("print \"Finish download\"\n");
    Py_Finalize();
    return 0;
}

int delete(char* obpath){
    //printf("start delete\n");

    Py_Initialize();
    if ( !Py_IsInitialized() )
        return -1;
    //添加swiftpy.py的目录
    PyRun_SimpleString("import sys");
    PyRun_SimpleString(SYSPATH);
    PyObject* pModule;
    PyObject* pFunc;
    PyObject* pDict;
    PyObject* args;
    Py_ssize_t s;
    char *pathname = obpath;

    pModule = PyImport_ImportModule("swiftpy");
    if ( !pModule ){
        printf("can't find swiftpy.py");
        getchar();
        return -1;
    }

    //将module中的方法以字典形式读入
    pDict = PyModule_GetDict(pModule);
    if ( !pDict ){
        return -1;
    }

    //在方法字典中通过名字获取对应的方法,找出函数名为uploadobject的函数
    pFunc = PyDict_GetItemString(pDict, "dele");
    if ( !pFunc || !PyCallable_Check(pFunc) ){
        printf("can't find function [dele]");
        getchar();
        return -1;
    }

    args = PyTuple_New(1);
    //将pathname赋给args
    PyTuple_SetItem(args,0,Py_BuildValue("s",pathname));
    PyObject_CallObject(pFunc, args);
    //PyRun_SimpleString("print \"Finish delete\"\n");
    Py_Finalize();
    return 0;
}

