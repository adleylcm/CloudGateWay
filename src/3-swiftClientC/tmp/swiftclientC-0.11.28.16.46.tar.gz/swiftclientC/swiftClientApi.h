/*
 * swiftClientC.h
 *
 *  Created on: 2013年11月5日
 *      Author: QL
 */

#ifndef SWIFTCLIENTC_H_
#define SWIFTCLIENTC_H_

#define SYSPATH "sys.path.append('/home/gateway/swiftclientC/python-swiftclient')"

#endif /* SWIFTCLIENTC_H_ */
