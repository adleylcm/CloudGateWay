/*
 * swiftapi, 2013-10-30, by ZYD,QL
 * 功能: 上传下载
 */

#include <stdio.h>
#include <stdlib.h>
#include <python2.7/Python.h>
#include <ctype.h>
#include <unistd.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <mysql/mysql.h>
#include <sys/time.h>
#include "swiftClientApi.h"
#include "mysqlData.h"

#define ERR_INPUT -1


void usage(char *api){
	printf("Copyright (C)2013, by ZYD, QL.\n\n"
	       "Usage: %s -p path [-l] [-k] [-a]\n"
	       "       -p set uploading/downloading file's path\n"
	       "       -l only download and set status to 'l'\n"
	       "       -k only download and set status to 'k'\n"
	       "       -a used by autoTrans\n",
			api);
	
	exit(ERR_INPUT);
}

int main(int argc, char **argv){
	char *path = NULL;//文件绝对路径
	
	int downloadLockFlag = 0;
	int downloadLocalFlag = 0;
	int autoTrans =0;
	mysqlMetadataStru mysqlMetadata;
	mysqlFrequencyStru mysqlFrequency;
	mysqlTranslogStru mysqlTranslog;
	mysqlAnalyseStru mysqlAnalyse;
	struct timeval startTime, endTime;

	//初始化mysqlMetadata
	mysqlMetadataStruIni(&mysqlMetadata);
	//初始化mysqlFrequency
	mysqlFrequencyStruIni(&mysqlFrequency);

	mysqlAnalyseStruIni(&mysqlAnalyse);

	if (argc == 1)
		usage(argv[0]);

	int opt = 0;
	while ((opt = getopt (argc, argv, "p:klha")) != -1) {
	   switch (opt) {
			case 'p':
				path = optarg;
				break;
			case 'k':
				downloadLockFlag = 1;
				break;
			case 'l':
				downloadLocalFlag = 1;
				break;
			case 'a':
				autoTrans = 1;
				break;
			case 'h':
				usage(argv[0]);
				break;
			case '?':
				if (optopt == 'p')
					fprintf(stderr, "Option -%c requires an argument\n", optopt);
				//功能：判断字符c是否为可打印字符（含空格）说明：当c为可打印字符（0x20-0x7e）时，返回非零值，否则返回零。
				else if (isprint(optopt))
					fprintf(stderr, "Unknown option '-%c'\n", optopt);
				else
					fprintf(stderr,"Unknown option character \n",optopt);
				usage(argv[0]);
				break;
			default:
				abort();
	    }
	}

	//连接数据库
    if( MYSQL_INI != mysql_metadata_init(MYSQL_IP, MYSQL_ROOT, MYSQL_PASSWD, MYSQL_BD)){
    	fprintf(stderr, "[error] MySQL init failed!\n");
    	exit(EXIT_FAILURE);
    }

    //通过输入的路径path从Mysql取得Metadata，存放在mysqlMetadata中
    mysql_get_metadata(&mysqlMetadata,path);


    //通过fstatus判断进行何种操作
    switch (mysqlMetadata.fstatus){
		case 'k'://文件被上锁不能使用
//			printf("file [%s]is in used.\n", path);
			break;

		case 'l'://文件在本地，将被上传
			if (!(downloadLockFlag || downloadLocalFlag))   //程序调用时，在本地则不操作
			{
				//获得上传开始时间
				gettimeofday(&startTime,NULL);
				
				//上锁
				mysqlMetadata.fstatus='k';
				mysql_save_metadata(&mysqlMetadata);

				//上传文件
				upload(path);
	//	        printf("UPLOADing [%s].\n",path);

				//解锁
				mysqlMetadata.fstatus='c';
				mysql_save_metadata(&mysqlMetadata);

				//获得上传结束时间
				gettimeofday(&endTime,NULL);
				
				//将转存信息传入数据库translog表
				mysqlTranslog.tfpath = path;
				mysqlTranslog.tdate = endTime.tv_sec;
				mysqlTranslog.tfname = mysqlMetadata.fname;
				mysqlTranslog.tfsize = mysqlMetadata.fsize;
				mysqlTranslog.time = endTime.tv_sec - startTime.tv_sec;
				mysqlTranslog.tmethod = 'u';//操作方式为上传upload
				if(autoTrans)
					mysqlTranslog.tstrategy = 'a';
				else
					mysqlTranslog.tstrategy = 's';//判断手动，自动
				mysql_save_translog(&mysqlTranslog);

				//将转存信息传入数据库frequency表
				mysqlFrequency.date = endTime.tv_sec;
				mysqlFrequency.uploadCNT++;
				mysqlFrequency.uploadSize = mysqlMetadata.fsize;
				mysql_save_frequency(&mysqlFrequency);

				//将转存信息传入数据库analyse表
				mysqlAnalyse.localUsed = -mysqlMetadata.fsize;
				mysqlAnalyse.cloudUsed = mysqlMetadata.fsize;
				mysql_save_analyse(&mysqlAnalyse);
			}
			break;

		case 'c'://文件在云端，将被下载
			 //上锁
			 gettimeofday(&startTime,NULL);
			 mysqlMetadata.fstatus = 'k';
			 mysql_save_metadata(&mysqlMetadata);

	         download(path);
	         delete(path);
//	         printf("DOWNLOADing [%s].\n",path);

	         //结束时间
	         gettimeofday(&endTime,NULL);
	         //解锁
	         if (downloadLockFlag)
				mysqlMetadata.fstatus = 'k';
			 else
				mysqlMetadata.fstatus = 'l';
	         mysql_save_metadata(&mysqlMetadata);

	         //将转存信息传入数据库translog表
			 mysqlTranslog.tfpath = path;
			 mysqlTranslog.tdate = startTime.tv_sec;
			 mysqlTranslog.tfname = mysqlMetadata.fname;
			 mysqlTranslog.tfsize = mysqlMetadata.fsize;
			 mysqlTranslog.time = endTime.tv_sec - startTime.tv_sec;
			 mysqlTranslog.tmethod = 'd';
			 if (downloadLockFlag || downloadLocalFlag)//判断手动，自动
				mysqlTranslog.tstrategy = 'a';
			 else
				mysqlTranslog.tstrategy = 's';
			 mysql_save_translog(&mysqlTranslog);

			 //将转存信息传入数据库frequency表
			 mysqlFrequency.date = endTime.tv_sec;
			 mysqlFrequency.downloadCNT++;
			 mysqlFrequency.downloadSize = mysqlMetadata.fsize;
			 mysql_save_frequency(&mysqlFrequency);

			 //将转存信息传入数据库analyse表
			 mysqlAnalyse.localUsed = mysqlMetadata.fsize;
			 mysqlAnalyse.cloudUsed = -mysqlMetadata.fsize;
			 mysql_save_analyse(&mysqlAnalyse);
	        break;
		default:
			break;
	}

    //关闭数据库
	if(MYSQL_QUIT != mysql_metadata_quit())
		fprintf(stderr, "[error] MySQL quit failed!\n");
//	else
//		printf("Done.\n");
//		printf("Mysql quit.\n");


	exit(EXIT_SUCCESS);

}
