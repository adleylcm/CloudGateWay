/*
 * UNFS3 low-level filesystem calls
 * (C) 2004, Pascal Schmidt
 * see file LICENSE for license details
 *  屏蔽win32与Linux系统调用的差异
 */

#ifndef UNFS3_BACKEND_H
#define UNFS3_BACKEND_H

#ifdef WIN32
#include "backend_win32.h"
#else
#include "backend_unix.h"
#endif /* WIN32 */

#endif
