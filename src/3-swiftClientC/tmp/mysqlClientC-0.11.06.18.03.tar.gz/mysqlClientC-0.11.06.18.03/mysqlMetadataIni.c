#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include "mysql_metadata.h"

char * NFS_SERVER_DIR="/home/gateway/nfsdir";

int trave_dir(char* path);

int main(int argc, char **argv){
	char current_dir[1024];
	int opt = 0;
    char *optstring = "hp:";
    while (opt != -1) {
		opt = getopt(argc, argv, optstring);
		switch (opt) {
			case 'p':
				NFS_SERVER_DIR = optarg;
				break;
			case 'h':
				printf("Usage: %s [options]\n", argv[0]);
				printf("\t-h          display this short option summary\n");
				printf("\t-p <path>   absolute path of NFSserver export dir\n");
				exit(0);
				break;
			case '?':
				exit(1);
				break;
			default:
				break;
		}
	}
	
    //MYSQL初始化
	if( MYSQL_INI == mysql_metadata_init(MYSQL_IP, MYSQL_ROOT, MYSQL_PASSWD, MYSQL_BD))
		printf("Mysql init.\n");
	else{
		fprintf(stderr, "[error] MySQL init failed!\n");
		exit(EXIT_FAILURE);
	}
	
	//保存根目录ls信息
	mysql_save_lstat(NFS_SERVER_DIR);
	
	strcpy(current_dir, NFS_SERVER_DIR);
	if(current_dir[strlen(current_dir) - 1] != '/'){
		strcat(current_dir, "/");
	}
	
	trave_dir(current_dir);

	// 退出Mysql
	if(MYSQL_QUIT == mysql_metadata_quit())
		printf("Mysql quit.\n");
	else
		fprintf(stderr, "[error] MySQL quit failed!\n");

	exit(EXIT_SUCCESS);
}


int trave_dir(char* path){
	struct stat file_stat;
	DIR *dir;
	struct dirent *file;
	
	if(!(dir = opendir(path))){
		printf("error opendir %s!!!\n",path);
		return -1;
	}
	
	while((file = readdir(dir)) != NULL){
		if( !strcmp(file->d_name, ".") || !strcmp(file->d_name, "..") )
			continue;
		
		printf("\n%s\n", strcat(path, file->d_name));
		lstat(path, &file_stat);
		mysql_save_lstat(path);
		
		strcat(path, "/");
		if(S_ISDIR(file_stat.st_mode)){
			trave_dir(path);
		}
		path[strlen(path) - 1] = 0;
		*(strrchr(path, '/') + 1) = 0;
	}
	closedir(dir);
	return 0;
}
