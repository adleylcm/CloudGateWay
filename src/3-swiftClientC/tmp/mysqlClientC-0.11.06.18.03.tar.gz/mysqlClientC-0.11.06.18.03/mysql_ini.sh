#! /bin/sh
    
# read -p "Please input MySQL username : " user
# read -p "Please input MySQL password : " pswd
# read -p "Please input parent dir of server root dir : " pdrootdir

user="root"
pswd=111111
pdrootdir="/home/gateway/nfsdir"

# echo "insert into mapping(fid, fpath, fpid) values(0, '"$pdrootdir"', 0);" >> mysqlGatewayDBIni.sql

mysql -u$user -p$pswd < mysqlGatewayDBIni.sql
./mysqlMetadataIni