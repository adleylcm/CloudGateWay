/*
 * mysqlClientCTest, 2013-10-30, by QL <liqilihaha@foxmail.com>
 *
 * 功能: 测试mysql_metadata.c各个函数
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include <error.h>
#include "mysql_metadata.h"

char * NFS_SERVER_DIR="/home/gateway/nfsdir";

int main(int argc, char **argv){

	if( MYSQL_INI == mysql_metadata_init(MYSQL_IP, MYSQL_ROOT, MYSQL_PASSWD, MYSQL_BD))
		printf("Mysql init.\n");
	else{
		fprintf(stderr, "[error] MySQL init failed!\n");
		exit(EXIT_FAILURE);
	}
//
//	//测试 mysql_lookup_fid();
//	printf("[test mysql_lookup_fid()]\n\t");
//	int64_t lookupFid = 1;
//	if( NOTFOUND != mysql_lookup_fid(lookupFid))
//		printf("fid=%ld found. \n", (long)lookupFid);
//	else
//		printf("fid=%ld not found!\n", (long)lookupFid);
//
//	//测试 mysql_fid2fpath();
//	printf("[test mysql_fid2fpath()]\n\t");
//	char mysql_fid2fpathFpath[100];
//	mysql_fid2fpath(1,mysql_fid2fpathFpath);
//	printf("fpath of [fid=1] is \"%s\"\n", mysql_fid2fpathFpath);
//
//	//测试 mysql_fpath2fpid();
//	printf("[test mysql_fpath2fpid()]\n\t");
//	printf("fpid of \"/home/gateway/nfsdir\" is %ld\n",\
//		(long)mysql_fpath2fpid("/home/gateway/nfsdir"));
//
//	//测试 mysql_fpath2fid();
//	printf("[test mysql_fpath2fid()]\n\t");
//	printf("fid of \"/home/gateway/nfsdir\" is %ld\n",\
//		(long)mysql_fpath2fid("/home/gateway/nfsdir"));
//
//	//测试 mysql_fpath2fname();
//	printf("[test mysql_fpath2fname()]\n\t");
//	char mysql_fpath2fnameName[100];
//	mysql_fpath2fname("/home/gateway/nfsdir", mysql_fpath2fnameName);
//	printf("fname of \"/home/gateway/nfsdir\" is \"%s\"\n", mysql_fpath2fnameName);

	//测试 mysql_save_metadata();
	printf("[test mysql_save_metadata()]\n\t");
	mysqlMetadataStru mysqlMetadataTmp;
	mysqlMetadataStruIni(&mysqlMetadataTmp);
	printf("%ld\n",(long)mysqlMetadataTmp.fid);
	printf("%s\n",mysqlMetadataTmp.fname);
	if(-1 == mysqlMetadataTmp.fmode)
		printf("yes\n");
	printf("%c\n",mysqlMetadataTmp.fstatus);
	strcpy(mysqlMetadataTmp.fpath,"/home/gateway/nfsdir/c");
	mysqlMetadataTmp.fsize = 1100;
	mysqlMetadataTmp.fdev = 1100;
	mysql_save_metadata(&mysqlMetadataTmp);
	printf("%ld\n",(long)mysqlMetadataTmp.fid);
	printf("%s\n",mysqlMetadataTmp.fname);
	printf("%c\n",mysqlMetadataTmp.fstatus);

	//
	//测试 mysql_save_lstat();
	printf("[test mysql_save_metadata()]\n\t");
	char saveLstatPath[]="/home/gateway/nfsdir/c";
	mysql_save_lstat(saveLstatPath);
	printf("[waitting.......]\n\n");

//
//	//测试 mysql_delete_metadata_by_fid();
//	printf("[test mysql_delete_metadata_by_fid()]\n");
//	int64_t deleteFid = 6;
//	if( FOUND == mysql_lookup_fid(deleteFid))
//		printf("\tfid=%ld found.\n", (long)deleteFid);
//	else{
//		printf("\t[error]fid=%ld not found!\n", (long)deleteFid);
//		exit(EXIT_FAILURE);
//	}
//	mysql_delete_metadata_by_fid(deleteFid);
//	if( FOUND == mysql_lookup_fid(deleteFid)){
//		fprintf(stderr, "[error]delete fid=%ld failed!\n", (long)deleteFid);
//		exit(EXIT_FAILURE);
//	}else{
//		printf("\tdelete fid=%ld successfully.\n", (long)deleteFid);
//	}


	if(MYSQL_QUIT == mysql_metadata_quit())
		printf("Mysql quit.\n");
	else
		fprintf(stderr, "[error] MySQL quit failed!\n");

	exit(EXIT_SUCCESS);
}
