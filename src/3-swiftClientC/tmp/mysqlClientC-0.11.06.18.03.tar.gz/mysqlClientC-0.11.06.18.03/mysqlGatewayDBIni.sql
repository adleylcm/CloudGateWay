-- phpMyAdmin SQL Dump
-- version 3.4.8
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 11 月 05 日 11:07
-- 服务器版本: 5.5.28
-- PHP 版本: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `gateway`
--

-- --------------------------------------------------------

--
-- 表的结构 `analyse`
--

CREATE TABLE IF NOT EXISTS `analyse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cloudUsed` int(11) NOT NULL,
  `cloudTotal` int(11) NOT NULL,
  `localUsed` int(11) NOT NULL,
  `localTotal` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `analyse`
--

INSERT INTO `analyse` (`id`, `cloudUsed`, `cloudTotal`, `localUsed`, `localTotal`) VALUES
(1, 276, 1024, 339, 1024);

-- --------------------------------------------------------

--
-- 表的结构 `fileinfo`
--

CREATE TABLE IF NOT EXISTS `fileinfo` (
  `fid` bigint(20) NOT NULL AUTO_INCREMENT,
  `fname` varchar(500) NOT NULL,
  `fpath` varchar(500) NOT NULL,
  `fpid` bigint(20) NOT NULL,
  `fstatus` char(1) NOT NULL,
  `ftype` char(1) NOT NULL,
  `curl` varchar(500) DEFAULT NULL,
  `fdev` bigint(20) DEFAULT NULL,
  `fino` bigint(20) DEFAULT NULL,
  `fmode` bigint(20) NOT NULL,
  `fnlinks` bigint(20) DEFAULT NULL,
  `fuid` bigint(20) NOT NULL,
  `fgid` bigint(20) NOT NULL,
  `frdev` bigint(20) DEFAULT NULL,
  `fsize` bigint(20) NOT NULL,
  `dsize` bigint(20) DEFAULT NULL,
  `faddr` varchar(60) DEFAULT NULL,
  `fgen` bigint(20) DEFAULT NULL,
  `atime` bigint(20) NOT NULL,
  `mtime` bigint(20) NOT NULL,
  `ctime` bigint(20) NOT NULL,
  `dblks` bigint(20) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `fileinfo`
--

INSERT INTO `fileinfo` (`fid`, `fname`, `fpath`, `fpid`, `fstatus`, `ftype`, `curl`, `fdev`, `fino`, `fmode`, `fnlinks`, `fuid`, `fgid`, `frdev`, `fsize`, `dsize`, `faddr`, `fgen`, `atime`, `mtime`, `ctime`, `dblks`) VALUES
(1, 'nfsdir', '/home/gateway/nfsdir', 0, 'l', 'd', 'NULL', 64512, 1050404, 16895, 6, 1000, 1000, 0, 4096, 4096, 'NULL', 0, 1383554435, 1383554434, 1383554434, 8),
(2, 'test3', '/home/gateway/nfsdir/test3', 1, 'l', 'd', NULL, 64512, 1058953, 16893, 3, 1000, 1000, 0, 4096, 4096, NULL, -1, 1383557958, 1383557958, 1383557958, 8),
(3, 'test4', '/home/gateway/nfsdir/test3/test4', 2, 'l', 'r', NULL, 64512, 1059083, 33204, 1, 1000, 1000, 0, 0, 4096, NULL, -1, 1383557944, 1383557944, 1383557951, 0),
(4, 'test5', '/home/gateway/nfsdir/test3/test5', 2, 'l', 'd', NULL, 64512, 1323079, 16893, 2, 1000, 1000, 0, 4096, 4096, NULL, -1, 1383557970, 1383557970, 1383557970, 8),
(5, 'test6', '/home/gateway/nfsdir/test3/test5/test6', 4, 'l', 'r', NULL, 64512, 1323083, 33204, 1, 1000, 1000, 0, 0, 4096, NULL, -1, 1383557964, 1383557964, 1383557970, 0),
(6, 'cur', '/home/gateway/nfsdir/cur', 1, 'l', 'd', NULL, 64512, 1322883, 16832, 2, 508, 508, 0, 4096, 4096, NULL, -1, 1383557132, 1382670968, 1382670968, 8),
(7, 'tmp', '/home/gateway/nfsdir/tmp', 1, 'l', 'd', NULL, 64512, 1059075, 16832, 2, 508, 508, 0, 4096, 4096, NULL, -1, 1383557138, 1382673021, 1382673021, 8),
(8, 'new', '/home/gateway/nfsdir/new', 1, 'l', 'd', NULL, 64512, 1322998, 16832, 2, 508, 508, 0, 4096, 4096, NULL, -1, 1383557133, 1382673021, 1382673021, 8),
(9, 'c', '/home/gateway/nfsdir/c', 1, 'c', 'r', NULL, 64512, 1050312, 33204, 1, 1000, 1000, 0, 24408313, 4096, NULL, -1, 1383299897, 1383299938, 1383299938, 47680),
(10, 'ltestfile2', '/home/gateway/nfsdir/ltestfile2', 1, 'l', 'r', NULL, 64512, 1058956, 33188, 1, 0, 0, 0, 0, 4096, NULL, -1, 1383197558, 1383197558, 1383197558, 0),
(11, 'nima', '/home/gateway/nfsdir/nima', 1, 'l', 'r', NULL, 64512, 1059082, 33204, 1, 1000, 1000, 0, 0, 4096, NULL, -1, 1383554428, 1383554428, 1383554434, 0),
(12, 'b', '/home/gateway/nfsdir/b', 1, 'l', 'r', NULL, 64512, 1050310, 33204, 1, 1000, 1000, 0, 0, 4096, NULL, -1, 1383187643, 1383187643, 1383187643, 0),
(13, 'ltestfile1', '/home/gateway/nfsdir/ltestfile1', 1, 'l', 'r', NULL, 64512, 1058963, 33279, 1, 0, 0, 0, 0, 4096, NULL, -1, 1383295388, 1383295388, 1383295388, 0),
(14, 'wahaha', '/home/gateway/nfsdir/wahaha', 1, 'l', 'r', NULL, 64512, 1059079, 33204, 1, 1000, 1000, 0, 0, 4096, NULL, -1, 1383529233, 1383529233, 1383529239, 0),
(15, 'ltest', '/home/gateway/nfsdir/ltest', 1, 'l', 'r', NULL, 64512, 1058958, 33279, 1, 1000, 1000, 0, 0, 4096, NULL, -1, 1383295359, 1383295369, 1383295369, 0),
(16, 'zhangtest', '/home/gateway/nfsdir/zhangtest', 1, 'l', 'r', NULL, 64512, 1058977, 33188, 1, 0, 0, 0, 0, 4096, NULL, -1, 1383211621, 1383192263, 1383192263, 0);

-- --------------------------------------------------------

--
-- 表的结构 `frequency`
--

CREATE TABLE IF NOT EXISTS `frequency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `uploadCNT` int(11) NOT NULL,
  `uploadSize` int(11) NOT NULL,
  `downloadCNT` int(11) NOT NULL,
  `downloadSize` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `frequency`
--

INSERT INTO `frequency` (`id`, `date`, `uploadCNT`, `uploadSize`, `downloadCNT`, `downloadSize`) VALUES
(1, '2013-10-25', 7, 110, 8, 100),
(2, '2013-10-24', 9, 70, 7, 230),
(6, '2013-10-23', 4, 99, 8, 123),
(4, '2013-10-22', 4, 300, 3, 70),
(5, '2013-10-21', 10, 210, 6, 80),
(7, '2013-10-20', 10, 210, 6, 80),
(8, '2013-10-19', 4, 99, 8, 123),
(9, '2013-10-18', 9, 70, 7, 230),
(10, '2013-10-17', 7, 110, 8, 100),
(11, '2013-10-16', 10, 210, 6, 80),
(12, '2013-10-15', 9, 70, 7, 230),
(13, '2013-10-15', 7, 110, 8, 100),
(14, '2013-10-13', 9, 70, 7, 230),
(15, '2013-10-12', 10, 210, 6, 80),
(16, '2013-10-11', 7, 110, 8, 100),
(17, '2013-10-10', 4, 99, 8, 123);

-- --------------------------------------------------------

--
-- 表的结构 `mapping`
--

CREATE TABLE IF NOT EXISTS `mapping` (
  `fid` bigint(20) NOT NULL,
  `fpath` varchar(500) NOT NULL,
  `fpid` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `mapping`
--

INSERT INTO `mapping` (`fid`, `fpath`, `fpid`) VALUES
(1, '/home/gateway/nfsdir', 0),
(2, '/home/gateway/nfsdir/test3', 1),
(4, '/home/gateway/nfsdir/test3/test5', 2),
(6, '/home/gateway/nfsdir/cur', 1),
(7, '/home/gateway/nfsdir/tmp', 1),
(8, '/home/gateway/nfsdir/new', 1);

-- --------------------------------------------------------

--
-- 表的结构 `policy`
--

CREATE TABLE IF NOT EXISTS `policy` (
  `id` int(11) NOT NULL,
  `flagsize` int(1) NOT NULL,
  `flagtype` int(1) NOT NULL,
  `flagexpires` int(1) NOT NULL,
  `flagfreq` int(1) NOT NULL,
  `fileSizeth` int(11) NOT NULL DEFAULT '1024',
  `fileType` varchar(1024) NOT NULL DEFAULT 'conf|emil|tmp',
  `expires` bigint(20) NOT NULL DEFAULT '30',
  `freq` int(11) NOT NULL DEFAULT '4',
  `ipaddr` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL DEFAULT 'swift',
  `passwd` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `policy`
--

INSERT INTO `policy` (`id`, `flagsize`, `flagtype`, `flagexpires`, `flagfreq`, `fileSizeth`, `fileType`, `expires`, `freq`, `ipaddr`, `user`, `passwd`) VALUES
(0, 1, 1, 1, 1, 1024, 'conf|emil|tmp', 20, 4, '192.168.3.9:5000/v2.0', 'swift', '111111');

-- --------------------------------------------------------

--
-- 表的结构 `translog`
--

CREATE TABLE IF NOT EXISTS `translog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tfname` varchar(50) NOT NULL,
  `tfsize` int(11) NOT NULL,
  `tmethod` char(1) NOT NULL,
  `time` int(11) NOT NULL,
  `tstrategy` char(1) NOT NULL,
  `tpath` varchar(50) NOT NULL,
  `tdate` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `translog`
--

INSERT INTO `translog` (`id`, `tfname`, `tfsize`, `tmethod`, `time`, `tstrategy`, `tpath`, `tdate`) VALUES
(1, 'test', 100, 'u', 100, 's', '/home/', 20131234),
(2, 'test2', 12, 'd', 254, 'c', '/home/', 20134567);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
