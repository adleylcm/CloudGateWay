import os
import swiftpy


upone("/home/gateway/swiftclientC/python-swiftclient/test")
