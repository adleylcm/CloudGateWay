
/*
 * UNFS3 error translation
 * (C) 2004, Pascal Schmidt
 * see file LICENSE for license details
 */

/*
 * translations from Unix errno to NFS error numbers
 */

#include "config.h"

#include <rpc/rpc.h>
#include <errno.h>

#include "nfs.h"
#include "error.h"
#include "backend.h"

static int is_stale(void)
{
	printf("Running error.c----is_stale()\n"); //QL

    if (errno == ENOTDIR || errno == ELOOP || errno == ENOENT ||
	errno == ENAMETOOLONG)
	return -1;
    else
	return 0;
}

nfsstat3 symlink_err(void)
{
	printf("Running error.c----symlink_err()\n"); //QL

    if (errno == EACCES || errno == EPERM)
	return NFS3ERR_ACCES;
    else if (is_stale())
	return NFS3ERR_STALE;
    else if (errno == EROFS)
	return NFS3ERR_ROFS;
    else if (errno == EEXIST)
	return NFS3ERR_EXIST;
    else if (errno == ENOSPC)
	return NFS3ERR_NOSPC;
#ifdef EDQUOT
    else if (errno == EDQUOT)
	return NFS3ERR_DQUOT;
#endif
    else if (errno == ENOSYS)
	return NFS3ERR_NOTSUPP;
    else if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else
	return NFS3ERR_IO;
}

nfsstat3 mkdir_err(void)
{
	printf("Running error.c----mkdir_err()\n"); //QL

    return symlink_err();
}

nfsstat3 mknod_err(void)
{
	printf("Running error.c----mknod_err()\n"); //QL

    return symlink_err();
}

nfsstat3 link_err(void)
{
	printf("Running error.c----link_err()\n"); //QL

    if (errno == EXDEV)
	return NFS3ERR_XDEV;
    else if (errno == EMLINK)
	return NFS3ERR_MLINK;
#ifdef EDQUOT
    else if (errno == EDQUOT)
	return NFS3ERR_DQUOT;
#endif
    else
	return symlink_err();
}

nfsstat3 lookup_err(void)
{
	printf("Running error.c----lookup_err()\n"); //QL

    if (errno == ENOENT)
	return NFS3ERR_NOENT;
#ifdef ENOMEDIUM
    else if (errno == ENOMEDIUM)
	return NFS3ERR_NOENT;
#endif
    else if (errno == EACCES)
	return NFS3ERR_ACCES;
    else if (errno == ENOTDIR || errno == ELOOP || errno == ENAMETOOLONG)
	return NFS3ERR_STALE;
    else if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else
	return NFS3ERR_IO;
}

nfsstat3 readlink_err(void)
{
	printf("Running error.c----readlink_err()\n"); //QL

    if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else if (errno == EACCES)
	return NFS3ERR_ACCES;
    else if (errno == ENOSYS)
	return NFS3ERR_NOTSUPP;
    else if (is_stale())
	return NFS3ERR_STALE;
    else
	return NFS3ERR_IO;
}

nfsstat3 read_err(void)
{
	printf("Running error.c----read_err()\n"); //QL

    if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else if (is_stale())
	return NFS3ERR_STALE;
    else if (errno == EACCES)
	return NFS3ERR_ACCES;
    else if (errno == ENXIO || errno == ENODEV)
	return NFS3ERR_NXIO;
    else
	return NFS3ERR_IO;
}

nfsstat3 write_open_err(void)
{
	printf("Running error.c----write_open_err()\n"); //QL

    if (errno == EACCES)
	return NFS3ERR_ACCES;
    else if (is_stale())
	return NFS3ERR_STALE;
    else if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else if (errno == EROFS)
	return NFS3ERR_ROFS;
    else
	return NFS3ERR_IO;
}

nfsstat3 write_write_err(void)
{
	printf("Running error.c----write_write_err()\n"); //QL

    if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else if (errno == EFBIG)
	return NFS3ERR_FBIG;
    else if (errno == ENOSPC)
	return NFS3ERR_NOSPC;
#ifdef EDQUOT
    else if (errno == EDQUOT)
	return NFS3ERR_DQUOT;
#endif
    else
	return NFS3ERR_IO;
}

nfsstat3 create_err(void)
{
	printf("Running error.c----create_err()\n"); //QL

    if (errno == EACCES)
	return NFS3ERR_ACCES;
    else if (is_stale())
	return NFS3ERR_STALE;
    else if (errno == EROFS)
	return NFS3ERR_ROFS;
    else if (errno == ENOSPC)
	return NFS3ERR_NOSPC;
    else if (errno == EEXIST)
	return NFS3ERR_EXIST;
#ifdef EDQUOT
    else if (errno == EDQUOT)
	return NFS3ERR_DQUOT;
#endif
    else
	return NFS3ERR_IO;
}

nfsstat3 rename_err(void)
{
	printf("Running error.c----rename_err()\n"); //QL

    if (errno == EISDIR)
	return NFS3ERR_ISDIR;
    else if (errno == EXDEV)
	return NFS3ERR_XDEV;
    else if (errno == EEXIST)
	return NFS3ERR_EXIST;
    else if (errno == ENOTEMPTY)
	return NFS3ERR_NOTEMPTY;
    else if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else if (errno == ENOTDIR)
	return NFS3ERR_NOTDIR;
    else if (errno == EACCES || errno == EPERM)
	return NFS3ERR_ACCES;
    else if (errno == ENOENT)
	return NFS3ERR_NOENT;
    else if (errno == ELOOP || errno == ENAMETOOLONG)
	return NFS3ERR_STALE;
    else if (errno == EROFS)
	return NFS3ERR_ROFS;
    else if (errno == ENOSPC)
	return NFS3ERR_NOSPC;
#ifdef EDQUOT
    else if (errno == EDQUOT)
	return NFS3ERR_DQUOT;
#endif
    else
	return NFS3ERR_IO;
}

nfsstat3 remove_err(void)
{
	printf("Running error.c----remove_err()\n"); //QL

    if (errno == EACCES || errno == EPERM)
	return NFS3ERR_ACCES;
    else if (errno == ENOENT)
	return ENOENT;
    else if (errno == ENOTDIR || errno == ELOOP || errno == ENAMETOOLONG)
	return NFS3ERR_STALE;
    else if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else if (errno == EROFS)
	return NFS3ERR_ROFS;
    else
	return NFS3ERR_IO;
}

nfsstat3 rmdir_err(void)
{
	printf("Running error.c----rmdir_err()\n"); //QL

    if (errno == ENOTEMPTY)
	return NFS3ERR_NOTEMPTY;
    else
	return remove_err();
}

nfsstat3 setattr_err(void)
{
	printf("Running error.c----setattr_err()\n"); //QL

    if (errno == EPERM)
	return NFS3ERR_PERM;
    else if (errno == EROFS)
	return NFS3ERR_ROFS;
    else if (is_stale())
	return NFS3ERR_STALE;
    else if (errno == EACCES)
	return NFS3ERR_ACCES;
#ifdef EDQUOT
    else if (errno == EDQUOT)
	return NFS3ERR_DQUOT;
#endif
    else if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else
	return NFS3ERR_IO;
}

nfsstat3 readdir_err(void)
{
	printf("Running error.c----readdir_err()\n"); //QL

    if (errno == EPERM)
	return NFS3ERR_PERM;
    else if (errno == EACCES)
	return NFS3ERR_ACCES;
    else if (errno == ENOTDIR)
	return NFS3ERR_NOTDIR;
    else if (is_stale())
	return NFS3ERR_STALE;
    else if (errno == EINVAL)
	return NFS3ERR_INVAL;
    else
	return NFS3ERR_IO;
}

/*
 * combine two error values
 */
nfsstat3 join(nfsstat3 x, nfsstat3 y)
{
	printf("Running error.c----join()\n"); //QL

    return (x != NFS3_OK) ? x : y;
}

/*
 * combine three error values
 */
nfsstat3 join3(nfsstat3 x, nfsstat3 y, nfsstat3 z)
{
	printf("Running error.c----join3()\n"); //QL

    return (x != NFS3_OK) ? x : join(y, z);
}
