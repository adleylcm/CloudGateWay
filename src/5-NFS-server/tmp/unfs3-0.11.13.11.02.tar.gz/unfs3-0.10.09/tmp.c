/*
 * tmp.c
 *
 *  Created on: Aug 8, 2013
 *      Author: ql
 */
#include "config.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>		       /* needed for statfs() on NetBSD */
#if HAVE_SYS_MOUNT_H == 1
#include <sys/mount.h>		       /* dito */
#endif
#if HAVE_SYS_VMOUNT_H == 1
#include <sys/vmount.h>		       /* AIX */
#endif
#include <rpc/rpc.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <utime.h>
#ifndef WIN32
#include <sys/socket.h>
#include <sys/un.h>
#endif				       /* WIN32 */

#if HAVE_STATVFS == 1
# include <sys/statvfs.h>
#else
# define statvfs statfs
#endif

#include "nfs.h"
#include "mount.h"
#include "fh.h"
#include "fh_cache.h"
#include "attr.h"
#include "readdir.h"
#include "user.h"
#include "error.h"
#include "fd_cache.h"
#include "daemon.h"
#include "backend.h"
#include "Config/exports.h"
#include "Extras/cluster.h"


#define PREP(p,f) do {						\
                      unfs3_fh_t *fh = (void *)f.data.data_val; \
                      switch_to_root();				\
                      p = fh_decomp(f);				\
                      if (exports_options(p, rqstp, NULL, NULL) == -1) { \
                          memset(&result, 0, sizeof(result));	\
                          if (p)				\
                              result.status = NFS3ERR_ACCES;	\
                          else					\
                              result.status = NFS3ERR_STALE;	\
                          return &result;			\
                      }						\
                      if (fh->pwhash != export_password_hash) { \
                          memset(&result, 0, sizeof(result));	\
                          result.status = NFS3ERR_STALE;        \
                          return &result;                       \
                      }                                         \
                      switch_user(rqstp);			\
                  } while (0)


GETATTR3res *nfsproc3_getattr_3_svc(GETATTR3args * argp,
				    struct svc_req * rqstp)
{
    printf("Running nfs.c----nfsproc3_getattr_3_svc\n");
    static GETATTR3res result;
    char *path;
    post_op_attr post;

    unfs3_fh_t *fh = (void *)argp->object.data.data_val;//接受到的文件句柄
    switch_to_root();	//转到root权限
    path = fh_decomp(argp->object);	//文件句柄转为路径
    if (exports_options(path, rqstp, NULL, NULL) == -1) {
    	memset(&result, 0, sizeof(result));
    	if (path)
    		result.status = NFS3ERR_ACCES;
    	else
    		result.status = NFS3ERR_STALE;
    	return &result;
    }
    if (fh->pwhash != export_password_hash) {
    	memset(&result, 0, sizeof(result));
    	result.status = NFS3ERR_STALE;
    	return &result;
    }
    switch_user(rqstp);

    post = get_post_cached(rqstp);

    result.status = NFS3_OK;
    result.GETATTR3res_u.resok.obj_attributes =	post.post_op_attr_u.attributes;

    return &result;
}
