/*
 * mysql_data, 2013-8-9, by Lin Zhong <zlbeidou@foxmail.com>
 *
 * 功能: 提供目录信息在mysql中存取的便捷接口
 *
 * 关键变量: extern mysqldatastru mysqldata(目录信息缓冲变量)
 * 接口函数:
 *     int mysql_data_init(const char *, const char *, const char *);
 *     int64 mysql_get_fpid(const char *);
 *     int64 mysql_mapping(int64 fid, char *);
 *     void mysql_clear_mysqldata();
 *     void mysql_default_mysqldata();
 *     void mysql_set_fname_mysqldata();
 *     int mysql_set_data();
 *     int mysql_get_data(char *);
 *     int mysql_data_quit();
 */

#ifndef MYSQL_DATA_H
#define MYSQL_DATA_H

#include <sys/types.h>
#include <sys/stat.h>
#include "nfs.h"
#include "backend.h"

//约定如下返回值类型:
//0或正数表示正常返回
//-1表示查无此值
//-2表示输入错误
//-3, -4, ...表示其他自定义错误
//QL-begin
#define MYSQL_ROOT "root"
#define MYSQL_PW "111111"
#define MYSQL_DB "gateway"
#define MYSQL_OK 0
#define MYSQLERR_INI -1
#define MYSQLERR_CONN -2
//QL-end

#define FILEINFO_FID 0
#define FILEINFO_FNAME 1
#define FILEINFO_FPATH 2
#define FILEINFO_FPID 3
#define FILEINFO_FSTATUS 4
#define FILEINFO_FTYPE 5
#define FILEINFO_CURL 6
#define FILEINFO_FDEV 7
#define FILEINFO_FINO 8
#define FILEINFO_FMODE 9
#define FILEINFO_FNLINKS 10
#define FILEINFO_FUID 11
#define FILEINFO_FGID 12
#define FILEINFO_FRDEV 13
#define FILEINFO_FSIZE 14
#define FILEINFO_DSIZE 15
#define FILEINFO_FADDR 16
#define FILEINFO_FGEN 17
#define FILEINFO_ATIME 18
#define FILEINFO_MTIME 19
#define FILEINFO_CTIME 20
#define FILEINFO_DBLKS 21

#define SQL_INT_NULL -1
#define SQL_CHR_NULL 0

#define FILEINFO_FNAME_MAX 100
#define FILEINFO_FPATH_MAX 200
#define FILEINFO_CURL_MAX 200
#define SQL_LEN_MAX 800

struct mysqldatastru{
	int flag;

	int64 fid;// 0
	char fname[FILEINFO_FNAME_MAX];// 1
	char fpath[FILEINFO_FPATH_MAX];// 2
	int64 fpid;// 3
	char fstatus;// 4
	char ftype;// 5
	char curl[FILEINFO_CURL_MAX];// 6
	int64 fdev;// 7
	int64 fino;// 8
	int64 fmode;// 9
	int64 fnlinks;// 10
	int64 fuid;// 11
	int64 fgid;// 12
	int64 frdev;// 13
	int64 fsize;// 14
	int64 dsize;// 15
	char faddr[60];// 16
	int64 fgen;// 17
	int64 atime;// 18
	int64 mtime;// 19
	int64 ctime;// 20
	int64 dblks;// 21
};
typedef struct mysqldatastru mysqldatastru;


struct mysqluserdatastru{
	int flag;
	char extenddata[SQL_LEN_MAX];
};
typedef struct mysqluserdatastru mysqluserdatastru;

extern mysqldatastru mysqldata;
extern mysqluserdatastru mysqluserdata;
extern struct stat st_sql_obj;
//数据库初始化
int mysql_data_init(const char *user, const char *passwd, const char *db);
//从数据库获得文件属性
void lstat_db(const char *path, backend_statstruct *result);

int mysql_data_quit();

int64 mysql_get_fpid(const char *fpath);

/*fid与fpath互查
 *fpath必须在调用之前已经分配好了内存
 *用法: fid->fpath---if(mysql_mapping(5, fpath) == 0)//结果已经存在fpath中了
 *      fpath->fid---fid = mysql_mapping(0, "/server/test");
 *返回: -1-查无此值, -2-fpath输入不正确 */
int64 mysql_mapping(int64 fid, char *fpath);

//将mysqldata中的有效值存进mysql数据库中
//正常返回: 0
//错误返回: -1-数据库存入发生错误, -2-mysqldata.fpath错误, -3-mysqldata关键数据残缺
//发生错误时不存入数据库
int mysql_set_data();

//将mysql中的某项纪录删除
//返回: 0-正常, -1-无此值, -2-输入路径错误, -3-试图删除一个非空的目录
int mysql_delete_data(int64 fid);

//看是否有fpid等于输入的值存在
//0-存在, -1-查无此值
int mysql_lookup_from_fpid(int64 pid);

//从mysql中查找fpath, 看是否有内容
int64 mysql_lookup_data(char *fpath);

//从mysql中将信息读取到mysqldata缓冲中
//返回: 0-正常, -1-无此文件信息, -2-输入路径错误, -3-某些值缺损
int mysql_get_data(char *fpath);

//清除mysqldata缓冲
void mysql_clear_mysqldata();
//清除mysqluserdata缓冲
void mysql_clear_mysqluserdata();
//将mysqldata设置为初始值
void mysql_default_mysqldata();
//将mysqldata.fpath截断后赋值给mysqldata.fname
void mysql_set_fname_mysqldata();

//void mysql_cpy_fattr3_mysqldata(const char *path, const fattr3 *attr);

void mysql_cpy_stat_mysqldata(const char *path, const struct stat *st_stat);

void mysql_cpy_stattime_mysqldata(const char *path, const struct stat *st_stat);
//int mysql_cpy_mysqldata_cache();

#endif
