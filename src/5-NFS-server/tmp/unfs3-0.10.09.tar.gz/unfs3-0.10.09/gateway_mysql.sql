drop database gateway;

create database gateway;

use gateway;

create table fileinfo(
	fid bigint not null primary key auto_increment,-- 0
	fname varchar(500) not null,-- 1
	fpath varchar(500) not null,-- 2
	fpid bigint not null,-- 3
	fstatus char(1) not null,-- 4
	ftype char(1) not null,-- 5
	curl varchar(500),-- 6
	fdev bigint,-- 7
	fino bigint,-- 8
	fmode bigint not null,-- 9
	fnlinks bigint,-- 10
	fuid bigint not null,-- 11
	fgid bigint not null,-- 12
	frdev bigint,-- 13
	fsize bigint not null,-- 14
	dsize bigint,-- 15
	faddr varchar(60),-- 16
	fgen bigint,-- 17
	atime bigint not null,-- 18
	mtime bigint not null,-- 19
	ctime bigint not null,-- 20
	dblks bigint not null-- 21
	);

create table mapping(
	fid bigint not null,
	fpath varchar(500) not null,
	fpid bigint not null);

create table policy(
	expires bigint not null);

insert into policy(expires) values(30);
