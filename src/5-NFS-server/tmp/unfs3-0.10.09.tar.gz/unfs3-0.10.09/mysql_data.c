/*
 * mysql_data, 2013-8-9, by Lin Zhong <zlbeidou@foxmail.com>
 *
 * 功能: 提供目录信息在mysql中存取的便捷接口
 *
 * 关键变量: extern mysqldatastru mysqldata(目录信息缓冲变量)
 * 接口函数:
 *     int mysql_data_init(const char *, const char *, const char *);
 *
lstat_db()     

int mysql_get_data(char *);

 int64 mysql_get_fpid(const char *);
 *     int64 mysql_mapping(int64 fid, char *);
 *     void mysql_clear_mysqldata();
 *     void mysql_default_mysqldata();
 *     void mysql_set_fname_mysqldata();
 *     int mysql_set_data();
 *     int mysql_get_data(char *);
 *     int mysql_data_quit();
 */

#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include "mysql_data.h"
#include "fh.h"


MYSQL mysql;
MYSQL_RES *mysqlres;
MYSQL_ROW mysqlrow;
char sql[SQL_LEN_MAX];//sql命令
mysqldatastru mysqldata;//此变量为extern
mysqluserdatastru mysqluserdata;//此变量为extern
struct stat st_sql_obj;//此变量为extern

//mysql初始化, 用法: mysql_data_init("root", "111111", "gateway");
int mysql_data_init(const char *user, const char *passwd, const char *db){// ok
	if(mysql_init(&mysql) == NULL){
		fprintf(stderr,"Error: MySQL init failed.\n");
		return MYSQLERR_INI;
	}
	if(mysql_real_connect(&mysql, "127.0.0.1", user, passwd, db, MYSQL_PORT, NULL, 0) == NULL){
		printf("[error] MySQL conn fail!\n");
		return MYSQLERR_CONN;
	}
	// mysqlres = NULL;
	printf("MySQL connected.\n");
	return MYSQL_OK;
}

//从数据库获得元数据信息，成功执行时，返回0。
// backend_statstruct {
// dev_t st_dev; /* 文件所在设备的标识 */
// ino_t st_ino; /* 文件结点号 */
// mode_t st_mode; /* 文件保护模式 */
// nlink_t st_nlink; /* 硬连接数 */
// uid_t st_uid; /* 文件用户标识 */
// gid_t st_gid; /* 文件用户组标识 */
// dev_t st_rdev;  文件所表示的特殊设备文件的设备标识 
// off_t st_size; /* 总大小，字节为单位 */
// blksize_t st_blksize; /* 文件系统的块大小 */
// blkcnt_t st_blocks; /* 分配给文件的块的数量，512字节为单元 */
// time_t st_atime; /* 最后访问时间 */
// time_t st_mtime; /* 最后修改时间 */
// time_t st_ctime; /* 最后状态改变时间 */
// };
void lstat_db(const char *path, backend_statstruct *result){
    // mysql_get_metadata(path,result);
    // mysql_get_data(path);
    // switch(mysqldata.ftype){
    //     case 'r': result_attr.type = NF3REG; break;
    //     case 'd': result_attr.type = NF3DIR; break;
    //     case 'b': result_attr.type = NF3BLK; break;
    //     case 'c': result_attr.type = NF3CHR; break;
    //     case 'l': result_attr.type = NF3LNK; break;
    //     case 's': result_attr.type = NF3SOCK; break;
    //     case 'f': result_attr.type = NF3FIFO; break;
    //     default: result_attr.type = NF3REG;
    // }
    // result_attr.mode = (uint32)mysqldata.fmode;
    // result_attr.nlink = (uint32)mysqldata.fnlinks;
    // result_attr.uid = (uint32)mysqldata.fuid;
    // result_attr.gid = (uint32)mysqldata.fgid;
    // result_attr.size = (uint64)mysqldata.fsize;
    // result_attr.used = (uint64)(mysqldata.dblks * 512);
    // result_attr.rdev.specdata1 = (uint32)((mysqldata.frdev >> 8) & 0xFF);
    // result_attr.rdev.specdata2 = (uint32)(mysqldata.frdev & 0xFF);
    // result_attr.fsid = (uint64)mysqldata.fdev;
    // result_attr.fileid = (fileid3)mysqldata.fino;
    // result_attr.atime.seconds = (uint32)mysqldata.atime;
    // result_attr.atime.nseconds = 0;
    // result_attr.mtime.seconds = (uint32)mysqldata.mtime;
    // result_attr.mtime.nseconds = 0;
    // result_attr.ctime.seconds = (uint32)mysqldata.ctime;
    // result_attr.ctime.nseconds = 0;
    
    // result.GETATTR3res_u.resok.obj_attributes = result_attr;
    return 0;
}
//关闭数据库
int mysql_data_quit(){// ok
	mysql_close(&mysql);
	return 0;
}

//获取fpid
int64 mysql_get_fpid(const char *fpath){// ok
	/*若将数据库中的服务器根目录去除, 需要这里进行改动.
	 *比对fpath与服务器根目录path, 相同则返回0.*/
	// zl
	
	char tmppath[FILEINFO_FPATH_MAX];
	char *tmp;
	
	strcpy(tmppath, fpath);
	tmp = strrchr(tmppath, '/');
	if(tmp)
		*tmp = 0;
	else
		return -1;//tmp为NULL, 即路径中没有'/', 错误

	sprintf(sql, "select fid from mapping where fpath='%s' limit 1", tmppath);
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		//printf("[error] Not paired data!\n");// zl
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	return atol(mysqlrow[0]);
}

/*fpath必须在调用之前已经分配好了内存
 *用法: fid->fpath---if(mysql_mapping(5, fpath) == 0)//结果已经存在fpath中了
 *      fpath->fid---fid = mysql_mapping(0, "/server/test");
 *返回: -1-查无此值, -2-fpath输入不正确 */
int64 mysql_mapping(int64 fid, char *fpath){// ok
	if(fid){//fid不为0表示根据fid查fpath
		sprintf(sql, "select fpath from fileinfo where fid=%ld limit 1", (long)fid);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		if( (mysqlres = mysql_store_result(&mysql)) == NULL){
			return -1;
		}
		if(!(mysqlrow = mysql_fetch_row(mysqlres))){
			return -1;
		}
		strcpy(fpath, mysqlrow[0]);
		return 0;
	}else{//fid为0表示根据fpath查fid
		if(fpath == NULL || *fpath == 0)return -2;
		
		sprintf(sql, "select fid from mapping where fpath='%s' limit 1", fpath);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		if( (mysqlres = mysql_store_result(&mysql)) == NULL){
			return -1;
		}
		if((mysqlrow = mysql_fetch_row(mysqlres))){
			return atol(mysqlrow[0]);
		}
		
		int64 tmpfpid = mysql_get_fpid(fpath);
		if(tmpfpid < 0)
			return -1;
		
		//查fpid = 父目录fid的所有文件
		sprintf(sql, "select fid,fpath from fileinfo where fpid=%ld", tmpfpid);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		if( (mysqlres = mysql_store_result(&mysql)) == NULL){
			return -1;
		}
		while((mysqlrow = mysql_fetch_row(mysqlres))){
			if(strcmp(fpath, mysqlrow[1]) == 0){
				return atol(mysqlrow[0]);
			}
		}
		//都查不到
		return -1;
	}
}

//将mysqldata中的有效值存进mysql数据库中
int mysql_set_data(){// ok
	int64 tmpfid = 0;
	if(!*mysqldata.fpath)return -2;//没有路径信息, mysqldata错误
	
	if(mysqldata.fpath[strlen(mysqldata.fpath) - 1] == '/')
		mysqldata.fpath[strlen(mysqldata.fpath) - 1] = 0;
	
	if((tmpfid = mysql_mapping(0, mysqldata.fpath)) >= 0){//已经存在记录, 只更新, 不创建
		sprintf(sql, "update fileinfo set fpath='%s'", mysqldata.fpath);
		
		if(mysqldata.fstatus != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",fstatus='%c'", mysqldata.fstatus);
		if(mysqldata.ftype != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",ftype='%c'", mysqldata.ftype);
		if(*mysqldata.curl != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",curl='%s'", mysqldata.curl);
		if(mysqldata.fdev != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fdev=%ld", mysqldata.fdev);
		if(mysqldata.fino != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fino=%ld", mysqldata.fino);
		if(mysqldata.fmode != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fmode=%ld", mysqldata.fmode);
		if(mysqldata.fnlinks != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fnlinks=%ld", mysqldata.fnlinks);
		if(mysqldata.fuid != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fuid=%ld", mysqldata.fuid);
		if(mysqldata.fgid != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fgid=%ld", mysqldata.fgid);
		if(mysqldata.frdev != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",frdev=%ld", mysqldata.frdev);
		if(mysqldata.fsize != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fsize=%ld", mysqldata.fsize);
		if(mysqldata.dsize != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",dsize=%ld", mysqldata.dsize);
		if(*mysqldata.faddr != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",faddr='%s'", mysqldata.faddr);
		if(mysqldata.fgen != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fgen=%ld", mysqldata.fgen);
		if(mysqldata.atime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",atime=%ld", mysqldata.atime);
		if(mysqldata.mtime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",mtime=%ld", mysqldata.mtime);
		if(mysqldata.ctime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",ctime=%ld", mysqldata.ctime);
		if(mysqldata.dblks != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",dblks=%ld", mysqldata.dblks);
		
		if(*(mysqluserdata.extenddata) != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",%s ", mysqluserdata.extenddata);
		
		sprintf(sql + strlen(sql), " where fid=%ld limit 1", tmpfid);
		
		printf("[sql] %s\n", sql);
	}else{//没有记录, 创建
		if(!(*mysqldata.fname && *mysqldata.fpath &&
			*mysqldata.curl && *mysqldata.faddr))
			return -3;
		mysql_set_fname_mysqldata();
		mysqldata.fpid = mysql_get_fpid(mysqldata.fpath);
		sprintf(sql, "insert into fileinfo(\
fname,\
fpath,\
fpid,\
fstatus,\
ftype,\
curl,\
fdev,\
fino,\
fmode,\
fnlinks,\
fuid,\
fgid,\
frdev,\
fsize,\
dsize,\
faddr,\
fgen,\
atime,\
mtime,\
ctime,\
dblks) \
values('%s','%s',%ld,'%c','%c','%s',%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,'%s',%ld,%ld,%ld,%ld,%ld)",
		mysqldata.fname,\
		mysqldata.fpath,\
		mysqldata.fpid,\
		mysqldata.fstatus,\
		mysqldata.ftype,\
		mysqldata.curl,\
		mysqldata.fdev,\
		mysqldata.fino,\
		mysqldata.fmode,\
		mysqldata.fnlinks,\
		mysqldata.fuid,\
		mysqldata.fgid,\
		mysqldata.frdev,\
		mysqldata.fsize,\
		mysqldata.dsize,\
		mysqldata.faddr,\
		mysqldata.fgen,\
		mysqldata.atime,\
		mysqldata.mtime,\
		mysqldata.ctime,\
		mysqldata.dblks);
		
		if(S_ISDIR(mysqldata.fmode)){
			mysql_query(&mysql, sql);
			if(mysql_affected_rows(&mysql) == 0)
				return -1;
			tmpfid = (int64)mysql_insert_id(&mysql);
			sprintf(sql, "insert into mapping(fid, fpath, fpid) values(%ld, '%s', %ld)", tmpfid, mysqldata.fpath, mysqldata.fpid);
		}
	}
	mysql_query(&mysql, sql);
	if(mysql_affected_rows(&mysql) == 0)
		return -1;
	return 0;
}

//将mysql中的某项纪录删除
//返回: 0-正常, -1-无此值, -2-输入路径错误
int mysql_delete_data(int64 fid){
	if(fid < 0)return -2;//输入路径错误
	
	sprintf(sql, "delete from fileinfo where fid=%ld", fid);
	mysql_query(&mysql, sql);
	sprintf(sql, "delete from mapping where fid=%ld limit 1", fid);
	mysql_query(&mysql, sql);
	return 0;
}

//看是否有fpid等于输入的值存在
//0-存在, -1-查无此值
int mysql_lookup_from_fpid(int64 pid){
	if(pid < 0)
		return -1;
	sprintf(sql, "select * from fileinfo where fpid=%ld limit 1", pid);
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	return 0;
}

//从mysql中查找fpath, 看是否有内容
int64 mysql_lookup_data(char *fpath){
	if(!(fpath && *fpath))return -2;//路径错误
	
	if(fpath[strlen(fpath) - 1] == '/'){//如果fpath中末位是'/', 要去除
		char tmpfpath[FILEINFO_FPATH_MAX];
		strcpy(tmpfpath, fpath);
		tmpfpath[strlen(tmpfpath) - 1] = 0;
		return mysql_mapping(0, tmpfpath);
	}else{
		return mysql_mapping(0, fpath);
	}
}

//从mysql中将信息读取到mysqldata缓冲中
int mysql_get_data(char *fpath){// ok
	if(!(fpath && *fpath))return -2;//路径错误
	
	int64 fid = mysql_lookup_data(fpath);

	mysql_clear_mysqldata();
	/*fid,fname,fpath,fpid,fstatus,ftype,curl,fdev,fino,fmode,fnlinks,fuid,fgid,
	 *frdev,fsize,dsize,faddr,fgen,atime,mtime,ctime,dblks;
	 *暂时这些信息, 如有其它字段, 一定要在结尾添加,
	 *并且建立数据库时也要按相同的顺序*/
	sprintf(sql, "select * from fileinfo where fid=%ld limit 1", (long)fid);//21 zl
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	//strcpy(fpath, mysqlrow[0]);
	int status_flag = 0;//0-正常, -3-某些值缺损
	if(mysqlrow[FILEINFO_FID])
		mysqldata.fid = atol(mysqlrow[FILEINFO_FID]);
	
	if(mysqlrow[FILEINFO_FNAME])
		strcpy(mysqldata.fname, mysqlrow[FILEINFO_FNAME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FPATH])
		strcpy(mysqldata.fpath, mysqlrow[FILEINFO_FPATH]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FPID])
		mysqldata.fpid = atol(mysqlrow[FILEINFO_FPID]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FSTATUS])
		mysqldata.fstatus = *mysqlrow[FILEINFO_FSTATUS];
	else
		mysqldata.fstatus = 'l';
	
	if(mysqlrow[FILEINFO_FTYPE])
		mysqldata.ftype = *mysqlrow[FILEINFO_FTYPE];
	else
		mysqldata.ftype = 'r';
	
	if(mysqlrow[FILEINFO_CURL])
		strcpy(mysqldata.curl, mysqlrow[FILEINFO_CURL]);
	else
		*mysqldata.curl = 0;
	
	if(mysqlrow[FILEINFO_FDEV])
		mysqldata.fdev = atol(mysqlrow[FILEINFO_FDEV]);
	else
		mysqldata.fdev = 0;
	
	if(mysqlrow[FILEINFO_FINO])
		mysqldata.fino = atol(mysqlrow[FILEINFO_FINO]);
	else
		mysqldata.fino = 0;
	
	if(mysqlrow[FILEINFO_FMODE])
		mysqldata.fmode = atol(mysqlrow[FILEINFO_FMODE]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FNLINKS])
		mysqldata.fnlinks = atol(mysqlrow[FILEINFO_FNLINKS]);
	else
		mysqldata.fnlinks = 0;
	
	if(mysqlrow[FILEINFO_FUID])
		mysqldata.fuid = atol(mysqlrow[FILEINFO_FUID]);
	else
		mysqldata.fuid = 0;
	
	if(mysqlrow[FILEINFO_FGID])
		mysqldata.fgid = atol(mysqlrow[FILEINFO_FGID]);
	else	
		mysqldata.fgid = 0;
	
	if(mysqlrow[FILEINFO_FRDEV])
		mysqldata.frdev = atol(mysqlrow[FILEINFO_FRDEV]);
	else
		mysqldata.frdev = 0;
	
	if(mysqlrow[FILEINFO_FSIZE])
		mysqldata.fsize = atol(mysqlrow[FILEINFO_FSIZE]);
	else
		mysqldata.fsize = 0;
	
	if(mysqlrow[FILEINFO_DSIZE])
		mysqldata.dsize = atol(mysqlrow[FILEINFO_DSIZE]);
	else
		mysqldata.dsize = 0;
	
	if(mysqlrow[FILEINFO_FADDR])
		strcpy(mysqldata.faddr, mysqlrow[FILEINFO_FADDR]);
	else
		*mysqldata.faddr = 0;
	
	if(mysqlrow[FILEINFO_FGEN])
		mysqldata.fgen = atol(mysqlrow[FILEINFO_FGEN]);
	else
		mysqldata.fgen = 0;
	
	if(mysqlrow[FILEINFO_ATIME])
		mysqldata.atime = atol(mysqlrow[FILEINFO_ATIME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_MTIME])
		mysqldata.mtime = atol(mysqlrow[FILEINFO_MTIME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_CTIME])
		mysqldata.ctime = atol(mysqlrow[FILEINFO_CTIME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_DBLKS])
		mysqldata.dblks = atol(mysqlrow[FILEINFO_DBLKS]);
	else
		status_flag = -3;
	
	return status_flag;
}

//清除mysqldata缓冲
void mysql_clear_mysqldata(){// ok
	mysqldata.fid = SQL_INT_NULL;// 0
	*mysqldata.fname = SQL_CHR_NULL;// 1
	*mysqldata.fpath = SQL_CHR_NULL;// 2
	mysqldata.fpid = SQL_INT_NULL;// 3
	mysqldata.fstatus = SQL_CHR_NULL;// 4
	mysqldata.ftype = SQL_CHR_NULL;// 5
	*mysqldata.curl = SQL_CHR_NULL;// 6
	mysqldata.fdev = SQL_INT_NULL;// 7
	mysqldata.fino = SQL_INT_NULL;// 8
	mysqldata.fmode = SQL_INT_NULL;// 9
	mysqldata.fnlinks = SQL_INT_NULL;// 10
	mysqldata.fuid = SQL_INT_NULL;// 11
	mysqldata.fgid = SQL_INT_NULL;// 12
	mysqldata.frdev = SQL_INT_NULL;// 13
	mysqldata.fsize = SQL_INT_NULL;// 14
	mysqldata.dsize = SQL_INT_NULL;// 15
	*mysqldata.faddr = SQL_CHR_NULL;// 16
	mysqldata.fgen = SQL_INT_NULL;// 17
	mysqldata.atime = SQL_INT_NULL;// 18
	mysqldata.mtime = SQL_INT_NULL;// 19
	mysqldata.ctime = SQL_INT_NULL;// 20
	mysqldata.dblks = SQL_INT_NULL;// 21
}

////清除mysqluserdata缓冲
void mysql_clear_mysqluserdata(){
	mysqluserdata.flag = SQL_INT_NULL;
	*(mysqluserdata.extenddata) = SQL_CHR_NULL;
}

//将mysqldata设置为初始值
void mysql_default_mysqldata(){// ok
	mysqldata.fid = 0;// 0
	strcpy(mysqldata.fname, "NULL");// 1
	strcpy(mysqldata.fpath, "NULL");// 2
	mysqldata.fpid = 0;// 3
	mysqldata.fstatus = 'l';// 4
	mysqldata.ftype = 'r';// 5
	strcpy(mysqldata.curl, "NULL");// 6
	mysqldata.fdev = 0;// 7
	mysqldata.fino = 0;// 8
	mysqldata.fmode = 0;// 9
	mysqldata.fnlinks = 0;// 10
	mysqldata.fuid = 0;// 11
	mysqldata.fgid = 0;// 12
	mysqldata.frdev = 0;// 13
	mysqldata.fsize = 0;// 14
	mysqldata.dsize = 0;// 15
	strcpy(mysqldata.faddr, "NULL");// 16
	mysqldata.fgen = 0;// 17
	mysqldata.atime = 0;// 18
	mysqldata.mtime = 0;// 19
	mysqldata.ctime = 0;// 20
	mysqldata.dblks = 0;// 21
}

//将mysqldata.fpath截断后赋值给mysqldata.fname
void mysql_set_fname_mysqldata(){// ok
	if(!(*mysqldata.fpath))
		return;
	
	//如果fpath最后一个字符为'/', 则去除这个字符
	if(mysqldata.fpath[strlen(mysqldata.fpath) - 1] == '/')
		mysqldata.fpath[strlen(mysqldata.fpath) - 1] = 0;
	
	char *tmp = strrchr(mysqldata.fpath, '/');
	if(!tmp)
		return;
	strcpy(mysqldata.fname, tmp + 1);
	return;
}

//将fattr3中的数据复制到mysqldata中, 会改变mysqldata数据
/*void mysql_cpy_fattr3_mysqldata(const char *path, const fattr3 *attr){
	ftype3 type;
	mode3 mode;
	uint32 nlink;
	uid3 uid;
	gid3 gid;
	size3 size;
	size3 used;
	specdata3 rdev;
	uint64 fsid;
	fileid3 fileid;
	nfstime3 atime;
	nfstime3 mtime;
	nfstime3 ctime;
}//*/

//将st_stat中的信息拷贝到mysqldata中, 会改变mysqldata数据
void mysql_cpy_stat_mysqldata(const char *path, const struct stat *st_stat){
	strcpy(mysqldata.fpath, path);//路径信息fpath
	mysql_set_fname_mysqldata();//fname
	mysqldata.fpid = mysql_get_fpid(path);//fpid
	//printf("get_fpid ok\n");//test zl
	mysqldata.fdev = (int64)(*st_stat).st_dev;
	mysqldata.fino = (*st_stat).st_ino;
	mysqldata.fmode = (*st_stat).st_mode;// 9
	mysqldata.fnlinks = (*st_stat).st_nlink;// 10
	mysqldata.fuid = (*st_stat).st_uid;// 11
	mysqldata.fgid = (*st_stat).st_gid;// 12
	mysqldata.frdev = (*st_stat).st_rdev;// 13
	mysqldata.fsize = (*st_stat).st_size;// 14
	mysqldata.dsize = (*st_stat).st_blksize;// 15
	mysqldata.atime = (*st_stat).st_atime;// 18
	mysqldata.mtime = (*st_stat).st_mtime;// 19
	mysqldata.ctime = (*st_stat).st_ctime;// 20
	mysqldata.dblks = (*st_stat).st_blocks;// 21
	
	if(S_ISDIR(mysqldata.fmode))
		mysqldata.ftype = 'd';
	return;
}//*/

//将st_stat中的部分信息拷贝到mysqldata中, 会改变mysqldata数据
void mysql_cpy_stattime_mysqldata(const char *path, const struct stat *st_stat){
	mysql_clear_mysqldata();
	strcpy(mysqldata.fpath, path);//路径信息fpath
	//将fpath变成父目录. zl
	char *tmp = strrchr(mysqldata.fpath, '/');
	if(tmp){
		*(tmp) = 0;
	}
	mysqldata.mtime = (*st_stat).st_mtime;// 19
	mysqldata.ctime = (*st_stat).st_ctime;// 20
printf("[sql] m:%ld\n[sql] c:%ld\n", mysqldata.mtime, mysqldata.ctime);//test. zl
}
