#! /bin/sh
mkdir nfsdir
sudo cp -f exports /etc/exports
read -p "Please input MySQL username : " user
read -p "Please input MySQL password : " pswd
read -p "Please input parent dir of server root dir : " pdrootdir

touch default_root_data.sql
echo "use gateway;" > default_root_data.sql
echo "insert into mapping(fid, fpath, fpid) values(0, '"$pdrootdir"', 0);" >> default_root_data.sql

mysql -u$user -p$pswd < gateway_mysql.sql
mysql -u$user -p$pswd < default_root_data.sql
