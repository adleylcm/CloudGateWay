#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include "mysql_data.h"

MYSQL mysql;
MYSQL_RES *mysqlres;
MYSQL_ROW mysqlrow;
char sql[SQL_LEN_MAX];//sql命令
mysqldatastru mysqldata;//此变量为extern

char current_dir[1024];
struct stat file_stat;

int mysql_data_init(const char *user, const char *passwd, const char *db){// ok
	if(mysql_init(&mysql) == NULL){
		printf("[error] MySQL init fail!\n");
		return -1;
	}
	if(mysql_real_connect(&mysql, "127.0.0.1", user, passwd, db, MYSQL_PORT, NULL, 0) == NULL){
		printf("[error] MySQL conn fail!\n");
		return -2;
	}
	
	mysqlres = NULL;
	printf("Mysql connected!\n");
	return 0;
}

int mysql_data_quit(){// ok
	mysql_close(&mysql);
	return 0;
}

int64 mysql_get_fpid(const char *fpath){// ok
	char tmppath[FILEINFO_FPATH_MAX];
	char *tmp;
	
	strcpy(tmppath, fpath);
	tmp = strrchr(tmppath, '/');
	if(tmp)
		*tmp = 0;
	else
		return -1;//tmp为NULL, 即路径中没有'/', 错误

	sprintf(sql, "select fid from mapping where fpath='%s'", tmppath);
	printf("%s\n", sql);// zl test
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	mysqlres = mysql_store_result(&mysql);
	if(mysqlres == NULL){
		printf("[error] Not paired data!\n");// zl
		printf("here\n");
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		printf("here\n");
		return -1;
	}
	return atol(mysqlrow[0]);
}

int64 mysql_mapping(int64 fid, char *fpath){// ok
	if(fid){//fid不为0表示根据fid查fpath
		sprintf(sql, "select fpath from fileinfo where fid=%ld", (long)fid);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		mysqlres = mysql_store_result(&mysql);
		if(mysqlres == NULL){
			return -1;
		}
		if(!(mysqlrow = mysql_fetch_row(mysqlres))){
			return -1;
		}
		strcpy(fpath, mysqlrow[0]);
		return 0;
	}else{//fid为0表示根据fpath查fid
		sprintf(sql, "select fid from mapping where fpath='%s'", fpath);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		mysqlres = mysql_store_result(&mysql);
		if(mysqlres == NULL){
			return -1;
		}
		if((mysqlrow = mysql_fetch_row(mysqlres))){
			return atol(mysqlrow[0]);
		}
		
		int64 tmpfpid = mysql_get_fpid(fpath);
		if(tmpfpid < 0)
			return -1;
		
		//查fpid = 父目录fid的所有文件
		sprintf(sql, "select fid,fpath from fileinfo where fpid=%ld", tmpfpid);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		mysqlres = mysql_store_result(&mysql);
		if(mysqlres == NULL){
			return -1;
		}
		while((mysqlrow = mysql_fetch_row(mysqlres))){
			if(strcmp(fpath, mysqlrow[1]) == 0){
				return atol(mysqlrow[0]);
			}
		}
		//都查不到
		return -1;
	}
}

//将mysqldata中的有效值存进mysql数据库中
int mysql_set_data(){// ok
	int64 tmpfid = 0;
	if((tmpfid = mysql_mapping(0, mysqldata.fpath)) >= 0){//已经存在记录, 只更新, 不创建
		printf("recond existed!\n");// zl test
		sprintf(sql, "update fileinfo set fpath='%s'", mysqldata.fpath);
		
		if(mysqldata.fstatus)
			sprintf(sql + strlen(sql), ",fstatus='%c'", mysqldata.fstatus);
		if(mysqldata.ftype)
			sprintf(sql + strlen(sql), ",ftype='%c'", mysqldata.ftype);
		if(*mysqldata.curl)
			sprintf(sql + strlen(sql), ",curl='%s'", mysqldata.curl);
		if(mysqldata.fdev)
			sprintf(sql + strlen(sql), ",fdev=%ld", mysqldata.fdev);
		if(mysqldata.fino)
			sprintf(sql + strlen(sql), ",fino=%ld", mysqldata.fino);
		if(mysqldata.fmode)
			sprintf(sql + strlen(sql), ",fmode=%ld", mysqldata.fmode);
		if(mysqldata.fnlinks)
			sprintf(sql + strlen(sql), ",fnlinks=%ld", mysqldata.fnlinks);
		if(mysqldata.fuid)
			sprintf(sql + strlen(sql), ",fuid=%ld", mysqldata.fuid);
		if(mysqldata.fgid)
			sprintf(sql + strlen(sql), ",fgid=%ld", mysqldata.fgid);
		if(mysqldata.frdev)
			sprintf(sql + strlen(sql), ",frdev=%ld", mysqldata.frdev);
		if(mysqldata.fsize)
			sprintf(sql + strlen(sql), ",fsize=%ld", mysqldata.fsize);
		if(mysqldata.dsize)
			sprintf(sql + strlen(sql), ",dsize=%ld", mysqldata.dsize);
		if(*mysqldata.faddr)
			sprintf(sql + strlen(sql), ",faddr='%s'", mysqldata.faddr);
		if(mysqldata.fgen)
			sprintf(sql + strlen(sql), ",fgen=%ld", mysqldata.fgen);
		if(mysqldata.atime)
			sprintf(sql + strlen(sql), ",atime=%ld", mysqldata.atime);
		if(mysqldata.mtime)
			sprintf(sql + strlen(sql), ",mtime=%ld", mysqldata.mtime);
		if(mysqldata.ctime)
			sprintf(sql + strlen(sql), ",ctime=%ld", mysqldata.ctime);
		if(mysqldata.dblks)
			sprintf(sql + strlen(sql), ",dblks=%ld", mysqldata.dblks);
		
		sprintf(sql + strlen(sql), " where fid=%ld", tmpfid);
		//printf("\n\n%s\n\n", sql);
	}else{//没有记录, 创建
		printf("recond not existed!\n");// zl test
		
		//printf("%c %c %c %c %d\n", *mysqldata.fname, *mysqldata.fpath, *mysqldata.curl, *mysqldata.faddr, 'N' && '/' && 'N');// zl test
		if(!(*mysqldata.fname && *mysqldata.fpath &&
			*mysqldata.curl && *mysqldata.faddr)){
			printf("All NULL\n");// zl test

			return -1;
		}
		
		mysqldata.fpid = mysql_get_fpid(mysqldata.fpath);
		//printf("[set data]get_fpid : %ld\n", mysqldata.fpid);
				printf("test\n");
		sprintf(sql, "insert into fileinfo(\
fname,\
fpath,\
fpid,\
fstatus,\
ftype,\
curl,\
fdev,\
fino,\
fmode,\
fnlinks,\
fuid,\
fgid,\
frdev,\
fsize,\
dsize,\
faddr,\
fgen,\
atime,\
mtime,\
ctime,\
dblks) \
values('%s','%s',%ld,'%c','%c','%s',%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,'%s',%ld,%ld,%ld,%ld,%ld)",
		mysqldata.fname,\
		mysqldata.fpath,\
		(long)mysqldata.fpid,\
		mysqldata.fstatus,\
		mysqldata.ftype,\
		mysqldata.curl,\
		(long)mysqldata.fdev,\
		(long)mysqldata.fino,\
		(long)mysqldata.fmode,\
		(long)mysqldata.fnlinks,\
		(long)mysqldata.fuid,\
		(long)mysqldata.fgid,\
		(long)mysqldata.frdev,\
		(long)mysqldata.fsize,\
		(long)mysqldata.dsize,\
		mysqldata.faddr,\
		(long)mysqldata.fgen,\
		(long)mysqldata.atime,\
		(long)mysqldata.mtime,\
		(long)mysqldata.ctime,\
		(long)mysqldata.dblks);
printf("sql:   %s\n", sql);
		if(S_ISDIR(mysqldata.fmode)){
			mysql_query(&mysql, sql);
			if(mysql_affected_rows(&mysql) == 0)
				return -1;
			tmpfid = (int64)mysql_insert_id(&mysql);
			printf("dir  %s\n", mysqldata.fpath);
			printf("dir  '%s'\n", mysqldata.fpath);
			sprintf(sql, "insert into mapping(fid, fpath, fpid) values(%ld, '%s', %ld)", (long)tmpfid, mysqldata.fpath, mysqldata.fpid);
			printf("insertsql:  %s\n", sql);
		}
	}
	mysql_query(&mysql, sql);
	if(mysql_affected_rows(&mysql) == 0){
		printf("not changed!\n");
		return -1;
	}
	return 0;
}

//从mysql中将信息读取到mysqldata缓冲中
int mysql_get_data(char *fpath){// ok
	if(!(fpath && *fpath))return -2;//路径错误
	
	int64 fid = 0;
	if(fpath[strlen(fpath) - 1] == '/'){//如果fpath中末位是'/', 要去除
		char tmpfpath[FILEINFO_FPATH_MAX];
		strcpy(tmpfpath, fpath);
		tmpfpath[strlen(tmpfpath) - 1] = 0;
		fid = mysql_mapping(0, tmpfpath);
	}else{
		fid = mysql_mapping(0, fpath);
	}
	mysql_clear_mysqldata();
	//fid,fname,fpath,fpid,fstatus,ftype,curl,fdev,fino,fmode,fnlinks,fuid,fgid,frdev,fsize,dsize,faddr,fgen,atime,mtime,ctime,dblks; 暂时这些信息, 如有其它字段, 一定要在结尾添加, 并且建立数据库时也要按相同的顺序
	sprintf(sql, "select * from fileinfo where fid=%ld", (long)fid);//21 zl
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	mysqlres = mysql_store_result(&mysql);
	if(mysqlres == NULL){
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	//strcpy(fpath, mysqlrow[0]);
	int status_flag = 0;
	if(mysqlrow[FILEINFO_FID])
		mysqldata.fid = atol(mysqlrow[FILEINFO_FID]);
	
	if(mysqlrow[FILEINFO_FNAME])
		strcpy(mysqldata.fname, mysqlrow[FILEINFO_FNAME]);
	else
		status_flag = -1;
	
	if(mysqlrow[FILEINFO_FPATH])
		strcpy(mysqldata.fpath, mysqlrow[FILEINFO_FPATH]);
	else
		status_flag = -1;
	
	if(mysqlrow[FILEINFO_FPID])
		mysqldata.fpid = atol(mysqlrow[FILEINFO_FPID]);
	else
		status_flag = -1;
	
	if(mysqlrow[FILEINFO_FSTATUS])
		mysqldata.fstatus = *mysqlrow[FILEINFO_FSTATUS];
	else
		mysqldata.fstatus = 'l';
	
	if(mysqlrow[FILEINFO_FTYPE])
		mysqldata.ftype = *mysqlrow[FILEINFO_FTYPE];
	else
		mysqldata.ftype = 'r';
	
	if(mysqlrow[FILEINFO_CURL])
		strcpy(mysqldata.curl, mysqlrow[FILEINFO_CURL]);
	else
		*mysqldata.curl = 0;
	
	if(mysqlrow[FILEINFO_FDEV])
		mysqldata.fdev = atol(mysqlrow[FILEINFO_FDEV]);
	else
		mysqldata.fdev = 0;
	
	if(mysqlrow[FILEINFO_FINO])
		mysqldata.fino = atol(mysqlrow[FILEINFO_FINO]);
	else
		mysqldata.fino = 0;
	
	if(mysqlrow[FILEINFO_FMODE])
		mysqldata.fmode = atol(mysqlrow[FILEINFO_FMODE]);
	else
		status_flag = -1;
	
	if(mysqlrow[FILEINFO_FNLINKS])
		mysqldata.fnlinks = atol(mysqlrow[FILEINFO_FNLINKS]);
	else
		mysqldata.fnlinks = 0;
	
	if(mysqlrow[FILEINFO_FUID])
		mysqldata.fuid = atol(mysqlrow[FILEINFO_FUID]);
	else
		mysqldata.fuid = 0;
	
	if(mysqlrow[FILEINFO_FGID])
		mysqldata.fgid = atol(mysqlrow[FILEINFO_FGID]);
	else	
		mysqldata.fgid = 0;
	
	if(mysqlrow[FILEINFO_FRDEV])
		mysqldata.frdev = atol(mysqlrow[FILEINFO_FRDEV]);
	else
		mysqldata.frdev = 0;
	
	if(mysqlrow[FILEINFO_FSIZE])
		mysqldata.fsize = atol(mysqlrow[FILEINFO_FSIZE]);
	else
		mysqldata.fsize = 0;
	
	if(mysqlrow[FILEINFO_DSIZE])
		mysqldata.dsize = atol(mysqlrow[FILEINFO_DSIZE]);
	else
		mysqldata.dsize = 0;
	
	if(mysqlrow[FILEINFO_FADDR])
		strcpy(mysqldata.faddr, mysqlrow[FILEINFO_FADDR]);
	else
		*mysqldata.faddr = 0;
	
	if(mysqlrow[FILEINFO_FGEN])
		mysqldata.fgen = atol(mysqlrow[FILEINFO_FGEN]);
	else
		mysqldata.fgen = 0;
	
	if(mysqlrow[FILEINFO_ATIME])
		mysqldata.atime = atol(mysqlrow[FILEINFO_ATIME]);
	else
		status_flag = -1;
	
	if(mysqlrow[FILEINFO_MTIME])
		mysqldata.mtime = atol(mysqlrow[FILEINFO_MTIME]);
	else
		status_flag = -1;
	
	if(mysqlrow[FILEINFO_CTIME])
		mysqldata.ctime = atol(mysqlrow[FILEINFO_CTIME]);
	else
		status_flag = -1;
	
	if(mysqlrow[FILEINFO_DBLKS])
		mysqldata.dblks = atol(mysqlrow[FILEINFO_DBLKS]);
	else
		status_flag = -1;
	
	printf("\nfid:%ld fname:%s fpath:%s fpid:%ld\
\nfstatus:%c ftype:%c curl:%s fdev:%ld\
\nfino:%ld fmode:%ld fnlinks:%ld fuid:%ld\
\nfgid:%ld frdev:%ld fsize:%ld dsize:%ld\
\nfaddr:%s fgen:%ld atime:%ld mtime:%ld\
\nctime:%ld dblks:%ld\n",
		(long)mysqldata.fid, mysqldata.fname, mysqldata.fpath, (long)mysqldata.fpid,
		mysqldata.fstatus, mysqldata.ftype, mysqldata.curl, (long)mysqldata.fdev,
		(long)mysqldata.fino, (long)mysqldata.fmode, (long)mysqldata.fnlinks,(long)mysqldata.fuid,
		(long)mysqldata.fgid, (long)mysqldata.frdev, (long)mysqldata.fsize, (long)mysqldata.dsize,
		mysqldata.faddr, (long)mysqldata.fgen, (long)mysqldata.atime, (long)mysqldata.mtime,
		(long)mysqldata.ctime, (long)mysqldata.dblks);// zl test
	
	return status_flag;
}

//清除mysqldata缓冲
void mysql_clear_mysqldata(){// ok
	mysqldata.fid = -1;// 0
	*mysqldata.fname = 0;// 1
	*mysqldata.fpath = 0;// 2
	mysqldata.fpid = -1;// 3
	mysqldata.fstatus = 0;// 4
	mysqldata.ftype = 0;// 5
	*mysqldata.curl = 0;// 6
	mysqldata.fdev = -1;// 7
	mysqldata.fino = -1;// 8
	mysqldata.fmode = -1;// 9
	mysqldata.fnlinks = -1;// 10
	mysqldata.fuid = -1;// 11
	mysqldata.fgid = -1;// 12
	mysqldata.frdev = -1;// 13
	mysqldata.fsize = -1;// 14
	mysqldata.dsize = -1;// 15
	*mysqldata.faddr = 0;// 16
	mysqldata.fgen = -1;// 17
	mysqldata.atime = -1;// 18
	mysqldata.mtime = -1;// 19
	mysqldata.ctime = -1;// 20
	mysqldata.dblks = -1;// 21
}

//将mysqldata设置为初始值
void mysql_default_mysqldata(){// ok
	mysqldata.fid = 0;// 0
	strcpy(mysqldata.fname, "NULL");// 1
	strcpy(mysqldata.fpath, "NULL");// 2
	mysqldata.fpid = 0;// 3
	mysqldata.fstatus = 'l';// 4
	mysqldata.ftype = 'r';// 5
	strcpy(mysqldata.curl, "NULL");// 6
	mysqldata.fdev = 0;// 7
	mysqldata.fino = 0;// 8
	mysqldata.fmode = 0;// 9
	mysqldata.fnlinks = 0;// 10
	mysqldata.fuid = 0;// 11
	mysqldata.fgid = 0;// 12
	mysqldata.frdev = 0;// 13
	mysqldata.fsize = 0;// 14
	mysqldata.dsize = 0;// 15
	strcpy(mysqldata.faddr, "NULL");// 16
	mysqldata.fgen = 0;// 17
	mysqldata.atime = 0;// 18
	mysqldata.mtime = 0;// 19
	mysqldata.ctime = 0;// 20
	mysqldata.dblks = 0;// 21
}

//将mysqldata.fpath截断后赋值给mysqldata.fname
void mysql_set_fname_mysqldata(){// ok
	if(!(*mysqldata.fpath))
		return;
	
	if(mysqldata.fpath[strlen(mysqldata.fpath) - 1] == '/')
		mysqldata.fpath[strlen(mysqldata.fpath) - 1] = 0;
	char *tmp = strrchr(mysqldata.fpath, '/');
	if(!tmp)
		return;
	strcpy(mysqldata.fname, tmp + 1);
	return;
}

//将cache中的信息拷贝到mysqldata中, 会改变mysqldata数据
void mysql_cpy_cache_mysqldata(const char *path){
	mysql_default_mysqldata();//初始化mysqldata
	strcpy(mysqldata.fpath, path);//路径信息fpath
	mysql_set_fname_mysqldata();//fname
	mysqldata.fpid = mysql_get_fpid(path);//fpid
	//printf("get_fpid ok, fpid = %ld\n", mysqldata.fpid);
	mysqldata.fdev = (int64)file_stat.st_dev;
	//printf("%ld*******\n", mysqldata.fdev);
	mysqldata.fino = file_stat.st_ino;
	mysqldata.fmode = file_stat.st_mode;// 9
	mysqldata.fnlinks = file_stat.st_nlink;// 10
	mysqldata.fuid = file_stat.st_uid;// 11
	mysqldata.fgid = file_stat.st_gid;// 12
	mysqldata.frdev = file_stat.st_rdev;// 13
	mysqldata.fsize = file_stat.st_size;// 14
	mysqldata.dsize = file_stat.st_blksize;// 15
	mysqldata.atime = file_stat.st_atime;// 18
	mysqldata.mtime = file_stat.st_mtime;// 19
	mysqldata.ctime = file_stat.st_ctime;// 20
	mysqldata.dblks = file_stat.st_blocks;// 21
	
	if(S_ISDIR(mysqldata.fmode))
		mysqldata.ftype = 'd';
	return;
}//*/

int trave_dir(char* path){
	DIR *dir;
	struct dirent *file;
	
	if(!(dir = opendir(path))){
		printf("error opendir %s!!!\n",path);
		return -1;
	}
	
	while((file = readdir(dir)) != NULL)
	{
		if( !strcmp(file->d_name, ".") || !strcmp(file->d_name, "..") )
			continue;
		
		printf("\n%s\n", strcat(current_dir, file->d_name));
		lstat(current_dir, &file_stat);
		
		//start
		mysql_cpy_cache_mysqldata(current_dir);
		mysql_set_data();
		//end
		
		strcat(current_dir, "/");
		if(S_ISDIR(file_stat.st_mode)){
			trave_dir(current_dir);
		}
		current_dir[strlen(current_dir) - 1] = 0;
		*(strrchr(current_dir, '/') + 1) = 0;
	}
	closedir(dir);
	return 0;
}

int main(int argc, char **argv){
	char *server_dir = "/home/gateway/nfsdir";
	int opt = 0;
    char *optstring = "hp:";

    while (opt != -1) {
		opt = getopt(argc, argv, optstring);
		switch (opt) {
			case 'p':
				server_dir = optarg;
				break;
			case 'h':
				printf("Usage: %s [options]\n", argv[0]);
				printf("\t-h          display this short option summary\n");
				printf("\t-p <path>   absolute path of NFSserver export dir\n");
				exit(0);
				break;
			case '?':
				exit(1);
				break;
			default:
				break;
		}
	}
	
	mysql_data_init("root", "111111", "gateway");// zl
	printf("Mysql init!\n");// zl
	
	lstat(server_dir, &file_stat);// zl
	mysql_cpy_cache_mysqldata(server_dir);
	mysql_set_data();
	
	strcpy(current_dir, server_dir);
	if(current_dir[strlen(current_dir) - 1] != '/'){
		strcat(current_dir, "/");
	}
	
	trave_dir(current_dir);
	return 0;
}
