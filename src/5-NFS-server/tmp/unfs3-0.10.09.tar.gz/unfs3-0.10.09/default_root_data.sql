use gateway;
insert into mapping(fid, fpath, fpid) values(0, '/home/gateway', 0);
