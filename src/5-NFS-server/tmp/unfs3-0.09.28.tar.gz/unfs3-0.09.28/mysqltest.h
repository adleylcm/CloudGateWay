﻿
#ifndef TEST_H
#define TEST_H

#include "nfs.h"

#define FILEINFO_FID 0
#define FILEINFO_FNAME 1
#define FILEINFO_FPATH 2
#define FILEINFO_FPID 3
#define FILEINFO_FSTATUS 4
#define FILEINFO_FTYPE 5
#define FILEINFO_CURL 6
#define FILEINFO_FDEV 7
#define FILEINFO_FINO 8
#define FILEINFO_FMODE 9
#define FILEINFO_FNLINKS 10
#define FILEINFO_FUID 11
#define FILEINFO_FGID 12
#define FILEINFO_FRDEV 13
#define FILEINFO_FSIZE 14
#define FILEINFO_DSIZE 15
#define FILEINFO_FADDR 16
#define FILEINFO_FGEN 17
#define FILEINFO_ATIME 18
#define FILEINFO_MTIME 19
#define FILEINFO_CTIME 20
#define FILEINFO_DBLKS 21

#define FILEINFO_FNAME_MAX 100
#define FILEINFO_FPATH_MAX 200
#define FILEINFO_CURL_MAX 200
#define SQL_LEN_MAX 800

struct mysqldatastru{
	int64 fid;// 0
	char fname[FILEINFO_FNAME_MAX];// 1
	char fpath[FILEINFO_FPATH_MAX];// 2
	int64 fpid;// 3
	char fstatus;// 4
	char ftype;// 5
	char curl[FILEINFO_CURL_MAX];// 6
	int64 fdev;// 7
	int64 fino;// 8
	int64 fmode;// 9
	int64 fnlinks;// 10
	int64 fuid;// 11
	int64 fgid;// 12
	int64 frdev;// 13
	int64 fsize;// 14
	int64 dsize;// 15
	char faddr[60];// 16
	int64 fgen;// 17
	int64 atime;// 18
	int64 mtime;// 19
	int64 ctime;// 20
	int64 dblks;// 21
};
typedef struct mysqldatastru mysqldatastru;


int mysql_data_init(const char *user, const char *passwd, const char *db);
int mysql_data_quit();

int64 mysql_get_fpid(const char *fpath);
int64 mysql_mapping(int64 fid, char *fpath);
int mysql_set_data();
int mysql_get_data(char *fpath);

void mysql_clear_mysqldata();
void mysql_default_mysqldata();
void mysql_set_fname_mysqldata();

void mysql_cpy_cache_mysqldata(const char *path);

#endif