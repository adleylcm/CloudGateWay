/*
 * mysql_metadata.c
 *
 *  Created on: 2013年11月15日
 *      Author: QL
 */

#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include "mysql_metadata.h"
#include "nfs.h"

MYSQL mysql;


/* --------------------------------
 * mysql初始化
 * --------------------------------
 * 用法: mysql_data_init("127.0.0.1", "root", "111111", "gateway");
 * 成功时返回MYSQL_INI，否则返回-1或-2
 */
int mysql_metadata_init(const char *ip, const char *user, const char *passwd, const char *db){// ok
	if(mysql_init(&mysql) == NULL){
		fprintf(stderr, "[error] MySQL init failed!\n");
		return -1;
	}
	if(mysql_real_connect(&mysql, ip, user, passwd, db, MYSQL_PORT, NULL, 0) == NULL){
		fprintf(stderr, "[error] MySQL conn failed!\n");
		return -2;
	}

	return MYSQL_INI;
}

/* --------------------------------
 * 关闭数据库
 * --------------------------------
 * 成功时返回MYSQL_QUIT
 */
int mysql_metadata_quit(){// ok
	mysql_close(&mysql);
	return MYSQL_QUIT;
}


/* --------------------------------
 * 通过fid查找该数据项是否存在
 * --------------------------------
 * 数据存在返回数据在mysql中的id号，否则返回NOTFOUND；
 * NOTFOUND =-1；
 */
int mysql_lookup_fid(int64_t fid){
	char sql[SQL_LEN_MAX];//sql命令
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

	sprintf(sql, "select fid from fileinfo where fid=%ld limit 1",\
			(long)fid);
	if (mysql_query(&mysql, sql)){
	  	fprintf(stderr, "[error] mysql error!\n");
	  	fprintf(stderr, " %s\n", mysql_error(&mysql));
	  	return NOTFOUND;
	}

	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}

	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return NOTFOUND;
	}

 	mysql_free_result(mysqlres);
	return FOUND;
}


/* --------------------------------
 * 通过fpath获取父目录id：fpid
 * --------------------------------
 * 成功时返回fpid，否则返回NOTFOUND；
 * NOTFOUND = -1;
 */
int64_t mysql_fpath2fpid(const char *fpath){
	char sql[SQL_LEN_MAX];//sql命令
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;
	char fpathTmp[FILEINFO_FPATH_MAX];
	char *pfpathTmp;

	strcpy(fpathTmp, fpath);

	pfpathTmp = strrchr(fpathTmp, '/');
	if(pfpathTmp)
		*pfpathTmp = '\0';
	else
		return NOTFOUND;//tmp为NULL, 即路径中没有'/', 错误

	sprintf(sql, "select fid from mapping where fpath='%s' limit 1",\
			fpathTmp);
	if (mysql_query(&mysql, sql)){
	  fprintf(stderr, "[error] mysql error!\n");
	  fprintf(stderr, " %s\n", mysql_error(&mysql));
	  return NOTFOUND;
	}

	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return NOTFOUND;
	}
	mysql_free_result(mysqlres);
	return atol(mysqlrow[0]);
}


/* --------------------------------
 * 将fpath转换为fid
 * --------------------------------
 * 转换成功返回fid，否则返回NOTFOUND；
 * NOTFOUND = -1;
 */
int64_t mysql_fpath2fid(const char *fpath){
	char sql[SQL_LEN_MAX];//sql命令
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

	//检测fpath是否为空
	if(!fpath)
		return NOTFOUND;

	sprintf(sql, "select fid from fileinfo where fpath='%s' limit 1", \
			fpath);
	if (mysql_query(&mysql, sql)){
	  fprintf(stderr, "[error] mysql error!\n");
	  fprintf(stderr, " %s\n", mysql_error(&mysql));
	  return NOTFOUND;
	}

	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return NOTFOUND;
	}
	mysql_free_result(mysqlres);
	return atol(mysqlrow[0]);
}


/* --------------------------------
 * 将fpath转换为fname
 * --------------------------------
 * 转换成功返回0，否则返回-1；
 */
int mysql_fpath2fname(const char *fpath, char *fname){
	char fpathTmp[FILEINFO_FPATH_MAX];

	if(!fpath)
		return -1;

	strcpy(fpathTmp, fpath);

	//如果fpath最后一个字符为'/', 则去除这个字符
	if(fpathTmp[strlen(fpathTmp) - 1] == '/')
		fpathTmp[strlen(fpathTmp) - 1] = 0;

	char *tmp = strrchr(fpathTmp, '/');
	if(!tmp)
		return -1;
	strcpy(fname, tmp + 1);
	return 0;
}


/* --------------------------------
 * 将fid转换为fpath
 * --------------------------------
 * 转换成功返回0，否则返回-1；
 */
int mysql_fid2fpath(int64_t fid, char *fpath){
	char sql[SQL_LEN_MAX];//sql命令
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

	//检测fpath是否为空
	if(!fpath)
		return -1;

	sprintf(sql, "select fpath from fileinfo where fid=%ld limit 1",\
			(long)fid);
	if (mysql_query(&mysql, sql)){
	  fprintf(stderr, "[error] mysql error!\n");
	  fprintf(stderr, " %s\n", mysql_error(&mysql));
	  return -1;
	}
	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	strcpy(fpath, mysqlrow[0]);
	mysql_free_result(mysqlres);
	return 0;
}

/* --------------------------------
 * 输入fid，将数据项删除
 * --------------------------------
 * 返回: 0-删除成功, -1-无此值, -2-输入错误
 */
int mysql_delete_metadata_by_fid(int64_t fid){
	char sql[SQL_LEN_MAX];//sql命令

	if(fid < 0)return -2;//输入错误

	sprintf(sql, "delete from fileinfo where fid=%ld", (long)fid);
	if (mysql_query(&mysql, sql)){
	  fprintf(stderr, "[error] mysql error!\n");
	  fprintf(stderr, " %s\n", mysql_error(&mysql));
	  return -1;
	}
	sprintf(sql, "delete from mapping where fid=%ld limit 1", (long)fid);
	if (mysql_query(&mysql, sql)){
	  fprintf(stderr, "[error] mysql error!\n");
	  fprintf(stderr, " %s\n", mysql_error(&mysql));
	  return -1;
	}
	return 0;
}


/* --------------------------------
 * 赋mysqlMetadata初值
 * --------------------------------
 * 返回: 0-成功
 */
int mysqlMetadataStruIni(mysqlMetadataStru *pMetadata){
	*pMetadata->fname = SQL_CHR_NULL;// 1
	*pMetadata->fpath = SQL_CHR_NULL;// 2
	pMetadata->fpid = SQL_INT_NULL;// 3
	pMetadata->fstatus = 'l';// 4
	pMetadata->ftype = 'r';// 5
//	*pMetadata->curl = SQL_CHR_NULL;// 6
	pMetadata->fdev = SQL_INT_NULL;// 7
	pMetadata->fino = SQL_INT_NULL;// 8
	pMetadata->fmode = SQL_INT_NULL;// 9
	pMetadata->fnlinks = SQL_INT_NULL;// 10
	pMetadata->fuid = SQL_INT_NULL;// 11
	pMetadata->fgid = SQL_INT_NULL;// 12
	pMetadata->frdev = SQL_INT_NULL;// 13
	pMetadata->fsize = SQL_INT_NULL;// 14
	pMetadata->dsize = SQL_INT_NULL;// 15
//	*pMetadata->faddr = SQL_CHR_NULL;// 16
	pMetadata->fgen = SQL_INT_NULL;// 17
	pMetadata->atime = SQL_INT_NULL;// 18
	pMetadata->mtime = SQL_INT_NULL;// 19
	pMetadata->ctime = SQL_INT_NULL;// 20
	pMetadata->dblks = SQL_INT_NULL;// 21
	return 0;
}

/* --------------------------------
 * 将输入的metadata保存到mysql
 * --------------------------------
 * 通过输入的metadata.fpath判断数据库是否有改数据项，有则更新，无则新建；
 */
int mysql_save_metadata(mysqlMetadataStru *pMetadata){
	char sql[SQL_LEN_MAX];//sql命令
	int64_t fidTmp = NOTFOUND;
	if(!pMetadata->fpath)return -2;//没有路径信息, mysqldata错误

	//去掉文件路径结尾的“/”
	if(pMetadata->fpath[strlen(pMetadata->fpath) - 1] == '/')
		pMetadata->fpath[strlen(pMetadata->fpath) - 1] = 0;

	fidTmp = mysql_fpath2fid(pMetadata->fpath);

	if(NOTFOUND != fidTmp){//已经存在记录, 只更新, 不创建
		sprintf(sql, "update fileinfo set fpath='%s'", pMetadata->fpath);
		if(pMetadata->fstatus != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",fstatus='%c'", pMetadata->fstatus);
		if(pMetadata->ftype != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",ftype='%c'", pMetadata->ftype);
//		if(pMetadata->curl != SQL_CHR_NULL)
//			sprintf(sql + strlen(sql), ",curl='%s'", pMetadata->curl);
		if(pMetadata->fdev != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fdev=%ld", (long)pMetadata->fdev);
		if(pMetadata->fino != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fino=%ld", (long)pMetadata->fino);
		if(pMetadata->fmode != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fmode=%ld", (long)pMetadata->fmode);
		if(pMetadata->fnlinks != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fnlinks=%ld", (long)pMetadata->fnlinks);
		if(pMetadata->fuid != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fuid=%ld", (long)pMetadata->fuid);
		if(pMetadata->fgid != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fgid=%ld", (long)pMetadata->fgid);
		if(pMetadata->frdev != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",frdev=%ld", (long)pMetadata->frdev);
		if(pMetadata->fsize != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fsize=%ld", (long)pMetadata->fsize);
		if(pMetadata->dsize != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",dsize=%ld", (long)pMetadata->dsize);
//		if(pMetadata->faddr != SQL_CHR_NULL)
//			sprintf(sql + strlen(sql), ",faddr='%s'", pMetadata->faddr);
		if(pMetadata->fgen != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fgen=%ld", (long)pMetadata->fgen);
		if(pMetadata->atime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",atime=%ld", (long)pMetadata->atime);
		if(pMetadata->mtime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",mtime=%ld", (long)pMetadata->mtime);
		if(pMetadata->ctime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",ctime=%ld", (long)pMetadata->ctime);
		if(pMetadata->dblks != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",dblks=%ld", (long)pMetadata->dblks);
	sprintf(sql + strlen(sql), " where fid=%ld limit 1", (long)fidTmp);
	}else{//没有记录, 创建
		mysql_fpath2fname(pMetadata->fpath, pMetadata->fname);
		pMetadata->fpid = mysql_fpath2fpid(pMetadata->fpath);
//		sprintf(sql, "insert into fileinfo(fname,fpath,fpid,fstatus,ftype,curl,fdev,fino,fmode,fnlinks,fuid,fgid,frdev,fsize,dsize,faddr,fgen,atime,mtime,ctime,dblks) values('%s','%s',%ld,'%c','%c','%s',%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,'%s',%ld,%ld,%ld,%ld,%ld)",pMetadata->fname, pMetadata->fpath, pMetadata->fpid, pMetadata->fstatus, pMetadata->ftype, pMetadata->curl, pMetadata->fdev, pMetadata->fino, (long)pMetadata->fmode, pMetadata->fnlinks, (long)pMetadata->fuid, (long)pMetadata->fgid, pMetadata->frdev, pMetadata->fsize, pMetadata->dsize, pMetadata->faddr, pMetadata->fgen, pMetadata->atime, pMetadata->mtime, pMetadata->ctime,pMetadata->dblks);
		sprintf(sql, "insert into fileinfo(fname,fpath,fpid,fstatus,"
				"ftype,fdev,fino,fmode,fnlinks,fuid,fgid,frdev,fsize,"
				"dsize,fgen,atime,mtime,ctime,dblks) "
				"values('%s','%s',%ld,'%c','%c',%ld,%ld,%ld,%ld,%ld,"
				"%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld)",\
				pMetadata->fname,	pMetadata->fpath,\
				(long)pMetadata->fpid,pMetadata->fstatus,\
				pMetadata->ftype,(long)pMetadata->fdev,\
				(long)pMetadata->fino,(long)pMetadata->fmode,\
				(long)pMetadata->fnlinks,(long)pMetadata->fuid,\
				(long)pMetadata->fgid,(long)pMetadata->frdev,\
				(long)pMetadata->fsize,(long)pMetadata->dsize,\
				(long)pMetadata->fgen,(long)pMetadata->atime,\
				(long)pMetadata->mtime,(long)pMetadata->ctime,\
				(long)pMetadata->dblks);
		if(S_ISDIR(pMetadata->fmode)){
			mysql_query(&mysql, sql);
			if(mysql_affected_rows(&mysql) == 0)
				return -1;
			fidTmp = (int64_t)mysql_insert_id(&mysql);
			sprintf(sql, "insert into mapping(fid, fpath, fpid)"
					" values(%ld, '%s', %ld)", \
					(long)fidTmp, pMetadata->fpath, (long)pMetadata->fpid);
		}
	}
	mysql_query(&mysql, sql);
//	printf("[sql] %s\n", sql);
	if(mysql_affected_rows(&mysql) == 0)
		return -1;
	return 0;
}


/* --------------------------------
 * 将系统调用返回的stat保存到mysql
 * --------------------------------
 */
int mysql_save_lstat(char *path){
	mysqlMetadataStru mysqlMetadata;
	mysqlMetadataStruIni(&mysqlMetadata);
	struct stat file_lstat;
	strcpy(mysqlMetadata.fpath, path);
	mysql_fpath2fname(path, mysqlMetadata.fname);
	mysqlMetadata.fpid = mysql_fpath2fpid(path);
	lstat(path, &file_lstat);
	mysqlMetadata.fdev = file_lstat.st_dev;
	mysqlMetadata.fino = file_lstat.st_ino;
	mysqlMetadata.fmode = file_lstat.st_mode;// 9
	mysqlMetadata.fnlinks = file_lstat.st_nlink;// 10
	mysqlMetadata.fuid = file_lstat.st_uid;// 11
	mysqlMetadata.fgid = file_lstat.st_gid;// 12
	mysqlMetadata.frdev = file_lstat.st_rdev;// 13
	mysqlMetadata.fsize = file_lstat.st_size;// 14
	mysqlMetadata.dsize = file_lstat.st_blksize;// 15
	mysqlMetadata.atime = file_lstat.st_atime;// 18
	mysqlMetadata.mtime = file_lstat.st_mtime;// 19
	mysqlMetadata.ctime = file_lstat.st_ctime;// 20
	mysqlMetadata.dblks = file_lstat.st_blocks;// 21

	if(S_ISDIR(mysqlMetadata.fmode))
		mysqlMetadata.ftype = 'd';
	mysql_save_metadata(&mysqlMetadata);

	return 0;
}

/* --------------------------------
 * mysql中的metadata数据读取出来
 * --------------------------------
 */

int mysql_get_metadata(mysqlMetadataStru *pMetadata,char *path){
	char sql[SQL_LEN_MAX];//sql命令
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

    sprintf(sql, "select * from fileinfo where fpath='%s' limit 1", path);
	if (mysql_query(&mysql, sql)){
	  fprintf(stderr, "[error] mysql error!\n");
	  fprintf(stderr, " %s\n", mysql_error(&mysql));
	  return NOTFOUND;
	}

	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return NOTFOUND;
	}

	if(mysqlrow[FILEINFO_FID])
		pMetadata->fid = atol(mysqlrow[FILEINFO_FID]);

	if(mysqlrow[FILEINFO_FNAME])
		strcpy(pMetadata->fname, mysqlrow[FILEINFO_FNAME]);

	if(mysqlrow[FILEINFO_FPATH])
		strcpy(pMetadata->fpath, mysqlrow[FILEINFO_FPATH]);

	if(mysqlrow[FILEINFO_FPID])
		pMetadata->fpid = atol(mysqlrow[FILEINFO_FPID]);

	if(mysqlrow[FILEINFO_FSTATUS])
		pMetadata->fstatus = *mysqlrow[FILEINFO_FSTATUS];
	else
		pMetadata->fstatus = 'l';

	if(mysqlrow[FILEINFO_FTYPE])
		pMetadata->ftype = *mysqlrow[FILEINFO_FTYPE];
	else
		pMetadata->ftype = 'r';

	if(mysqlrow[FILEINFO_FDEV])
		pMetadata->fdev = atol(mysqlrow[FILEINFO_FDEV]);
	else
		pMetadata->fdev = 0;

	if(mysqlrow[FILEINFO_FINO])
		pMetadata->fino = atol(mysqlrow[FILEINFO_FINO]);
	else
		pMetadata->fino = 0;

	if(mysqlrow[FILEINFO_FMODE])
		pMetadata->fmode = atol(mysqlrow[FILEINFO_FMODE]);

	if(mysqlrow[FILEINFO_FNLINKS])
		pMetadata->fnlinks = atol(mysqlrow[FILEINFO_FNLINKS]);
	else
		pMetadata->fnlinks = 0;

	if(mysqlrow[FILEINFO_FUID])
		pMetadata->fuid = atol(mysqlrow[FILEINFO_FUID]);
	else
		pMetadata->fuid = 0;

	if(mysqlrow[FILEINFO_FGID])
		pMetadata->fgid = atol(mysqlrow[FILEINFO_FGID]);
	else
		pMetadata->fgid = 0;

	if(mysqlrow[FILEINFO_FRDEV])
		pMetadata->frdev = atol(mysqlrow[FILEINFO_FRDEV]);
	else
		pMetadata->frdev = 0;

	if(mysqlrow[FILEINFO_FSIZE])
		pMetadata->fsize = atol(mysqlrow[FILEINFO_FSIZE]);
	else
		pMetadata->fsize = 0;

	if(mysqlrow[FILEINFO_DSIZE])
		pMetadata->dsize = atol(mysqlrow[FILEINFO_DSIZE]);
	else
		pMetadata->dsize = 0;

	if(mysqlrow[FILEINFO_FGEN])
		pMetadata->fgen = atol(mysqlrow[FILEINFO_FGEN]);
	else
		pMetadata->fgen = 0;

	if(mysqlrow[FILEINFO_ATIME])
		pMetadata->atime = atol(mysqlrow[FILEINFO_ATIME]);

	if(mysqlrow[FILEINFO_MTIME])
		pMetadata->mtime = atol(mysqlrow[FILEINFO_MTIME]);

	if(mysqlrow[FILEINFO_CTIME])
		pMetadata->ctime = atol(mysqlrow[FILEINFO_CTIME]);

	if(mysqlrow[FILEINFO_DBLKS])
		pMetadata->dblks = atol(mysqlrow[FILEINFO_DBLKS]);

	return 0;
}

post_op_attr mysql_get_nfs_post(const char *path, struct svc_req * req){
	post_op_attr result;

	if (mysql_get_data((char *)path) < 0){// 取值错误. zl
		printf("[mysql_get_nfs_post] error!\n");
		result.attributes_follow = FALSE;
	} else {// 取值正确. zl
		result.attributes_follow = TRUE;

		if (S_ISDIR(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3DIR;
		else if (S_ISBLK(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3BLK;
		else if (S_ISCHR(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3CHR;
#ifdef S_ISLNK
		else if (S_ISLNK(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3LNK;
#endif				       /* S_ISLNK */
#ifdef S_ISSOCK
		else if (S_ISSOCK(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3SOCK;
#endif				       /* S_ISSOCK */
		else if (S_ISFIFO(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3FIFO;
		else
			result.post_op_attr_u.attributes.type = NF3REG;

		/* adapt permissions for executable files */
		if (opt_readable_executables && S_ISREG(mysqldata.fmode)) {
			if (mysqldata.fmode & S_IXUSR)
				mysqldata.fmode |= S_IRUSR;
			if (mysqldata.fmode & S_IXGRP)
				mysqldata.fmode |= S_IRGRP;
			if (mysqldata.fmode & S_IXOTH)
				mysqldata.fmode |= S_IROTH;
		}
		result.post_op_attr_u.attributes.mode = (mode3)mysqldata.fmode & 0xFFFF;
		result.post_op_attr_u.attributes.nlink = (uint32)mysqldata.fnlinks;

//printf("getuid:%d geteuid:%d\n", getuid(), geteuid());
		/* If -s, translate uids */
		if (opt_singleuser) {
			unsigned int req_uid = 0;
			unsigned int req_gid = 0;
			struct authunix_parms *auth = (void *) req->rq_clntcred;

			if (req->rq_cred.oa_flavor == AUTH_UNIX) {
				req_uid = auth->aup_uid;
				req_gid = auth->aup_gid;
				result.post_op_attr_u.attributes.uid = req_uid;
				result.post_op_attr_u.attributes.gid = req_gid;
printf("[mysql_post] req_uid:%d gid:%d\n", req_uid, req_gid);
			} else {
				result.post_op_attr_u.attributes.uid = (uid3)mysqldata.fuid;
				result.post_op_attr_u.attributes.gid = (gid3)mysqldata.fgid;
			}
		} else {
			result.post_op_attr_u.attributes.uid = (uid3)mysqldata.fuid;
			result.post_op_attr_u.attributes.gid = (gid3)mysqldata.fgid;
		}

		result.post_op_attr_u.attributes.size = (size3)mysqldata.fsize;
		result.post_op_attr_u.attributes.used = (size3)mysqldata.dsize;

		result.post_op_attr_u.attributes.rdev.specdata1
				= ((uint32)mysqldata.frdev >> 8) & 0xFF;
		result.post_op_attr_u.attributes.rdev.specdata2
				= (uint32)mysqldata.frdev & 0xFF;

		result.post_op_attr_u.attributes.fsid = (uint64)mysqldata.fdev;
		result.post_op_attr_u.attributes.fileid = (fileid3)mysqldata.fino;

		result.post_op_attr_u.attributes.atime.seconds = (uint32)mysqldata.atime;
		result.post_op_attr_u.attributes.atime.nseconds = 0;
		result.post_op_attr_u.attributes.mtime.seconds = (uint32)mysqldata.mtime;
		result.post_op_attr_u.attributes.mtime.nseconds = 0;
		result.post_op_attr_u.attributes.ctime.seconds = (uint32)mysqldata.ctime;
		result.post_op_attr_u.attributes.ctime.nseconds = 0;
	}

	return result;
}


