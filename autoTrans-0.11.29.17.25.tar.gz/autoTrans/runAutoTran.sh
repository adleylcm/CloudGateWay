#! /bin/sh

dayofWeek=`mysql -u root -p111111 -D gateway -e "select dayofWeek from policy where id=0" | grep -v dayofWeek`
timeofDay=`mysql -u root -p111111 -D gateway -e "select timeofDay from policy where id=0" | grep -v timeofDay`

now_dayofWeek=`date +%w`
now_hour=`date +%H`
now_minute=`date +%M`
echo $timeofDay
if [ $dayofWeek -eq $now_dayofWeek -a $timeofDay -eq $now_hour ]; then
	echo ok;
fi