/*
 * mysqlData.h
 *
 *  Created on: 2013年11月26日
 *      Author: QL
 */

#ifndef MYSQLDATA_H_
#define MYSQLDATA_H_

#include <sys/types.h>
#include <sys/stat.h>

#define MYSQL_IP "127.0.0.1"
#define MYSQL_ROOT "root"
#define MYSQL_PASSWD "111111"
#define MYSQL_BD "gateway"

#define MYSQL_INI 0
#define MYSQL_QUIT 0
#define FOUND 1
#define NOTFOUND -1

#define SQL_INT_NULL -1
#define SQL_CHR_NULL 'N'

#define FILEINFO_FNAME_MAX 100
#define FILEINFO_FPATH_MAX 200
#define FILEINFO_CURL_MAX 200
#define SQL_LEN_MAX 800
#define SHELL_LEN_MAX 800

extern MYSQL mysql;

struct mysqlPolicyStru{
	int flagsize;
	int flagtype;
	int flagexpires;
	int flagfreq;
	int dayofWeek;
	int timeofDay;
	off_t fileSizeth;
	char fileType[1024];
	int64_t expires;
	int64_t freq;
	char ipaddr[100];
	char user[100];
	char passwd[50];
};
typedef struct mysqlPolicyStru mysqlPolicyStru;

/* --------------------------------
 * mysql_data_init()mysql初始化
 * --------------------------------
 * 用法: mysql_data_init("127.0.0.1", "root", "111111", "gateway");
 * 成功时返回MYSQL_INI，否则返回-1或-2								*/
int mysql_metadata_init(const char *ip, const char *user, const char *passwd, const char *db);


//mysql_metadata_quit()关闭数据库
//成功时返回MYSQL_QUIT
int mysql_metadata_quit();

// 初始化mysqlPolicydata
int mysqlPolicyStruIni(mysqlPolicyStru *pPolicy);

// mysql的policy表数据读取出来
int mysql_get_policy(mysqlPolicyStru *pPolicy);

//根据文件阈值自动上传
int autoTrans_size(off_t defFsize);

//根据使用频率阈值自动上传
int autoTrans_freq(int64_t defFreq);

//根据访问时间阈值自动上传
int autoTrans_expires(int64_t defExpires);

#endif /* MYSQLDATA_H_ */
