#! /bin/sh

dayofWeek=`mysql -u root -p111111 -D gateway -e "select dayofWeek from policy where id=0" | grep -v dayofWeek`
timeofDay=`mysql -u root -p111111 -D gateway -e "select timeofDay from policy where id=0" | grep -v timeofDay`

echo "0	$timeofDay	*	*	$dayofWeek	$PWD/autoTrans">$PWD/cronRunAutoTrans

crontab ./cronRunAutoTrans -u gateway