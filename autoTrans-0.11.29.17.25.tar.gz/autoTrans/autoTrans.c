/*
 * autoTrans.c
 *
 *  Created on: 2013年11月26日
 *      Author: QL
 */

#include <stdlib.h>
#include <stdio.h>
#include <mysql/mysql.h>
#include "mysqlData.h"

int main(int argc, char **argv){
	mysqlPolicyStru mysqlPolicy;

	mysqlPolicyStruIni(&mysqlPolicy);

	//初始化Mysql
	if( MYSQL_INI == mysql_metadata_init(MYSQL_IP, MYSQL_ROOT, MYSQL_PASSWD, MYSQL_BD))
		printf("Mysql init.\n");
	else{
		fprintf(stderr, "[error] MySQL init failed!\n");
		exit(EXIT_FAILURE);
	}

	//读取policy表
	mysql_get_policy(&mysqlPolicy);

	//根据文件大小阈值自动上传
	if(mysqlPolicy.flagsize)
		autoTrans_size(mysqlPolicy.fileSizeth);

	//根据使用频率阈值自动上传
	if(mysqlPolicy.flagfreq)
		autoTrans_freq(mysqlPolicy.freq);

	//根据访问时间阈值自动上传
	if(mysqlPolicy.expires)
		autoTrans_expires(mysqlPolicy.expires);

	// 退出Mysql
	if(MYSQL_QUIT == mysql_metadata_quit())
		printf("Mysql quit.\n");
	else
		fprintf(stderr, "[error] MySQL quit failed!\n");

	//退出程序
	exit(EXIT_SUCCESS);
}
