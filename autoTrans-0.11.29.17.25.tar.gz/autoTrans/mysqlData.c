/*
 * mysqlData.c
 *
 *  Created on: 2013年11月26日
 *      Author: QL
 */


#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include "mysqlData.h"

MYSQL mysql;

/* --------------------------------
 * mysql初始化
 * --------------------------------
 * 用法: mysql_data_init("127.0.0.1", "root", "111111", "gateway");
 * 成功时返回MYSQL_INI，否则返回-1或-2
 */
int mysql_metadata_init(const char *ip, const char *user, const char *passwd, const char *db){// ok
	if(mysql_init(&mysql) == NULL){
		fprintf(stderr, "[error] MySQL init failed!\n");
		return -1;
	}
	if(mysql_real_connect(&mysql, ip, user, passwd, db, MYSQL_PORT, NULL, 0) == NULL){
		fprintf(stderr, "[error] MySQL conn failed!\n");
		return -2;
	}

	return MYSQL_INI;
}

/* --------------------------------
 * 关闭数据库
 * --------------------------------
 * 成功时返回MYSQL_QUIT
 */
int mysql_metadata_quit(){// ok
	mysql_close(&mysql);
	return MYSQL_QUIT;
}


/* --------------------------------
 * 赋mysqlPolicy初值
 * --------------------------------
 * 返回: 0-成功
 */
int mysqlPolicyStruIni(mysqlPolicyStru *pPolicy){
	pPolicy->flagsize = SQL_INT_NULL;
	pPolicy->flagtype = SQL_INT_NULL;
	pPolicy->flagexpires = SQL_INT_NULL;
	pPolicy->flagfreq = SQL_INT_NULL;
	pPolicy->dayofWeek = SQL_INT_NULL;
	pPolicy->timeofDay = SQL_INT_NULL;
	pPolicy->fileSizeth = SQL_INT_NULL;
//	strcmp(pPolicy->fileType,SQL_CHR_NULL);
//	*pPolicy->fileType = SQL_CHR_NULL;
	pPolicy->expires = SQL_INT_NULL;
	pPolicy->freq = SQL_INT_NULL;
//	strcmp(pPolicy->ipaddr,SQL_CHR_NULL);
//	strcmp(pPolicy->user,SQL_CHR_NULL);
//	strcmp(pPolicy->passwd,SQL_CHR_NULL);
//	*pPolicy->ipaddr = SQL_CHR_NULL;
//	*pPolicy->user = SQL_CHR_NULL;
//	*pPolicy->passwd = SQL_CHR_NULL;
	return 0;
}

//读取policy数据表中的数据
int mysql_get_policy(mysqlPolicyStru *pPolicy){
	char sql[SQL_LEN_MAX];//sql命令
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

	sprintf(sql,"select * from policy");
	if (mysql_query(&mysql,sql)){
		fprintf(stderr, "[error] mysql error!\n");
	  	fprintf(stderr, " %s\n", mysql_error(&mysql));
	  return NOTFOUND;
	}

	if ( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}

	if ( (mysqlrow = mysql_fetch_row(mysqlres)) == NULL){
		return NOTFOUND;
	}

	if (mysqlrow[1])
		pPolicy->flagsize = atol(mysqlrow[1]);
	if (mysqlrow[2])
		pPolicy->flagtype = atol(mysqlrow[2]);
	if (mysqlrow[3])
		pPolicy->flagexpires = atol(mysqlrow[3]);
	if (mysqlrow[4])
		pPolicy->flagfreq = atol(mysqlrow[4]);
	if (mysqlrow[5])
		pPolicy->dayofWeek = atol(mysqlrow[5]);
	if (mysqlrow[6])
		pPolicy->timeofDay = atol(mysqlrow[6]);
	if (mysqlrow[7])
		pPolicy->fileSizeth = atol(mysqlrow[7]);
	if (mysqlrow[8])
		strcmp(pPolicy->fileType,mysqlrow[8]);
	if (mysqlrow[9])
		pPolicy->expires = atol(mysqlrow[9]);
	if (mysqlrow[10])
		pPolicy->freq = atol(mysqlrow[10]);
	if (mysqlrow[11])
		strcmp(pPolicy->ipaddr,mysqlrow[11]);
	if (mysqlrow[12])
		strcmp(pPolicy->user,mysqlrow[12]);
	if (mysqlrow[13])
		strcmp(pPolicy->passwd,mysqlrow[13]);
	return 0;
}

//根据文件阈值自动上传
int autoTrans_size(off_t defFsize){
	//查找符合条件的文件名
	char sql[SQL_LEN_MAX];//sql命令
	char shell_cmd[SHELL_LEN_MAX];
	int i;
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

	//非目录、本地文件、大小大于阈值
	sprintf(sql, "select fpath from fileinfo where ftype='r' and fsize>=%ld and fstatus='l'",\
			(long)defFsize*1024*1024);
	if (mysql_query(&mysql, sql)){
		fprintf(stderr, "[error] mysql error!\n");
		fprintf(stderr, " %s\n", mysql_error(&mysql));
		return NOTFOUND;
	}

	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}

	printf("autoTrans by defFsize=%ld\n",defFsize);
	while(mysqlrow = mysql_fetch_row(mysqlres)){
		sprintf(shell_cmd, "/home/gateway/swiftclientC/swiftclientc -a -p %s",mysqlrow[0]);
		system(shell_cmd);
	}

	mysql_free_result(mysqlres);
	return FOUND;
	//上传文件
}

//根据使用频率阈值自动上传
int autoTrans_freq(int64_t defFreq){
	//查找符合条件的文件名
	char sql[SQL_LEN_MAX];//sql命令
	char shell_cmd[SHELL_LEN_MAX];
	int i;
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

	//非目录、本地文件、使用频率小于阈值
	sprintf(sql, "select fpath from fileinfo where ftype='r' and usedCNT<=%ld and fstatus='l'",\
			(long)defFreq);
	if (mysql_query(&mysql, sql)){
		fprintf(stderr, "[error] mysql error!\n");
		fprintf(stderr, " %s\n", mysql_error(&mysql));
		return NOTFOUND;
	}

	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}

	printf("autoTrans by defFreq=%ld\n",defFreq);
	while(mysqlrow = mysql_fetch_row(mysqlres)){
		sprintf(shell_cmd, "/home/gateway/swiftclientC/swiftclientc -a -p %s",mysqlrow[0]);
		system(shell_cmd);
	}

	mysql_free_result(mysqlres);
	return FOUND;
	//上传文件
}

//根据访问时间阈值自动上传
int autoTrans_expires(int64_t defExpires){
	//查找符合条件的文件名
	char sql[SQL_LEN_MAX];//sql命令
	char shell_cmd[SHELL_LEN_MAX];
	int i;
	MYSQL_RES *mysqlres;
	MYSQL_ROW mysqlrow;

	//非目录、本地文件、最后访问时间大于阈值
	sprintf(sql, "select fpath from fileinfo where ftype='r' and usedCNT<=%ld and fstatus='l'",\
			(long)defExpires);
	if (mysql_query(&mysql, sql)){
		fprintf(stderr, "[error] mysql error!\n");
		fprintf(stderr, " %s\n", mysql_error(&mysql));
		return NOTFOUND;
	}

	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return NOTFOUND;
	}

	printf("autoTrans by defExpires=%ld\n",defExpires);
	while(mysqlrow = mysql_fetch_row(mysqlres)){
		sprintf(shell_cmd, "/home/gateway/swiftclientC/swiftclientc -a -p %s",mysqlrow[0]);
		system(shell_cmd);
	}

	mysql_free_result(mysqlres);
	return FOUND;
	//上传文件
}
