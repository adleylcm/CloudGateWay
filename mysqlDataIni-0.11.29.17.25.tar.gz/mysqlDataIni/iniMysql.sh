#! /bin/sh

mysqlUser="root"
mysqlPswd=111111

# 新建各个数据表
mysql -u$mysqlUser -p$mysqlPswd < mysqlGatewayDBIni.sql

# 初始化fileifo、mapping两个表
./mysqlMetadataIni

# 初始化analyse表
mysql -u$mysqlUser -p$mysqlPswd < mysqlAnalyseTabIni.sql