﻿/*
 * mysql_metadata, 2013-10-30, by QL <liqilihaha@foxmail.com>
 *
 * 功能: 提供目录信息在mysql中存取的便捷接口
 */

#ifndef MYSQL_METADATA_H
#define MYSQL_METADATA_H

#include <sys/types.h>
#include <sys/stat.h>

#define MYSQL_IP "localhost"
#define MYSQL_ROOT "root"
#define MYSQL_PASSWD "111111"
#define MYSQL_BD "gateway"

#define MYSQL_INI 0
#define MYSQL_QUIT 0
#define FOUND 1
#define NOTFOUND -1


#define FILEINFO_FID 0
#define FILEINFO_FNAME 1
#define FILEINFO_FPATH 2
#define FILEINFO_FPID 3
#define FILEINFO_FSTATUS 4
#define FILEINFO_FTYPE 5
#define FILEINFO_CURL 6
#define FILEINFO_FDEV 7
#define FILEINFO_FINO 8
#define FILEINFO_FMODE 9
#define FILEINFO_FNLINKS 10
#define FILEINFO_FUID 11
#define FILEINFO_FGID 12
#define FILEINFO_FRDEV 13
#define FILEINFO_FSIZE 14
#define FILEINFO_DSIZE 15
#define FILEINFO_FADDR 16
#define FILEINFO_FGEN 17
#define FILEINFO_ATIME 18
#define FILEINFO_MTIME 19
#define FILEINFO_CTIME 20
#define FILEINFO_DBLKS 21

#define SQL_INT_NULL -1
#define SQL_CHR_NULL 'N'

#define FILEINFO_FNAME_MAX 100
#define FILEINFO_FPATH_MAX 200
#define FILEINFO_CURL_MAX 200
#define SQL_LEN_MAX 800

struct mysqlMetadataStru{
	int64_t fid;// 0
	char fname[FILEINFO_FNAME_MAX];// 1
	char fpath[FILEINFO_FPATH_MAX];// 2
	int64_t fpid;// 3
	char fstatus;// 4
	char ftype;// 5
	char curl[FILEINFO_CURL_MAX];// 6
	dev_t fdev;// 7
	ino_t fino;// 8
	mode_t fmode;// 9
	nlink_t fnlinks;// 10
	uid_t fuid;// 11
	gid_t fgid;// 12
	dev_t frdev;// 13
	off_t fsize;// 14
	blksize_t dsize;// 15
//	char faddr[60];// 16
	time_t fgen;// 17
	time_t atime;// 18
	time_t mtime;// 19
	time_t ctime;// 20
	blkcnt_t dblks;// 21
};
typedef struct mysqlMetadataStru mysqlMetadataStru;

struct mysqlTranslogStru{
	long int tdate;//转存时间
	char *tfname;//转存文件名
	char *tfpath;//转存文件的绝对路径
	char tmethod;//转存方式：本地到云端/云端到本地
	char tstrategy;//手动转存/自动转存
	int tfsize;//文件大小
	int time;//转存耗时
};
typedef struct mysqlTranslogStru mysqlTranslogStru;

struct mysqlFrequencyStru{
	time_t date;//转存日期
	int64_t uploadCNT;//上传次数
	int64_t uploadSize;
	int64_t downloadCNT;
	int64_t downloadSize;
};
typedef struct mysqlFrequencyStru mysqlFrequencyStru;

struct mysqlAnalyseStru{
	int64_t cloudUsed;
	int64_t cloudTotal;
	int64_t localUsed;
	int64_t localTotal;
};
typedef struct mysqlAnalyseStru mysqlAnalyseStru;

/* --------------------------------
 * mysql_data_init()mysql初始化
 * --------------------------------
 * 用法: mysql_data_init("127.0.0.1", "root", "111111", "gateway");
 * 成功时返回MYSQL_INI，否则返回-1或-2
 */
int mysql_metadata_init(const char *ip, const char *user, const char *passwd, const char *db);


/* --------------------------------
 * mysql_metadata_quit()关闭数据库
 * --------------------------------
 * 成功时返回MYSQL_QUIT
 */
int mysql_metadata_quit();

/* --------------------------------
 * mysql_lookup_metadata_by_fid()通过fid查找该数据项是否存在
 * --------------------------------
 * 数据存在返回FOUND，否则返回NOTFOUND；
 * FOUND = 1; NOTFOUND =0；
 */
int mysql_lookup_fid(int64_t fid);


/* --------------------------------
 * 将fpath转换为fid
 * --------------------------------
 * 转换成功返回fid，否则返回-1；
 */
int64_t mysql_fpath2fid(const char *fpath);

/* --------------------------------
 * mysql_get_fpid()通过fpath获取父目录id：fpid
 * --------------------------------
 * 成功时返回fpid，否则返回-1；
 */
int64_t mysql_fpath2fpid(const char *fpath);

/* --------------------------------
 * mysql_fid2fpath()将fid转换为fpath
 * --------------------------------
 * 转换成功返回0，否则返回-1；
 */
int mysql_fid2fpath(int64_t fid, char *fpath);


/* --------------------------------
 * mysql_fpath2fname()将fpath转换为fname
 * --------------------------------
 * 转换成功返回0，否则返回-1；
 */
int mysql_fpath2fname(const char *fpath, char *fname);

/* --------------------------------
 * mysql_lookup_metadata_by_fpath()通过fpath查找该数据项是否存在
 * --------------------------------
 * 数据存在返回FOUND，否则返回NOTFOUND；
 * FOUND = 1; NOTFOUND =0；
 */
int64_t mysql_fpath2id(const char *fpath);

/* --------------------------------
 * mysql_delete_metadata_by_fid()输入fid，将数据项删除
 * --------------------------------
 * 返回: 0-删除成功, -1-无此值, -2-输入错误
 */
int mysql_delete_metadata_by_fid(int64_t fid);

/* --------------------------------
 * 初始化mysqlMetadata
 * --------------------------------
 */
int mysqlMetadataStruIni(mysqlMetadataStru *pMetadata);

/* --------------------------------
 * mysqlFrequencydata 
 * --------------------------------
 */
int mysqlFrequencyStruIni(mysqlFrequencyStru *pFrequency);

/* --------------------------------
 * mysqlFrequencydata 
 * --------------------------------
 */
int mysqlAnalyseStruIni(mysqlAnalyseStru *pAnalyse);
/* --------------------------------
 * 将输入的metadata保存到mysql
 * --------------------------------
 * 通过输入的metadata.fpath判断数据库是否有改数据项，有则更新，无则新建；
 */
int mysql_save_metadata(mysqlMetadataStru *pMetadata);

/* --------------------------------
 * 将系统调用返回的stat保存到mysql
 * --------------------------------
 */
int mysql_save_lstat(char *path);

/* --------------------------------
 * mysql中的metadata数据读取出来
 * --------------------------------
 */
int mysql_get_metadata(mysqlMetadataStru *pMetadata,char *path);


int mysql_save_translog(mysqlTranslogStru *pTranslog);

int mysql_save_analyse(mysqlAnalyseStru *pAnalyse);

int mysql_save_frequency(mysqlFrequencyStru *pFrequency);

int mysql_get_frequency(mysqlFrequencyStru *pFrequency);



#endif
