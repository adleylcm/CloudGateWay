-- 主机: localhost
-- 生成日期: 2013 年 11 月 06 日 21:59

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

-- --------------------------------------------------------
-- 清空数据库: `gateway`

drop database if EXISTS gateway;
create database gateway;
use gateway;

-- --------------------------------------------------------
--  `analyse` 使用空间统计

CREATE TABLE IF NOT EXISTS `analyse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cloudUsed` bigint(20) NOT NULL,
  `cloudTotal` bigint(20) NOT NULL,
  `localUsed` bigint(20) NOT NULL,
  `localTotal` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------
-- `fileinfo`文件属性表

CREATE TABLE IF NOT EXISTS `fileinfo` (
  `fid` bigint(20) NOT NULL AUTO_INCREMENT,
  `fname` varchar(500) NOT NULL,
  `fpath` varchar(500) NOT NULL,
  `fpid` bigint(20) NOT NULL,
  `fstatus` char(1) NOT NULL,
  `ftype` char(1) NOT NULL,
  `curl` varchar(500) DEFAULT "NULL",
  `fdev` bigint(20) DEFAULT NULL,
  `fino` bigint(20) DEFAULT NULL,
  `fmode` bigint(20) NOT NULL,
  `fnlinks` bigint(20) DEFAULT NULL,
  `fuid` bigint(20) NOT NULL,
  `fgid` bigint(20) NOT NULL,
  `frdev` bigint(20) DEFAULT NULL,
  `fsize` bigint(20) NOT NULL,
  `dsize` bigint(20) DEFAULT NULL,
  `faddr` varchar(60) DEFAULT NULL,
  `fgen` bigint(20) DEFAULT NULL,
  `atime` bigint(20) NOT NULL,
  `mtime` bigint(20) NOT NULL,
  `ctime` bigint(20) NOT NULL,
  `dblks` bigint(20) NOT NULL,
  `usedCNT` bigint(20) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------
-- `mapping`文件目录表

CREATE TABLE IF NOT EXISTS `mapping` (
  `fid` bigint(20) NOT NULL,
  `fpath` varchar(500) NOT NULL,
  `fpid` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- `frequency`转存频率统计表

CREATE TABLE IF NOT EXISTS `frequency` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `uploadCNT` int(11) NOT NULL,
  `uploadSize` int(11) NOT NULL,
  `downloadCNT` int(11) NOT NULL,
  `downloadSize` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------
-- `policy`转存策略表

CREATE TABLE IF NOT EXISTS `policy` (
  `id` int(11) NOT NULL,
  `flagsize` int(1) NOT NULL,
  `flagtype` int(1) NOT NULL,
  `flagexpires` int(1) NOT NULL,
  `flagfreq` int(1) NOT NULL,
  `dayofWeek` int(1) NOT NULL,
  `timeofDay` int(2) NOT NULL,
  `fileSizeth` int(11) NOT NULL,
  `fileType` varchar(1024) NOT NULL,
  `expires` bigint(20) NOT NULL,
  `freq` int(11) NOT NULL,
  `ipaddr` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- `translog`转存日志表

CREATE TABLE IF NOT EXISTS `translog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tfname` varchar(50) NOT NULL,
  `tfsize` int(11) NOT NULL,
  `tmethod` char(1) NOT NULL,
  `time` time NOT NULL,
  `tstrategy` char(1) NOT NULL,
  `tpath` varchar(50) NOT NULL,
  `tdate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------
-- 初始化`mapping`表中的数据 

insert into mapping(fid, fpath, fpid) values(0, '/home/gateway', 0);

-- --------------------------------------------------------
-- 初始化`analyse`表中的数据 

INSERT INTO `analyse` (`id`, `cloudUsed`, `cloudTotal`, `localUsed`, `localTotal`) VALUES
(1, 0, 107374182400, 0, 107374182400);

-- --------------------------------------------------------
-- 初始化`policy`表中的数据 

INSERT INTO `policy` (`id`, `flagsize`, `flagtype`, `flagexpires`, `flagfreq`, `dayofWeek`, `timeofDay`, `fileSizeth`, `fileType`, `expires`, `freq`, `ipaddr`, `user`, `passwd`) VALUES
(0, 1, 0, 1, 1, 0, 2, 5, '', 7, 4, '192.168.3.9:5000/v2.0', 'swift', '111111');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
