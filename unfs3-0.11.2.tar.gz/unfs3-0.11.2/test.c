﻿
/*
 * Just for test, no meaning
 * (C) 2013.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "test.h"

int show_time(){
	time_t timep;
	time(&timep);
	
	long ts = time(NULL);
	struct tm *ptm = localtime(&ts);
	
	printf("ctime is:   %s",ctime(&timep));
	printf("asctime is: %s\n",asctime(ptm));
	return 0;
}

void show_attr(const char *path, int i){

	struct stat st_cache;
	
	do{
		sleep(1);
		lstat(path, &st_cache);
		printf("path:%s fdev:%ld fino:%ld fmode:%ld \
frdev:%ld fsize:%ld atime:%ld mtime:%ld ctime:%ld dblks:%ld\n",
			path, st_cache.st_dev, st_cache.st_ino, st_cache.st_mode, 
			st_cache.st_rdev, st_cache.st_size, st_cache.st_atime,
			st_cache.st_mtime, st_cache.st_ctime, st_cache.st_blocks);// zl test
	}while(--i != 0);
}

char *init_time(){
	static time_t now;
	static struct tm  *timenow;
	time(&now);
	timenow = localtime(&now);
	while (1) {
		printf("\033[1m%s\033[0m",asctime(timenow));
		sleep(1);
	}// return 0;
	return asctime(timenow);
}

void print_time(char *time_str){
	printf("%s", time_str);
	return;
}

int main(int argc, char *argv[]){
	char *xx = init_time();
	while (1) {
		print_time(xx);
		sleep(1);
	}
	
	char *path;
	int show_times;
	if(argc < 3){
		path = "/home/unfs3/server/testfile";
		show_times = 0;
	}else{
		path = argv[1];
		show_times = atoi(argv[2]);
	}
	
	//show_time();
	
	show_attr(path, show_times);
	
	int fd;
	char tmp[20];
	if((fd = open(path, O_WRONLY | O_NONBLOCK)) >= 0){
		printf("\nOpen!\n\n");
		pread(fd, tmp, 10, 0);
		//printf("%s\n", tmp);
		close(fd);
	}
	
	show_attr(path, show_times);
	
	/*system("cat /home/unfs3/build/Makefile");
	printf("Done\n");//*/
	
	//
	
	return 0;
}
