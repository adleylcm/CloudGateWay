﻿/*
 * Adding local file information to mysql database tool
 * (C) 2013, Lin Zhong
 * see file LICENSE for license details
 */
 
#ifndef TEST_CHECK_LOCAL_H_
#define TEST_CHECK_LOCAL_H_

#endif