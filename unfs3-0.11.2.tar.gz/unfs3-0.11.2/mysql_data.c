﻿
/*
 * 功能: 提供目录信息在mysql中存取的便捷接口
 * (C) 2013, Lin Zhong <zlbeidou@foxmail.com>
 * see file LICENSE for license details
 *
 * 关键变量: extern mysqldatastru mysqldata(目录信息缓冲变量)
 */

#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include "mysql_data.h"
#include "fh.h"

MYSQL mysql;
MYSQL_RES *mysqlres;
MYSQL_ROW mysqlrow;
char sql[SQL_LEN_MAX];// sql命令
mysqldatastru mysqldata;// 此变量为extern
mysqluserdatastru mysqluserdata;// 此变量为extern
struct stat st_sql_obj;// 此变量为extern
linkpathstru linkpath;// 此变量为extern

// mysql初始化, 用法: mysql_data_init("root", "111111", "gateway");
int mysql_data_init(const char *user, const char *passwd, const char *db){// ok
	if(mysql_init(&mysql) == NULL){
		printf("[error] MySQL init fail!\n");
		return -1;
	}
	if(mysql_real_connect(&mysql, "127.0.0.1", user, passwd, db, MYSQL_PORT, NULL, 0) == NULL){
		printf("[error] MySQL conn fail!\n");
		return -2;
	}
	
	mysqlres = NULL;
	printf("Mysql connected!\n");

	mysql_clear_mysqluserdata();// zl
	mysql_clear_mysqldata();// zl
	linkpath.flag = 0;

	return 0;
}

// 关闭数据库
int mysql_data_quit(){// ok
	mysql_close(&mysql);
	return 0;
}

// 获取fpid
int64 mysql_get_fpid(const char *fpath){// ok
	/*若将数据库中的服务器根目录去除, 需要这里进行改动.
	 *比对fpath与服务器根目录path, 相同则返回0.*/
	//  zl
	
	char tmppath[FILEINFO_FPATH_MAX];
	char *tmp;
	
	strcpy(tmppath, fpath);
	tmp = strrchr(tmppath, '/');
	if(tmp)
		*tmp = 0;
	else
		return -1;// tmp为NULL, 即路径中没有'/', 错误

	sprintf(sql, "select fid from mapping where fpath='%s' limit 1", tmppath);
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		//  printf("[error] Not paired data!\n");// zl
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	return atol(mysqlrow[0]);
}

/* fid与fpath互查
 * fpath必须在调用之前已经分配好了内存
 * 用法: fid->fpath---if(mysql_mapping(5, fpath) == 0)// 结果已经存在fpath中了
 *       fpath->fid---fid = mysql_mapping(0, "/server/test");
 * 返回: -1-查无此值, -2-fpath输入不正确 */
int64 mysql_mapping(int64 fid, char *fpath){// ok
	if(fid){// fid不为0表示根据fid查fpath
		sprintf(sql, "select fpath from fileinfo where fid=%ld limit 1", (long)fid);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		if( (mysqlres = mysql_store_result(&mysql)) == NULL){
			return -1;
		}
		if(!(mysqlrow = mysql_fetch_row(mysqlres))){
			return -1;
		}
		strcpy(fpath, mysqlrow[0]);
		return 0;
	}else{// fid为0表示根据fpath查fid
		if(fpath == NULL || *fpath == 0)return -2;
		
		sprintf(sql, "select fid from mapping where fpath='%s' limit 1", fpath);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		if( (mysqlres = mysql_store_result(&mysql)) == NULL){
			return -1;
		}
		if((mysqlrow = mysql_fetch_row(mysqlres))){
			return atol(mysqlrow[0]);
		}
		
		int64 tmpfpid = mysql_get_fpid(fpath);
		if(tmpfpid < 0)
			return -1;
		
		// 查fpid = 父目录fid的所有文件
		sprintf(sql, "select fid,fpath from fileinfo where fpid=%ld", (long)tmpfpid);
		mysql_query(&mysql, sql);
		if(mysqlres)
			mysql_free_result(mysqlres);
		if( (mysqlres = mysql_store_result(&mysql)) == NULL){
			return -1;
		}
		while((mysqlrow = mysql_fetch_row(mysqlres))){
			if(strcmp(fpath, mysqlrow[1]) == 0){
				return atol(mysqlrow[0]);
			}
		}
		// 都查不到
		return -1;
	}
}

// 将mysqldata中的有效值存进mysql数据库中
int mysql_set_data(){// ok
	int64 tmpfid = 0;
	if(!*mysqldata.fpath)return -2;// 没有路径信息, mysqldata错误
	
	if(mysqldata.fpath[strlen(mysqldata.fpath) - 1] == '/')
		mysqldata.fpath[strlen(mysqldata.fpath) - 1] = 0;
	
	if((tmpfid = mysql_mapping(0, mysqldata.fpath)) >= 0){// 已经存在记录, 只更新, 不创建
		mysql_set_fname_mysqldata();
		sprintf(sql, "update fileinfo set fpath='%s'", mysqldata.fpath);
		sprintf(sql + strlen(sql), ",fname='%s'", mysqldata.fname);
		
		if(mysqldata.fstatus != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",fstatus='%c'", mysqldata.fstatus);
		if(mysqldata.ftype != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",ftype='%c'", mysqldata.ftype);
		if(*mysqldata.curl != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",curl='%s'", mysqldata.curl);
		if(mysqldata.fdev != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fdev=%ld", (long)mysqldata.fdev);
		if(mysqldata.fino != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fino=%ld", (long)mysqldata.fino);
		if(mysqldata.fmode != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fmode=%ld", (long)mysqldata.fmode);
		if(mysqldata.fnlinks != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fnlinks=%ld", (long)mysqldata.fnlinks);
		if(mysqldata.fuid != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fuid=%ld", (long)mysqldata.fuid);
		if(mysqldata.fgid != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fgid=%ld", (long)mysqldata.fgid);
		if(mysqldata.frdev != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",frdev=%ld", (long)mysqldata.frdev);
		if(mysqldata.fsize != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fsize=%ld", (long)mysqldata.fsize);
		if(mysqldata.dsize != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",dsize=%ld", (long)mysqldata.dsize);
		if(*mysqldata.faddr != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",faddr='%s'", mysqldata.faddr);
		if(mysqldata.fgen != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",fgen=%ld", (long)mysqldata.fgen);
		if(mysqldata.atime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",atime=%ld", (long)mysqldata.atime);
		if(mysqldata.mtime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",mtime=%ld", (long)mysqldata.mtime);
		if(mysqldata.ctime != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",ctime=%ld", (long)mysqldata.ctime);
		if(mysqldata.dblks != SQL_INT_NULL)
			sprintf(sql + strlen(sql), ",dblks=%ld", (long)mysqldata.dblks);
		
		if(*(mysqluserdata.extenddata) != SQL_CHR_NULL)
			sprintf(sql + strlen(sql), ",%s ", mysqluserdata.extenddata);
		
		sprintf(sql + strlen(sql), " where fid=%ld limit 1", (long)tmpfid);
		
		// printf("[sql] %s\n", sql);
	}else{// 没有记录, 创建
		if(!(*mysqldata.fpath && *mysqldata.curl))
			return -3;
		mysql_set_fname_mysqldata();
		mysqldata.fpid = mysql_get_fpid(mysqldata.fpath);
		sprintf(sql, "insert into fileinfo("
				"fname,"
				"fpath,"
				"fpid,"
				"fstatus,"
				"ftype,"
				"curl,"
				"fdev,"
				"fino,"
				"fmode,"
				"fnlinks,"
				"fuid,"
				"fgid,"
				"frdev,"
				"fsize,"
				"dsize,"
				"faddr,"
				"fgen,"
				"atime,"
				"mtime,"
				"ctime,"
				"dblks) "
				"values('%s','%s',%ld,'%c','%c','%s',%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,'%s',%ld,%ld,%ld,%ld,%ld)",
				mysqldata.fname,
				mysqldata.fpath,
				(long)mysqldata.fpid,
				mysqldata.fstatus,
				mysqldata.ftype,
				mysqldata.curl,
				(long)mysqldata.fdev,
				(long)mysqldata.fino,
				(long)mysqldata.fmode,
				(long)mysqldata.fnlinks,
				(long)mysqldata.fuid,
				(long)mysqldata.fgid,
				(long)mysqldata.frdev,
				(long)mysqldata.fsize,
				(long)mysqldata.dsize,
				mysqldata.faddr,
				(long)mysqldata.fgen,
				(long)mysqldata.atime,
				(long)mysqldata.mtime,
				(long)mysqldata.ctime,
				(long)mysqldata.dblks);

		if (S_ISDIR(mysqldata.fmode)) {
			mysql_query(&mysql, sql);
			if (mysql_affected_rows(&mysql) == 0)
				return -1;
			tmpfid = (int64)mysql_insert_id(&mysql);
			sprintf(sql, "insert into mapping(fid, fpath, fpid) values(%ld, '%s', %ld)", (long)tmpfid, mysqldata.fpath, (long)mysqldata.fpid);
		}
	}
	mysql_query(&mysql, sql);
	if (mysql_affected_rows(&mysql) == 0)
		return -1;
	return 0;
}

//  更改 fpath 及 fname, 用于 rename 函数
//  返回: 0-正常, -1-无此值, -2-输入错误
int mysql_set_path(int64 fid) {
	if (fid < 0) return -2;
	if (!*mysqldata.fpath) return -2;// 没有路径信息, mysqldata错误

	mysql_set_fname_mysqldata();

	//  mapping 表
	sprintf(sql, "update mapping set fpath='%s'",
			mysqldata.fpath);

	if(*(mysqluserdata.extenddata) != SQL_CHR_NULL)
		sprintf(sql + strlen(sql), ",%s ", mysqluserdata.extenddata);

	sprintf(sql + strlen(sql), " where fid=%ld", (long)fid);
#ifdef DEBUG
printf("[mysql_set_path] sql:%s\n", sql);
#endif
	mysql_query(&mysql, sql);

	//  fileinfo 表
	sprintf(sql, "update fileinfo set fpath='%s',fname='%s'",
			mysqldata.fpath, mysqldata.fname);

	if(*(mysqluserdata.extenddata) != SQL_CHR_NULL)
		sprintf(sql + strlen(sql), ",%s ", mysqluserdata.extenddata);

	sprintf(sql + strlen(sql), " where fid=%ld limit 1", (long)fid);
#ifdef DEBUG
printf("[mysql_set_path] sql:%s\n", sql);
#endif
	mysql_query(&mysql, sql);

	if(mysql_affected_rows(&mysql) == 0)
		return -1;
	return 0;
}

// 将mysql中的某项纪录删除
// 返回: 0-正常, -1-无此值, -2-输入路径错误
int mysql_delete_data(int64 fid){
	if(fid < 0)return -2;// 输入路径错误
	
	//  删除fileinfo表
	sprintf(sql, "delete from fileinfo where fid=%ld", (long)fid);
	mysql_query(&mysql, sql);

	//  删除mapping表
	sprintf(sql, "delete from mapping where fid=%ld limit 1", (long)fid);
	mysql_query(&mysql, sql);

	return 0;
}

// 看是否有fpid等于输入的值存在
// 0-存在, -1-查无此值
int mysql_lookup_from_fpid(int64 pid){
	if(pid < 0)
		return -1;
	sprintf(sql, "select * from fileinfo where fpid=%ld limit 1", (long)pid);
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	return 0;
}

// 从mysql中查找fpath, 看是否有内容
int64 mysql_lookup_data(char *fpath){
	if(!(fpath && *fpath))return -2;// 路径错误
	
	if(fpath[strlen(fpath) - 1] == '/'){// 如果fpath中末位是'/', 要去除
		char tmpfpath[FILEINFO_FPATH_MAX];
		strcpy(tmpfpath, fpath);
		tmpfpath[strlen(tmpfpath) - 1] = 0;
		return mysql_mapping(0, tmpfpath);
	}else{
		return mysql_mapping(0, fpath);
	}
}

// 从mysql中将信息读取到mysqldata缓冲中
int mysql_get_data(char *fpath){// ok
	mysql_clear_mysqldata();
	if(!(fpath && *fpath))return -2;// 路径错误
	
	int64 fid = mysql_lookup_data(fpath);

	/*fid,fname,fpath,fpid,fstatus,ftype,curl,fdev,fino,fmode,fnlinks,fuid,fgid,
	 *frdev,fsize,dsize,faddr,fgen,atime,mtime,ctime,dblks;
	 *暂时这些信息, 如有其它字段, 一定要在结尾添加,
	 *并且建立数据库时也要按相同的顺序*/
	sprintf(sql, "select * from fileinfo where fid=%ld limit 1", (long)fid);// 21 zl
	mysql_query(&mysql, sql);
	if(mysqlres)
		mysql_free_result(mysqlres);
	if( (mysqlres = mysql_store_result(&mysql)) == NULL){
		return -1;
	}
	if(!(mysqlrow = mysql_fetch_row(mysqlres))){
		return -1;
	}
	// strcpy(fpath, mysqlrow[0]);
	int status_flag = 0;// 0-正常, -3-某些值缺损
	if(mysqlrow[FILEINFO_FID])
		mysqldata.fid = atol(mysqlrow[FILEINFO_FID]);
	
	if(mysqlrow[FILEINFO_FNAME])
		strcpy(mysqldata.fname, mysqlrow[FILEINFO_FNAME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FPATH])
		strcpy(mysqldata.fpath, mysqlrow[FILEINFO_FPATH]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FPID])
		mysqldata.fpid = atol(mysqlrow[FILEINFO_FPID]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FSTATUS])
		mysqldata.fstatus = *mysqlrow[FILEINFO_FSTATUS];
	else
		mysqldata.fstatus = 'l';
	
	if(mysqlrow[FILEINFO_FTYPE])
		mysqldata.ftype = *mysqlrow[FILEINFO_FTYPE];
	else
		mysqldata.ftype = 'r';
	
	if(mysqlrow[FILEINFO_CURL])
		strcpy(mysqldata.curl, mysqlrow[FILEINFO_CURL]);
	else
		*mysqldata.curl = 0;
	
	if(mysqlrow[FILEINFO_FDEV])
		mysqldata.fdev = atol(mysqlrow[FILEINFO_FDEV]);
	else
		mysqldata.fdev = 0;
	
	if(mysqlrow[FILEINFO_FINO])
		mysqldata.fino = atol(mysqlrow[FILEINFO_FINO]);
	else
		mysqldata.fino = 0;
	
	if(mysqlrow[FILEINFO_FMODE])
		mysqldata.fmode = atol(mysqlrow[FILEINFO_FMODE]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_FNLINKS])
		mysqldata.fnlinks = atol(mysqlrow[FILEINFO_FNLINKS]);
	else
		mysqldata.fnlinks = 0;
	
	if(mysqlrow[FILEINFO_FUID])
		mysqldata.fuid = atol(mysqlrow[FILEINFO_FUID]);
	else
		mysqldata.fuid = 0;
	
	if(mysqlrow[FILEINFO_FGID])
		mysqldata.fgid = atol(mysqlrow[FILEINFO_FGID]);
	else	
		mysqldata.fgid = 0;
	
	if(mysqlrow[FILEINFO_FRDEV])
		mysqldata.frdev = atol(mysqlrow[FILEINFO_FRDEV]);
	else
		mysqldata.frdev = 0;
	
	if(mysqlrow[FILEINFO_FSIZE])
		mysqldata.fsize = atol(mysqlrow[FILEINFO_FSIZE]);
	else
		mysqldata.fsize = 0;
	
	if(mysqlrow[FILEINFO_DSIZE])
		mysqldata.dsize = atol(mysqlrow[FILEINFO_DSIZE]);
	else
		mysqldata.dsize = 0;
	
	if(mysqlrow[FILEINFO_FADDR])
		strcpy(mysqldata.faddr, mysqlrow[FILEINFO_FADDR]);
	else
		*mysqldata.faddr = 0;
	
	if(mysqlrow[FILEINFO_FGEN])
		mysqldata.fgen = atol(mysqlrow[FILEINFO_FGEN]);
	else
		mysqldata.fgen = 0;
	
	if(mysqlrow[FILEINFO_ATIME])
		mysqldata.atime = atol(mysqlrow[FILEINFO_ATIME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_MTIME])
		mysqldata.mtime = atol(mysqlrow[FILEINFO_MTIME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_CTIME])
		mysqldata.ctime = atol(mysqlrow[FILEINFO_CTIME]);
	else
		status_flag = -3;
	
	if(mysqlrow[FILEINFO_DBLKS])
		mysqldata.dblks = atol(mysqlrow[FILEINFO_DBLKS]);
	else
		status_flag = -3;
	
	return status_flag;
}

// 清除mysqldata缓冲
void mysql_clear_mysqldata(){// ok
	mysqldata.fid = SQL_INT_NULL;// 0
	*mysqldata.fname = SQL_CHR_NULL;// 1
	*mysqldata.fpath = SQL_CHR_NULL;// 2
	mysqldata.fpid = SQL_INT_NULL;// 3
	mysqldata.fstatus = SQL_CHR_NULL;// 4
	mysqldata.ftype = SQL_CHR_NULL;// 5
	*mysqldata.curl = SQL_CHR_NULL;// 6
	mysqldata.fdev = SQL_INT_NULL;// 7
	mysqldata.fino = SQL_INT_NULL;// 8
	mysqldata.fmode = SQL_INT_NULL;// 9
	mysqldata.fnlinks = SQL_INT_NULL;// 10
	mysqldata.fuid = SQL_INT_NULL;// 11
	mysqldata.fgid = SQL_INT_NULL;// 12
	mysqldata.frdev = SQL_INT_NULL;// 13
	mysqldata.fsize = SQL_INT_NULL;// 14
	mysqldata.dsize = SQL_INT_NULL;// 15
	*mysqldata.faddr = SQL_CHR_NULL;// 16
	mysqldata.fgen = SQL_INT_NULL;// 17
	mysqldata.atime = SQL_INT_NULL;// 18
	mysqldata.mtime = SQL_INT_NULL;// 19
	mysqldata.ctime = SQL_INT_NULL;// 20
	mysqldata.dblks = SQL_INT_NULL;// 21
}

// // 清除mysqluserdata缓冲
void mysql_clear_mysqluserdata(){
	mysqluserdata.flag = SQL_INT_NULL;
	*(mysqluserdata.extenddata) = SQL_CHR_NULL;
}

// 将mysqldata设置为初始值
void mysql_default_mysqldata(){// ok
	mysqldata.fid = 0;// 0
	strcpy(mysqldata.fname, "NULL");// 1
	strcpy(mysqldata.fpath, "NULL");// 2
	mysqldata.fpid = 0;// 3
	mysqldata.fstatus = 'l';// 4
	mysqldata.ftype = 'r';// 5
	strcpy(mysqldata.curl, "NULL");// 6
	mysqldata.fdev = 0;// 7
	mysqldata.fino = 0;// 8
	mysqldata.fmode = 0;// 9
	mysqldata.fnlinks = 0;// 10
	mysqldata.fuid = 0;// 11
	mysqldata.fgid = 0;// 12
	mysqldata.frdev = 0;// 13
	mysqldata.fsize = 0;// 14
	mysqldata.dsize = 0;// 15
	strcpy(mysqldata.faddr, "NULL");// 16
	mysqldata.fgen = 0;// 17
	mysqldata.atime = 0;// 18
	mysqldata.mtime = 0;// 19
	mysqldata.ctime = 0;// 20
	mysqldata.dblks = 0;// 21
}

// 将mysqldata.fpath截断后赋值给mysqldata.fname
void mysql_set_fname_mysqldata(){// ok
	if(!(*mysqldata.fpath))
		return;
	
	// 如果fpath最后一个字符为'/', 则去除这个字符
	if(mysqldata.fpath[strlen(mysqldata.fpath) - 1] == '/')
		mysqldata.fpath[strlen(mysqldata.fpath) - 1] = 0;
	
	char *tmp = strrchr(mysqldata.fpath, '/');
	if(!tmp)
		return;
	strcpy(mysqldata.fname, tmp + 1);
	return;
}

// 将fattr3中的数据复制到mysqldata中, 会改变mysqldata数据
/*void mysql_cpy_fattr3_mysqldata(const char *path, const fattr3 *attr){
	ftype3 type;
	mode3 mode;
	uint32 nlink;
	uid3 uid;
	gid3 gid;
	size3 size;
	size3 used;
	specdata3 rdev;
	uint64 fsid;
	fileid3 fileid;
	nfstime3 atime;
	nfstime3 mtime;
	nfstime3 ctime;
}// */

// 将st_stat中的信息拷贝到mysqldata中, 会改变mysqldata数据
void mysql_cpy_stat_mysqldata(const char *path, const struct stat *st_stat){
	strcpy(mysqldata.fpath, path);// 路径信息fpath
	mysql_set_fname_mysqldata();// fname
	mysqldata.fpid = mysql_get_fpid(path);// fpid
	// printf("get_fpid ok\n");// test zl
	mysqldata.fdev = (int64)(*st_stat).st_dev;
	mysqldata.fino = (*st_stat).st_ino;
	mysqldata.fmode = (*st_stat).st_mode;// 9
	mysqldata.fnlinks = (*st_stat).st_nlink;// 10
	mysqldata.fuid = (*st_stat).st_uid;// 11
	mysqldata.fgid = (*st_stat).st_gid;// 12
	mysqldata.frdev = (*st_stat).st_rdev;// 13
	mysqldata.fsize = (*st_stat).st_size;// 14
	mysqldata.dsize = (*st_stat).st_blocks * 512;// 15
	mysqldata.atime = (*st_stat).st_atime;// 18
	mysqldata.mtime = (*st_stat).st_mtime;// 19
	mysqldata.ctime = (*st_stat).st_ctime;// 20
	mysqldata.dblks = (*st_stat).st_blocks;// 21
	
	if(S_ISDIR(mysqldata.fmode))
		mysqldata.ftype = 'd';
	return;
}// */

// 将st_stat中的部分信息拷贝到mysqldata中, 会改变mysqldata数据
void mysql_cpy_stattime_mysqldata(const char *path, const struct stat *st_stat){
	mysql_clear_mysqldata();
	strcpy(mysqldata.fpath, path);// 路径信息fpath
	
	mysqldata.mtime = (*st_stat).st_ctime;// 19
	mysqldata.ctime = (*st_stat).st_ctime;// 20
// printf("[sql] m:%ld\n[sql] c:%ld\n", mysqldata.mtime, mysqldata.ctime);// test. zl
}

void mysql_set_localused(long byte_cnt){
	sprintf(sql, "update analyse set localUsed=localUsed+(%ld)", byte_cnt);
	mysql_query(&mysql, sql);
}
