﻿
/*
 * Adding local file information to mysql database tool
 * (C) 2013, Lin Zhong
 * see file LICENSE for license details
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h>

#include "mysql_data.h"

char current_dir[1024];
struct stat file_stat;
long zl_cnt = 0;

int trave_dir(char* path){
	DIR *dir;
	struct dirent *file;
	
	if(!(dir = opendir(path))){
		printf("error opendir %s!!!\n",path);
		return -1;
	}
	
	while((file = readdir(dir)) != NULL)
	{
		if( !strcmp(file->d_name, ".") || !strcmp(file->d_name, "..") )
			continue;
		
		printf(" \033[1m\033[4mNo. %ld\033[0m: %s\n", ++zl_cnt, strcat(current_dir, file->d_name));
		lstat(current_dir, &file_stat);
		
		//start
		mysql_default_mysqldata();
		mysql_cpy_stat_mysqldata(current_dir, &file_stat);
		printf("[res] %d\n", mysql_set_data());
		//end
		
		strcat(current_dir, "/");
		if(S_ISDIR(file_stat.st_mode)){
			trave_dir(current_dir);
		}
		current_dir[strlen(current_dir) - 1] = 0;
		*(strrchr(current_dir, '/') + 1) = 0;
	}
	closedir(dir);
	return 0;
}

int main(int argc, char **argv){
	char *server_dir = "/home/unfs3/server";
	int opt = 0;
    char *optstring = "hp:";

    while (opt != -1) {
		opt = getopt(argc, argv, optstring);
		switch (opt) {
			case 'p':
				server_dir = optarg;
			break;
			case 'h':
				printf("Usage: %s [options]\n", argv[0]);
				printf("\t-h          display this short option summary\n");
				printf("\t-p <path>   server root dir's absolute path\n");
				exit(0);
			break;
			case '?':
				exit(1);
			break;
		}
	}
	
	mysql_data_init("root", "111111", "gateway");// zl
	printf("Mysql setup!\n");// zl
	
	mysql_clear_mysqluserdata();
	
	printf("\n \033[1m\033[4mNo. %ld\033[0m: %s\n", ++zl_cnt, server_dir);
	lstat(server_dir, &file_stat);// zl
	mysql_default_mysqldata();
	mysql_cpy_stat_mysqldata(server_dir, &file_stat);
	printf("[res] %d\n", mysql_set_data());
	
	strcpy(current_dir, server_dir);
	if(current_dir[strlen(current_dir) - 1] != '/'){
		strcat(current_dir, "/");
	}
	
	trave_dir(current_dir);
	
	return 0;
}
