﻿
/*
 * 功能: 作为mysql_data的拓展, 使得mysql_data成为独立的模块.
 * (C) 2013, Lin Zhong <zlbeidou@foxmail.com>
 * see file LICENSE for license details
 */

#include "config.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <rpc/rpc.h>
#include <fcntl.h>
#include <time.h>
#include <utime.h>
#include <errno.h>

#include "backend.h"
#include "nfs.h"
#include "attr.h"
#include "error.h"
#include "fh.h"
#include "fh_cache.h"
#include "daemon.h"
#include "user.h"
#include "Config/exports.h"
#include "mysql_data.h"
#include "mysql_data_ex.h"

mysqldatastru *mysql_backup_data(const char *path){
	static mysqldatastru mysqldata_bak;
	mysql_get_data((char *)path);
	mysqldata_bak = mysqldata;
	return &mysqldata_bak;
}

void mysql_post_op_attr(const char *path, post_op_attr *obj){
	if (mysql_get_data((char *)path) < 0){// 取值错误. zl
		(*obj).attributes_follow = FALSE;
	} else {// 取值正确. zl
		(*obj).attributes_follow = TRUE;
		(*obj).post_op_attr_u.attributes.atime.seconds = (uint32)mysqldata.atime;
		(*obj).post_op_attr_u.attributes.atime.nseconds = 0;
		(*obj).post_op_attr_u.attributes.ctime.seconds = (uint32)mysqldata.ctime;
		(*obj).post_op_attr_u.attributes.ctime.nseconds = 0;
		(*obj).post_op_attr_u.attributes.fileid = (fileid3)mysqldata.fino;
		(*obj).post_op_attr_u.attributes.fsid = (uint64)mysqldata.fdev;
		(*obj).post_op_attr_u.attributes.gid = (gid3)mysqldata.fgid;
		(*obj).post_op_attr_u.attributes.mtime.seconds = (uint32)mysqldata.mtime;
		(*obj).post_op_attr_u.attributes.mtime.nseconds = 0;
		(*obj).post_op_attr_u.attributes.nlink = (uint32)mysqldata.fnlinks;
		(*obj).post_op_attr_u.attributes.rdev.specdata1
				= (mysqldata.frdev >> 8) & 0xFF;
		(*obj).post_op_attr_u.attributes.rdev.specdata2
				= mysqldata.frdev & 0xFF;
		(*obj).post_op_attr_u.attributes.size = (size3)mysqldata.fsize;

	    if (S_ISDIR(mysqldata.fmode))
	    	(*obj).post_op_attr_u.attributes.type = NF3DIR;
	    else if (S_ISBLK(mysqldata.fmode))
	    	(*obj).post_op_attr_u.attributes.type = NF3BLK;
	    else if (S_ISCHR(mysqldata.fmode))
	    	(*obj).post_op_attr_u.attributes.type = NF3CHR;
#ifdef S_ISLNK
	    else if (S_ISLNK(mysqldata.fmode))
	    	(*obj).post_op_attr_u.attributes.type = NF3LNK;
#endif				       /* S_ISLNK */
#ifdef S_ISSOCK
	    else if (S_ISSOCK(mysqldata.fmode))
	    	(*obj).post_op_attr_u.attributes.type = NF3SOCK;
#endif				       /* S_ISSOCK */
	    else if (S_ISFIFO(mysqldata.fmode))
	    	(*obj).post_op_attr_u.attributes.type = NF3FIFO;
	    else
	    	(*obj).post_op_attr_u.attributes.type = NF3REG;
	    /* adapt permissions for executable files */
	    if (opt_readable_executables && S_ISREG(mysqldata.fmode)) {
			if (mysqldata.fmode & S_IXUSR)
				mysqldata.fmode |= S_IRUSR;
			if (mysqldata.fmode & S_IXGRP)
				mysqldata.fmode |= S_IRGRP;
			if (mysqldata.fmode & S_IXOTH)
				mysqldata.fmode |= S_IROTH;
	    }

	    (*obj).post_op_attr_u.attributes.mode = (mode3)mysqldata.fmode & 0xFFFF;
	    (*obj).post_op_attr_u.attributes.uid = (uid3)mysqldata.fuid;
	    (*obj).post_op_attr_u.attributes.used = (size3)mysqldata.dsize;
	}
	return;
}

post_op_attr mysql_get_post(const char *path, struct svc_req * req){
	post_op_attr result;
	if (mysql_get_data((char *)path) < 0){// 取值错误. zl
printf("\n[mysql_post] mysql_get_data error!\n\n");
		result.attributes_follow = FALSE;
	} else {// 取值正确. zl
		result.attributes_follow = TRUE;

		if (S_ISDIR(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3DIR;
		else if (S_ISBLK(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3BLK;
		else if (S_ISCHR(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3CHR;
#ifdef S_ISLNK
		else if (S_ISLNK(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3LNK;
#endif				       /* S_ISLNK */
#ifdef S_ISSOCK
		else if (S_ISSOCK(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3SOCK;
#endif				       /* S_ISSOCK */
		else if (S_ISFIFO(mysqldata.fmode))
			result.post_op_attr_u.attributes.type = NF3FIFO;
		else
			result.post_op_attr_u.attributes.type = NF3REG;

		/* adapt permissions for executable files */
		if (opt_readable_executables && S_ISREG(mysqldata.fmode)) {
			if (mysqldata.fmode & S_IXUSR)
				mysqldata.fmode |= S_IRUSR;
			if (mysqldata.fmode & S_IXGRP)
				mysqldata.fmode |= S_IRGRP;
			if (mysqldata.fmode & S_IXOTH)
				mysqldata.fmode |= S_IROTH;
		}
		result.post_op_attr_u.attributes.mode = (mode3)mysqldata.fmode & 0xFFFF;
		result.post_op_attr_u.attributes.nlink = (uint32)mysqldata.fnlinks;

//printf("getuid:%d geteuid:%d\n", getuid(), geteuid());
		/* If -s, translate uids */
		if (opt_singleuser) {
			unsigned int req_uid = 0;
			unsigned int req_gid = 0;
			struct authunix_parms *auth = (void *) req->rq_clntcred;

			if (req->rq_cred.oa_flavor == AUTH_UNIX) {
				req_uid = auth->aup_uid;
				req_gid = auth->aup_gid;
				result.post_op_attr_u.attributes.uid = req_uid;
				result.post_op_attr_u.attributes.gid = req_gid;
			} else {
				result.post_op_attr_u.attributes.uid = (uid3)mysqldata.fuid;
				result.post_op_attr_u.attributes.gid = (gid3)mysqldata.fgid;
			}
		} else {
			result.post_op_attr_u.attributes.uid = (uid3)mysqldata.fuid;
			result.post_op_attr_u.attributes.gid = (gid3)mysqldata.fgid;
		}

		result.post_op_attr_u.attributes.size = (size3)mysqldata.fsize;
		result.post_op_attr_u.attributes.used = (size3)mysqldata.dsize;

		result.post_op_attr_u.attributes.rdev.specdata1
				= ((uint32)mysqldata.frdev >> 8) & 0xFF;
		result.post_op_attr_u.attributes.rdev.specdata2
				= (uint32)mysqldata.frdev & 0xFF;

		result.post_op_attr_u.attributes.fsid = (uint64)mysqldata.fdev;
		result.post_op_attr_u.attributes.fileid = (fileid3)mysqldata.fino;

		result.post_op_attr_u.attributes.atime.seconds = (uint32)mysqldata.atime;
		result.post_op_attr_u.attributes.atime.nseconds = 0;
		result.post_op_attr_u.attributes.mtime.seconds = (uint32)mysqldata.mtime;
		result.post_op_attr_u.attributes.mtime.nseconds = 0;
		result.post_op_attr_u.attributes.ctime.seconds = (uint32)mysqldata.ctime;
		result.post_op_attr_u.attributes.ctime.nseconds = 0;
	}

	return result;
}

post_op_attr mysql_backup_post(mysqldatastru *bak, struct svc_req * req){
	post_op_attr result;

	result.attributes_follow = TRUE;

	if (S_ISDIR((*bak).fmode))
		result.post_op_attr_u.attributes.type = NF3DIR;
	else if (S_ISBLK((*bak).fmode))
		result.post_op_attr_u.attributes.type = NF3BLK;
	else if (S_ISCHR((*bak).fmode))
		result.post_op_attr_u.attributes.type = NF3CHR;
#ifdef S_ISLNK
	else if (S_ISLNK((*bak).fmode))
		result.post_op_attr_u.attributes.type = NF3LNK;
#endif				       /* S_ISLNK */
#ifdef S_ISSOCK
	else if (S_ISSOCK((*bak).fmode))
		result.post_op_attr_u.attributes.type = NF3SOCK;
#endif				       /* S_ISSOCK */
	else if (S_ISFIFO((*bak).fmode))
		result.post_op_attr_u.attributes.type = NF3FIFO;
	else
		result.post_op_attr_u.attributes.type = NF3REG;

	/* adapt permissions for executable files */
	if (opt_readable_executables && S_ISREG((*bak).fmode)) {
		if ((*bak).fmode & S_IXUSR)
			(*bak).fmode |= S_IRUSR;
		if ((*bak).fmode & S_IXGRP)
			(*bak).fmode |= S_IRGRP;
		if ((*bak).fmode & S_IXOTH)
			(*bak).fmode |= S_IROTH;
	}
	result.post_op_attr_u.attributes.mode = (mode3)(*bak).fmode & 0xFFFF;
	result.post_op_attr_u.attributes.nlink = (uint32)(*bak).fnlinks;

//printf("getuid:%d geteuid:%d\n", getuid(), geteuid());
	/* If -s, translate uids */
	if (opt_singleuser) {
		unsigned int req_uid = 0;
		unsigned int req_gid = 0;
		struct authunix_parms *auth = (void *) req->rq_clntcred;

		if (req->rq_cred.oa_flavor == AUTH_UNIX) {
			req_uid = auth->aup_uid;
			req_gid = auth->aup_gid;
			result.post_op_attr_u.attributes.uid = req_uid;
			result.post_op_attr_u.attributes.gid = req_gid;
#ifdef DEBUG
			printf("[mysql_post] req_uid:%d gid:%d\n", req_uid, req_gid);
#endif
		} else {
			result.post_op_attr_u.attributes.uid = (uid3)(*bak).fuid;
			result.post_op_attr_u.attributes.gid = (gid3)(*bak).fgid;
		}
	} else {
		result.post_op_attr_u.attributes.uid = (uid3)(*bak).fuid;
		result.post_op_attr_u.attributes.gid = (gid3)(*bak).fgid;
	}

	result.post_op_attr_u.attributes.size = (size3)(*bak).fsize;
	result.post_op_attr_u.attributes.used = (size3)(*bak).dsize;

	result.post_op_attr_u.attributes.rdev.specdata1
			= ((uint32)(*bak).frdev >> 8) & 0xFF;
	result.post_op_attr_u.attributes.rdev.specdata2
			= (uint32)(*bak).frdev & 0xFF;

	result.post_op_attr_u.attributes.fsid = (uint64)(*bak).fdev;
	result.post_op_attr_u.attributes.fileid = (fileid3)(*bak).fino;

	result.post_op_attr_u.attributes.atime.seconds = (uint32)(*bak).atime;
	result.post_op_attr_u.attributes.atime.nseconds = 0;
	result.post_op_attr_u.attributes.mtime.seconds = (uint32)(*bak).mtime;
	result.post_op_attr_u.attributes.mtime.nseconds = 0;
	result.post_op_attr_u.attributes.ctime.seconds = (uint32)(*bak).ctime;
	result.post_op_attr_u.attributes.ctime.nseconds = 0;


	return result;
}

pre_op_attr mysql_get_pre(const char *path) {
	pre_op_attr result;
	if (mysql_get_data((char *)path) < 0){// 取值错误. zl
printf("[mysql_pre] error!\n");
		result.attributes_follow = FALSE;
	} else {// 取值正确. zl
		result.attributes_follow = TRUE;
		result.pre_op_attr_u.attributes.size = (size3)mysqldata.fsize;
		result.pre_op_attr_u.attributes.mtime.seconds = (uint32)mysqldata.mtime;
		result.pre_op_attr_u.attributes.mtime.nseconds = 0;
		result.pre_op_attr_u.attributes.ctime.seconds = (uint32)mysqldata.ctime;
		result.pre_op_attr_u.attributes.ctime.nseconds = 0;
	}

	return result;
}

void mysql_backup_linkpath(){
	if (strcmp(mysqldata.curl, "NULL")) {
		linkpath.flag = 1;
		strcpy(linkpath.path, mysqldata.curl);
	} else {
		linkpath.flag = 0;
	}
	return;
}

int mysql_recovery_linkpath(){
	if (linkpath.flag == 0)
		return 0;

	strcpy(mysqldata.fpath, linkpath.path);
	mysqldata.fid = SQL_INT_NULL;// 0
	*mysqldata.fname = SQL_CHR_NULL;// 1
	mysqldata.fpid = SQL_INT_NULL;// 3
	mysqldata.ftype = SQL_CHR_NULL;// 5
	*mysqldata.curl = SQL_CHR_NULL;// 6
	mysqldata.fdev = SQL_INT_NULL;// 7
	mysqldata.fino = SQL_INT_NULL;// 8
	mysqldata.fnlinks = SQL_INT_NULL;// 10

	linkpath.flag = 0;
	return 1;
}
