﻿
/*
 * Just for test, no meaning
 * (C) 2013.
 */

#ifndef TEST_H_
#define TEST_H_


#endif