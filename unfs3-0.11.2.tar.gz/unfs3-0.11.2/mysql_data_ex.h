﻿
/*
 * 功能: 作为mysql_data的拓展, 使得mysql_data成为独立的模块.
 * (C) 2013, Lin Zhong <zlbeidou@foxmail.com>
 * see file LICENSE for license details
 */

 #ifndef MYSQL_DATA_EX_H
#define MYSQL_DATA_EX_H

mysqldatastru *mysql_backup_data(const char *path);
void mysql_post_op_attr(const char *path, post_op_attr *obj);

post_op_attr mysql_get_post(const char *path, struct svc_req * req);
post_op_attr mysql_backup_post(mysqldatastru *bak, struct svc_req * req);

pre_op_attr mysql_get_pre(const char *path);

void mysql_backup_linkpath();
int mysql_recovery_linkpath();

#endif
