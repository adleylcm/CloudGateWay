﻿
/*
 * UNFS3 NFS protocol procedures
 * (C) 2004, Pascal Schmidt
 * see file LICENSE for license details
 *
 * Modified by Lin Zhong during 2013 where commented with "// zl".
 */

#include "config.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>		       /* needed for statfs() on NetBSD */
#if HAVE_SYS_MOUNT_H == 1
#include <sys/mount.h>		       /* dito */
#endif
#if HAVE_SYS_VMOUNT_H == 1
#include <sys/vmount.h>		       /* AIX */
#endif
#include <rpc/rpc.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <utime.h>
#ifndef WIN32
#include <sys/socket.h>
#include <sys/un.h>
#endif				       /* WIN32 */

#if HAVE_STATVFS == 1
# include <sys/statvfs.h>
#else
# define statvfs statfs
#endif

#include "nfs.h"
#include "mount.h"
#include "fh.h"
#include "fh_cache.h"
#include "attr.h"
#include "readdir.h"
#include "user.h"
#include "error.h"
#include "fd_cache.h"
#include "daemon.h"
#include "backend.h"
#include "Config/exports.h"
#include "Extras/cluster.h"
#include "mysql_data.h"
#include "mysql_data_ex.h"

#define PATH_DEBUG(str) printf("[path] %s\n", str)
#define OBJ_DEBUG(str) printf("[obj] %s\n", str)
#define OLD_DEBUG(str) printf("[old] %s\n", str)

/*
 * decompose filehandle and switch user if permitted access
 * otherwise zero result structure and return with error status
 */
#define PREP(p,f) do { \
	unfs3_fh_t *fh = (void *)f.data.data_val; \
	switch_to_root(); \
	p = fh_decomp(f); \
	if (exports_options(p, rqstp, NULL, NULL) == -1) { \
		memset(&result, 0, sizeof(result)); \
		if (p) \
			result.status = NFS3ERR_ACCES; \
		else \
			result.status = NFS3ERR_STALE; \
		return &result; \
	} \
	if (fh->pwhash != export_password_hash) { \
		memset(&result, 0, sizeof(result)); \
		result.status = NFS3ERR_STALE; \
		return &result; \
	} \
	switch_user(rqstp); \
}while(0)

#define PREP_MYSQL(p,f) do { \
	unfs3_fh_t *fh = (void *)f.data.data_val; \
	switch_to_root(); \
	p = fh_decomp(f); \
	if (exports_options(p, rqstp, NULL, NULL) == -1) { \
		memset(&result, 0, sizeof(result)); \
		if (p) \
			result.status = NFS3ERR_ACCES; \
		else \
			result.status = NFS3ERR_STALE; \
		return &result; \
	} \
	if (fh->pwhash != export_password_hash) { \
		memset(&result, 0, sizeof(result)); \
		result.status = NFS3ERR_STALE; \
		return &result; \
	} \
	switch_user(rqstp); \
}while(0)

/*
 * cat an object name onto a path, checking for illegal input
 */
// 将path和name合并, 例如path-server/testdir, name-testfile,
// result = server/testdir/testfile. zl
nfsstat3 cat_name(const char *path, const char *name, char *result)
{
    char *last;

    if (!path)
	return NFS3ERR_STALE;

    if (!name)
	return NFS3ERR_ACCES;

    if (name[0] == 0 || strchr(name, '/') != NULL)// name为空串或者带有'/', 即name中含有路径. zl
	return NFS3ERR_ACCES;

    if (strlen(path) + strlen(name) + 2 > NFS_MAXPATHLEN)
	return NFS3ERR_NAMETOOLONG;

    if (strcmp(name, ".") == 0) {
	strcpy(result, path);
	return NFS3_OK;
    }

    /* 
     * Irix clients do lookups for .. and then use the
     * resulting filehandle for more lookups, causing them
     * to get filehandles that fh_decomp_raw will refuse to
     * resolve. Export list handling will also get very
     * confused if we allow such filehandles.
     */
    if (strcmp(name, "..") == 0) {
		last = strrchr(path, '/');
		if (!last || last == path)
			strcpy(result, "/");
		else {
			*last = 0;
			strcpy(result, path);
			*last = '/';
		}
		return NFS3_OK;
    }

    sprintf(result, "%s/%s", path, name);
    return NFS3_OK;
}

void *nfsproc3_null_3_svc(U(void *argp), U(struct svc_req *rqstp))
{
    static void *result = NULL;
    return &result;
}

// GETATTR。返回一个文件的属性：文件类型（一般文件，目录等）、访问权限、
// 文件大小、文件的属主者及上一次访问时间等信息。 ql
GETATTR3res *nfsproc3_getattr_3_svc(GETATTR3args * argp,
				    struct svc_req * rqstp)
{
    static GETATTR3res result;
    // static fattr3 result_attr;
	char *path;
    post_op_attr post;// bak. zl

    PREP_MYSQL(path, argp->object);
    PATH_DEBUG(path);

    // post = get_post_cached(rqstp);// bak. zl
    post = mysql_get_post(path, rqstp);

    if (post.attributes_follow)
    	result.status = NFS3_OK;
    else
    	result.status = NFS3ERR_NOENT;
	
	// result.GETATTR3res_u.resok.obj_attributes = post.post_op_attr_u.attributes;// bak zl
	// 从数据库读取信息. zl
    result.GETATTR3res_u.resok.obj_attributes = post.post_op_attr_u.attributes;
	
    return &result;
}

/*
 * check ctime guard for SETATTR procedure
 */
static nfsstat3 in_sync(sattrguard3 guard, pre_op_attr pre)
{
    if (!pre.attributes_follow)
    	return NFS3ERR_STALE;

    if (!guard.check)
    	return NFS3_OK;

    if (guard.sattrguard3_u.obj_ctime.seconds !=
    		pre.pre_op_attr_u.attributes.ctime.seconds)
    	return NFS3ERR_NOT_SYNC;

    return NFS3_OK;
}

// SETATTR。设置一个文件的属性。
// 只允许设置文件属性的一个子集：访问权限、文件的属主、组的属主、文件大小、上次访问时间和上次修改时间。 ql
SETATTR3res *nfsproc3_setattr_3_svc(SETATTR3args * argp,
				    struct svc_req * rqstp)
{
    static SETATTR3res result;
    pre_op_attr pre;
    char *path;

    PREP_MYSQL(path, argp->object);
    PATH_DEBUG(path);

    // pre = get_pre_cached();// bak. zl
    mysqldatastru *bak = mysql_backup_data(path);
    pre.attributes_follow = TRUE;
    pre.pre_op_attr_u.attributes.size = (size3)(*bak).fsize;
    pre.pre_op_attr_u.attributes.mtime.seconds = (uint32)(*bak).mtime;
    pre.pre_op_attr_u.attributes.mtime.nseconds = 0;
    pre.pre_op_attr_u.attributes.ctime.seconds = (uint32)(*bak).ctime;
    pre.pre_op_attr_u.attributes.ctime.nseconds = 0;
    uint64 bak_used = (*bak).dsize;

    result.status = join(in_sync(argp->guard, pre), exports_rw());

    if (result.status == NFS3_OK){
		result.status = set_attr(path, argp->object, argp->new_attributes);// set_attr函数已修改. zl
		
	}

    /* overlaps with resfail */
    result.SETATTR3res_u.resok.obj_wcc.before = pre;
    // result.SETATTR3res_u.resok.obj_wcc.after = get_post_stat(path, rqstp);// bak. zl
    // mysql_post_op_attr(path, &(result.SETATTR3res_u.resok.obj_wcc.after));
    result.SETATTR3res_u.resok.obj_wcc.after = mysql_get_post(path, rqstp);

	if (result.status == NFS3_OK) {
		mysql_set_localused(
				result.SETATTR3res_u.resok.obj_wcc.after.post_op_attr_u.attributes.used
				- (long)bak_used);
	}

    return &result;
}

// LOOKUP。查找一个文件。 ql
LOOKUP3res *nfsproc3_lookup_3_svc(LOOKUP3args * argp, struct svc_req * rqstp)
{
    static LOOKUP3res result;
    unfs3_fh_t *fh;
    char *path;
    char obj[NFS_MAXPATHLEN];
    backend_statstruct buf;
    int res;
    uint32 gen;

    PREP_MYSQL(path, argp->what.dir);// zl
    result.status = cat_name(path, argp->what.name, obj);// 将文件名叠加到path后复制到(char[])obj中. zl

    OBJ_DEBUG(obj);

    cluster_lookup(obj, rqstp, &result.status);// 可忽略此行, 只有宏定义了WANT_CLUSTER才有效, linux下没有使用, 可注释掉. zl

    if (result.status == NFS3_OK) {
		res = backend_lstat(obj, &buf);
		if (res == -1) {// 文件有错误. zl
			result.status = lookup_err();// 不用改这里. zl
		} else {// 文件存在并正确. zl
			if (strcmp(argp->what.name, ".") == 0 ||
					strcmp(argp->what.name, "..") == 0) {
				fh = fh_comp_ptr(obj, rqstp, 0);
			} else {
				gen = backend_get_gen(buf, FD_NONE, obj);
				fh = fh_extend(argp->what.dir, buf.st_dev, buf.st_ino, gen);
				fh_cache_add(buf.st_dev, buf.st_ino, obj);
			}

			if (fh) {
				result.LOOKUP3res_u.resok.object.data.data_len =
					fh_length(fh);
				result.LOOKUP3res_u.resok.object.data.data_val = (char *) fh;
				// result.LOOKUP3res_u.resok.obj_attributes =
				// 	get_post_buf(buf, rqstp);// bak. zl
				// mysql_post_op_attr(obj, &(result.LOOKUP3res_u.resok.obj_attributes));
				result.LOOKUP3res_u.resok.obj_attributes = mysql_get_post(obj, rqstp);
			} else {
				/* path was too long */
				result.status = NFS3ERR_NAMETOOLONG;
			}
		}
    }
	
    /* overlaps with resfail */
    // result.LOOKUP3res_u.resok.dir_attributes = get_post_stat(path, rqstp);// bak. zl
    // mysql_post_op_attr(path, &(result.LOOKUP3res_u.resok.dir_attributes));
    result.LOOKUP3res_u.resok.dir_attributes = mysql_get_post(path, rqstp);

    return &result;
}

// ACCESS。检查文件夹访问权限。 ql
ACCESS3res *nfsproc3_access_3_svc(ACCESS3args * argp, struct svc_req * rqstp)
{
    static ACCESS3res result;
    char *path;
    // post_op_attr post;
    mode_t mode;
    int access = 0;

    PREP(path, argp->object);

    PATH_DEBUG(path);

    // result.ACCESS3res_u.resok.obj_attributes = get_post_stat(path, rqstp);
    result.ACCESS3res_u.resok.obj_attributes = mysql_get_post(path, rqstp);
    // post = get_post_cached(rqstp);// bak. zl
    // mode = post.post_op_attr_u.attributes.mode;// bak. zl
    mode = (mode_t)mysqldata.fmode;

    /* owner permissions */
    if (is_owner(st_cache.st_uid, rqstp)) {
		if (mode & S_IRUSR)
			access |= ACCESS3_READ;
		if (mode & S_IWUSR)
			access |= ACCESS3_MODIFY | ACCESS3_EXTEND;
		if (mode & S_IXUSR) {
			access |= ACCESS3_EXECUTE;
			if (opt_readable_executables)
				access |= ACCESS3_READ;
		}
    } else if (has_group(st_cache.st_gid, rqstp)) {
		/* group permissions */
		if (mode & S_IRGRP)
			access |= ACCESS3_READ;
		if (mode & S_IWGRP)
			access |= ACCESS3_MODIFY | ACCESS3_EXTEND;
		if (mode & S_IXGRP) {
			access |= ACCESS3_EXECUTE;
			if (opt_readable_executables)
				access |= ACCESS3_READ;
		}
    } else {
		/* other permissions */
		if (mode & S_IROTH)
			access |= ACCESS3_READ;
		if (mode & S_IWOTH)
			access |= ACCESS3_MODIFY | ACCESS3_EXTEND;
		if (mode & S_IXOTH) {
			access |= ACCESS3_EXECUTE;
			if (opt_readable_executables)
				access |= ACCESS3_READ;
		}
    }

    /* root is allowed everything */
    if (get_uid(rqstp) == 0)
    	access |= ACCESS3_READ | ACCESS3_MODIFY | ACCESS3_EXTEND;

    // 迫不得已这么弄, 可删除试一试. zl
    // access |= ACCESS3_READ | ACCESS3_MODIFY | ACCESS3_EXTEND | ACCESS3_EXECUTE;

    /* adjust if directory */
    // if (post.post_op_attr_u.attributes.type == NF3DIR) {
    if (mysqldata.ftype == 'd') {
		if (access & (ACCESS3_READ | ACCESS3_EXECUTE))
			access |= ACCESS3_LOOKUP;
		if (access & ACCESS3_MODIFY)
			access |= ACCESS3_DELETE;
		access &= ~ACCESS3_EXECUTE;
    }

    result.status = NFS3_OK;
    result.ACCESS3res_u.resok.access = access & argp->access;
#ifdef DEBUG
printf("[res ans rsq] 0x%X = 0x%X & 0x%X\n", (int)result.ACCESS3res_u.resok.access,
		access, (int)argp->access);
#endif
    // 此操作转移到函数开头. zl
    // result.ACCESS3res_u.resok.obj_attributes = post;// bak. zl

    return &result;
}

// READLINK。读一个符号链接。即返回符号链接所指的文件的名字。 ql
READLINK3res *nfsproc3_readlink_3_svc(READLINK3args * argp,
				      struct svc_req * rqstp)
{
printf("\n[error] readlink not ok!\n\n");
    static READLINK3res result;
    char *path;
    static char buf[NFS_MAXPATHLEN];
    int res;

    PREP(path, argp->symlink);
    PATH_DEBUG(path);

    res = backend_readlink(path, buf, NFS_MAXPATHLEN - 1);
    if (res == -1) {
    	result.status = readlink_err();
    } else {
		/* readlink does not NULL-terminate */
		buf[res] = 0;

		result.status = NFS3_OK;
		result.READLINK3res_u.resok.data = buf;
    }

    /* overlaps with resfail */
    result.READLINK3res_u.resok.symlink_attributes =
    		get_post_stat(path, rqstp);

    return &result;
}

// READ。从一个文件中读数据。客户说明文件的句柄、读操作的开始位置和读数据的最大字节数。 ql
READ3res *nfsproc3_read_3_svc(READ3args * argp, struct svc_req * rqstp)
{
    static READ3res result;
    char *path;
    int fd, res;
    static char buf[NFS_MAXDATA_TCP + 1];
    unsigned int maxdata;

    if (get_socket_type(rqstp) == SOCK_STREAM)
		maxdata = NFS_MAXDATA_TCP;
    else
		maxdata = NFS_MAXDATA_UDP;

    PREP_MYSQL(path, argp->file);
    PATH_DEBUG(path);

    result.status = is_reg();// 只有常规文件才能读. zl

    // mysqldata备份标志位. zl
	static bool_t flag_bak = TRUE;
	static mysqldatastru *bak;
    // 对mysqldata做一个备份, 后面用得上. zl
    if(result.status == NFS3_OK && flag_bak){
		bak = mysql_backup_data(path);
		mysql_backup_linkpath();
		flag_bak = FALSE;
    }

    /* handle reading of executables */
    read_executable(rqstp, st_cache);

    /* handle read of owned files */
    read_by_owner(rqstp, st_cache);

    /* if bigger than rtmax, truncate length */
    if (argp->count > maxdata)
    	argp->count = maxdata;

    if (result.status == NFS3_OK) {
		fd = fd_open(path, argp->file, UNFS3_FD_READ, TRUE);// 此函数已更改. zl
		if (fd != -1) {
			/* read one more to check for eof */
			res = backend_pread(fd, buf, argp->count + 1, argp->offset);

			/* eof if we could not read one more */
			result.READ3res_u.resok.eof = (res <= (int64) argp->count);

			/* close for real when hitting eof */
			if (result.READ3res_u.resok.eof)
				fd_close(fd, UNFS3_FD_READ, FD_CLOSE_REAL);
			else {
				fd_close(fd, UNFS3_FD_READ, FD_CLOSE_VIRT);
				res--;
			}

			if (res >= 0) {
				result.READ3res_u.resok.count = res;
				result.READ3res_u.resok.data.data_len = res;
				result.READ3res_u.resok.data.data_val = buf;
			} else {
				/* error during read() */

				/* EINVAL means unreadable object */
				if (errno == EINVAL)
					result.status = NFS3ERR_INVAL;
				else
					result.status = NFS3ERR_IO;
			}
		} else {
			/* opening for read failed */
			result.status = read_err();
		}
    }

    /* overlaps with resfail */
    // result.READ3res_u.resok.file_attributes = get_post_stat(path, rqstp);// bak. zl
	if (!result.READ3res_u.resok.eof) {
		result.READ3res_u.resok.file_attributes = mysql_backup_post(bak, rqstp);
		if (fstat(fd, &st_sql_obj) != -1) {
			result.READ3res_u.resok.file_attributes.post_op_attr_u.attributes.atime.seconds
					= st_sql_obj.st_atime;
		}
	}

    // 更新数据库. zl
    if (result.status == NFS3_OK && result.READ3res_u.resok.eof) {
#ifdef DEBUG
printf("[read] read over!\n");
#endif
    	flag_bak = TRUE;// 此次读文件结束, 下次读文件继续备份文件信息. zl
    	if (lstat(path, &st_sql_obj) != -1) {
			mysql_clear_mysqldata();
			strcpy(mysqldata.fpath, path);
			mysqldata.fstatus = 'l';
			mysqldata.atime = st_sql_obj.st_atime;
			strcpy(mysqluserdata.extenddata, "usedCNT=usedCNT+1");
#ifdef DEBUG
			printf("[read] set fstatus:l\n");
#endif
			mysql_set_data();
			if (mysql_recovery_linkpath()) {
				mysql_set_data();
			}
			mysql_clear_mysqluserdata();
		}
    	result.READ3res_u.resok.file_attributes = mysql_get_post(path, rqstp);
    }

    return &result;
}

// WRITE。对一个文件进行读写操作。客户说明文件的句柄、开始位置、写数据的字节数和要写的数据。 ql
WRITE3res *nfsproc3_write_3_svc(WRITE3args * argp, struct svc_req * rqstp)
{
    static WRITE3res result;
    char *path;
    int fd, res, res_close;

    PREP(path, argp->file);
    PATH_DEBUG(path);

    result.status = join(is_reg(), exports_rw());

    // mysqldata备份标志位. zl
	static bool_t flag_bak = TRUE;
	static mysqldatastru *bak;
    // 对mysqldata做一个备份, 后面用得上. zl
    if(result.status == NFS3_OK && flag_bak){
// printf("[write] bak!\n");
		bak = mysql_backup_data(path);
		mysql_backup_linkpath();
		flag_bak = FALSE;
    }

    /* handle write of owned files */
    write_by_owner(rqstp, st_cache);

	if (result.status == NFS3_OK) {
		/* We allow caching of the fd only for unstable writes. This is to
		   prevent generating a new write verifier for failed stable writes,
		   when the fd was not in the cache. Besides, for stable writes, the
		   fd will be removed from the cache by fd_close() below, so adding
		   it to and removing it from the cache is just a waste of CPU cycles
		 */
		fd = fd_open(path, argp->file, UNFS3_FD_WRITE,
				 (argp->stable == UNSTABLE));
		if (fd != -1) {
			res = backend_pwrite(fd,
					argp->data.data_val,
					argp->data.data_len,
					argp->offset);

			/* close for real if not UNSTABLE write */
			if (argp->stable == UNSTABLE)
				res_close = fd_close(fd, UNFS3_FD_WRITE, FD_CLOSE_VIRT);
			else
				res_close = fd_close(fd, UNFS3_FD_WRITE, FD_CLOSE_REAL);

			/* we always do fsync(), never fdatasync() */
			if (argp->stable == DATA_SYNC)
				argp->stable = FILE_SYNC;

			if (res != -1 && res_close != -1) {
				result.WRITE3res_u.resok.count = res;
				result.WRITE3res_u.resok.committed = argp->stable;
				memcpy(result.WRITE3res_u.resok.verf, wverf,
					   NFS3_WRITEVERFSIZE);
			} else {
				/* error during write or close */
				result.status = write_write_err();
			}
		} else {
			/* could not open for writing */
			result.status = write_open_err();
		}
    }

    /* overlaps with resfail */
    // result.WRITE3res_u.resok.file_wcc.before = get_pre_cached();// bak. zl
	result.WRITE3res_u.resok.file_wcc.before.attributes_follow = TRUE;
	result.WRITE3res_u.resok.file_wcc.before.pre_op_attr_u.attributes.size
			= (size3)(*bak).fsize;
	result.WRITE3res_u.resok.file_wcc.before.pre_op_attr_u.attributes.mtime.seconds
    		= (uint32)(*bak).mtime;
	result.WRITE3res_u.resok.file_wcc.before.pre_op_attr_u.attributes.mtime.nseconds
    		= 0;
	result.WRITE3res_u.resok.file_wcc.before.pre_op_attr_u.attributes.ctime.seconds
    		= (uint32)(*bak).ctime;
	result.WRITE3res_u.resok.file_wcc.before.pre_op_attr_u.attributes.ctime.nseconds
    		= 0;

    // result.WRITE3res_u.resok.file_wcc.after = get_post_stat(path, rqstp);// bak. zl
	// 更新数据库. zl
	if(result.status == NFS3_OK){
		flag_bak = TRUE;// 此次写文件结束, 下次写文件继续备份文件信息. zl
		if(lstat(path, &st_sql_obj) != -1){
			mysql_clear_mysqldata();
			strcpy(mysqldata.fpath, path);
			mysqldata.mtime = st_sql_obj.st_mtime;
			mysqldata.ctime = st_sql_obj.st_ctime;
			mysqldata.fsize = st_sql_obj.st_size;
			mysqldata.dsize = st_sql_obj.st_blocks * 512;
			mysqldata.dblks = st_sql_obj.st_blocks;
			mysqldata.fstatus = 'l';
#ifdef DEBUG
printf("[write] set fstatus:l\n");
#endif
			mysql_set_data();
			if (mysql_recovery_linkpath()) {
				mysql_set_data();
			}
		}
	}// */
	// mysql_post_op_attr(path, &(result.WRITE3res_u.resok.file_wcc.after));
	result.WRITE3res_u.resok.file_wcc.after = mysql_get_post(path, rqstp);

	if (result.status == NFS3_OK) {
		mysql_set_localused(
				result.WRITE3res_u.resok.file_wcc.after.post_op_attr_u.attributes.used
				- (long)(*bak).dsize);
	}

    return &result;
}

#ifndef WIN32

/*
 * store verifier in atime and mtime 
 */
static int store_create_verifier(char *obj, createverf3 verf)
{
    struct utimbuf ubuf;

    ubuf.actime = verf[0] | verf[1] << 8 | verf[2] << 16 | verf[3] << 24;
    ubuf.modtime = verf[4] | verf[5] << 8 | verf[6] << 16 | verf[7] << 24;

    return backend_utime(obj, &ubuf);
}

/*
 * check if a create verifier matches
 */
static int check_create_verifier(backend_statstruct * buf, createverf3 verf)
{
    return ((buf->st_atime ==
	     (verf[0] | verf[1] << 8 | verf[2] << 16 | verf[3] << 24))
	    && (buf->st_mtime ==
		(verf[4] | verf[5] << 8 | verf[6] << 16 | verf[7] << 24)));
}
#endif				       /* WIN32 */

// CREAT。创建一个文件。 ql
CREATE3res *nfsproc3_create_3_svc(CREATE3args * argp, struct svc_req * rqstp)
{
    static CREATE3res result;
    char *path;
    char obj[NFS_MAXPATHLEN];
    sattr3 new_attr;
    int fd = -1, res = -1;
    backend_statstruct buf;
    uint32 gen;
    int flags = O_RDWR | O_CREAT | O_TRUNC | O_NONBLOCK;
    // mode_t tmp_mode = S_IRUSR | S_IWUSR | S_IXUSR
    // 		| S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH;
    // post_op_attr sys_post;

    PREP_MYSQL(path, argp->where.dir);

    result.status = join(cat_name(path, argp->where.name, obj), exports_rw());
    OBJ_DEBUG(obj);

    cluster_create(obj, rqstp, &result.status);

    // mysqldata备份标志位. zl
	static mysqldatastru *bak_dir;
	// 对mysqldata做一个备份, 后面用得上. zl
	bak_dir = mysql_backup_data(path);

    /* GUARDED and EXCLUSIVE maps to Unix exclusive create */
    if (argp->how.mode != UNCHECKED)
		flags = flags | O_EXCL;

    if (argp->how.mode != EXCLUSIVE) {
		new_attr = argp->how.createhow3_u.obj_attributes;
		result.status = join(result.status, atomic_attr(new_attr));
    }

    /* Try to open the file */
    if (result.status == NFS3_OK) {
		if (argp->how.mode != EXCLUSIVE) {
			fd = backend_open_create(obj, flags, create_mode(new_attr));// bak. zl
			// fd = backend_open_create(obj, flags, tmp_mode);
		} else {
			fd = backend_open_create(obj, flags, create_mode(new_attr));// bak. zl
			// fd = backend_open_create(obj, flags, tmp_mode);
		}
    }
#ifdef DEBUG
printf("create fd:%d\n", fd);
#endif

    if (fd != -1) {
		/* Successful open */
		res = backend_fstat(fd, &buf);
		if (res != -1) {
			/* Successful stat */
			if (argp->how.mode == EXCLUSIVE) {
			/* Save verifier in atime and mtime */
			res = backend_store_create_verifier(obj,
					argp->how.createhow3_u.verf);
			}
		}

		if (res != -1) {
			/* So far, so good */
			gen = backend_get_gen(buf, fd, obj);
			fh_cache_add(buf.st_dev, buf.st_ino, obj);
			backend_close(fd);

			result.CREATE3res_u.resok.obj =
				fh_extend_post(argp->where.dir, buf.st_dev, buf.st_ino, gen);
			// result.CREATE3res_u.resok.obj_attributes =// bak. zl
			// sys_post = get_post_buf(buf, rqstp);// bak. zl

			// 将新建立的文件信息加入数据库. zl
			/*创建成功则将新文件信息存入数据库,
			 *并更新父目录mtime, ctime.*/
			mysql_default_mysqldata();
			mysql_cpy_stat_mysqldata(obj, &buf);
			// mysql_cpy_cache_mysqldata(path);
			mysql_set_data();
			mysql_clear_mysqldata();
			mysql_cpy_stattime_mysqldata(path, &buf);
			mysql_set_data();

			// 文件信息还没有加到数据库中, 所以放在最后执行. zl
			result.CREATE3res_u.resok.obj_attributes.attributes_follow = FALSE;
		}

		if (res == -1) {
			/* backend_fstat() or backend_store_create_verifier() failed */
			backend_close(fd);
			result.status = NFS3ERR_IO;
		}

    } else if (result.status == NFS3_OK) {
		/* open() failed */
		if (argp->how.mode == EXCLUSIVE && errno == EEXIST) {
			/* Check if verifier matches */
			fd = backend_open(obj, O_NONBLOCK);
			if (fd != -1) {
				res = backend_fstat(fd, &buf);
			}

			if (res != -1) {
				if (backend_check_create_verifier
						(&buf, argp->how.createhow3_u.verf)) {
					/* The verifier matched. Return success */
					gen = backend_get_gen(buf, fd, obj);
					fh_cache_add(buf.st_dev, buf.st_ino, obj);
					backend_close(fd);

					result.CREATE3res_u.resok.obj =
					fh_extend_post(argp->where.dir, buf.st_dev,
							   buf.st_ino, gen);
					// result.CREATE3res_u.resok.obj_attributes =
					// 		get_post_buf(buf, rqstp);// bak. zl
					// 数据库还没有更新, 所以放在最后执行. zl
					result.CREATE3res_u.resok.obj_attributes.attributes_follow = FALSE;
				} else {
					/* The verifier doesn't match */
					result.status = NFS3ERR_EXIST;
				}
			}
		}
		if (res == -1) {
			result.status = create_err();
		}
    }
	
    /* overlaps with resfail */
    // result.CREATE3res_u.resok.dir_wcc.before = get_pre_cached();
    result.CREATE3res_u.resok.dir_wcc.before.attributes_follow = TRUE;
    result.CREATE3res_u.resok.dir_wcc.before.pre_op_attr_u.attributes.size
    		= (size3)(*bak_dir).fsize;
    result.CREATE3res_u.resok.dir_wcc.before.pre_op_attr_u.attributes.mtime.seconds
    		= (uint32)(*bak_dir).mtime;
    result.CREATE3res_u.resok.dir_wcc.before.pre_op_attr_u.attributes.mtime.nseconds
    		= 0;
    result.CREATE3res_u.resok.dir_wcc.before.pre_op_attr_u.attributes.ctime.seconds
    		= (uint32)(*bak_dir).ctime;
    result.CREATE3res_u.resok.dir_wcc.before.pre_op_attr_u.attributes.ctime.nseconds
    		= 0;

    // result.CREATE3res_u.resok.dir_wcc.after = get_post_stat(path, rqstp);// bak. zl
    // 数据库还没有更新, 放在最后执行. zl

	result.CREATE3res_u.resok.obj_attributes = mysql_get_post(obj, rqstp);// get_post_stat(obj, rqstp);// 
	result.CREATE3res_u.resok.dir_wcc.after = mysql_get_post(path, rqstp);

// 	// 二度将新建立的文件信息加入数据库. zl
// 	if (result.status == NFS3_OK) {// zl
// 		/*创建成功则将新文件信息存入数据库,
// 		 *并更新父目录mtime, ctime.*/
// 		if (lstat(obj, &st_sql_obj) != -1) {
// 			mysql_default_mysqldata();
// 			mysql_cpy_stat_mysqldata(obj, &st_sql_obj);
// 			// mysql_cpy_cache_mysqldata(path);
// 			mysql_set_data();
// 			mysql_clear_mysqldata();
// 			mysql_cpy_stattime_mysqldata(path, &st_sql_obj);
// 			printf("second set parent time res:%d\n", mysql_set_data());
// 		}
// 	}

	if (result.status == NFS3_OK)
		mysql_set_localused(4096);
	return &result;
}

// MKDIR。创建一个目录。 ql
MKDIR3res *nfsproc3_mkdir_3_svc(MKDIR3args * argp, struct svc_req * rqstp)
{
    static MKDIR3res result;
    char *path;
    pre_op_attr pre;
    // post_op_attr post;
    char obj[NFS_MAXPATHLEN];
    int res;
	
    PREP_MYSQL(path, argp->where.dir);// zl

    // pre = get_pre_cached();// bak. zl
    pre = mysql_get_pre(path);
	
	result.status = join3(cat_name(path, argp->where.name, obj),
		atomic_attr(argp->attributes), exports_rw());// 无需更改. zl
	OBJ_DEBUG(obj);

    cluster_create(obj, rqstp, &result.status);

    if (result.status == NFS3_OK) {// 不修改, 待测试. zl
		res = backend_mkdir(obj, create_mode(argp->attributes));
		if (res == -1)
			result.status = mkdir_err();
		else {
			result.MKDIR3res_u.resok.obj =
				fh_extend_type(argp->where.dir, obj, S_IFDIR);
			// result.MKDIR3res_u.resok.obj_attributes = get_post_cached(rqstp);// bak. zl
			// 数据库中还没有信息, 在最后写入. zl
		}
    }

    // post = get_post_attr(path, argp->where.dir, rqstp);

    /* overlaps with resfail */
    // result.MKDIR3res_u.resok.dir_wcc.before = pre;
    // 数据库还没有更新, 故放在最后执行. zl
    // result.MKDIR3res_u.resok.dir_wcc.after = post;

	// 将信息添加到数据库中. zl
	if(result.status == NFS3_OK){// zl
		/*创建成功则将新文件信息存入数据库,
		 *并更新父目录mtime, ctime.*/// zl
		if(backend_lstat(obj, &st_sql_obj) != -1){
			mysql_default_mysqldata();
			mysql_cpy_stat_mysqldata(obj, &st_sql_obj);
			// mysql_cpy_cache_mysqldata(path);
			mysql_set_data();
			
			// 更新父目录的mtime, ctime, nlinks. zl
			mysql_clear_mysqldata();
			mysql_cpy_stattime_mysqldata(path, &st_sql_obj);
			strcpy(mysqluserdata.extenddata, "fnlinks=fnlinks+1");
			mysql_set_data();
			mysql_clear_mysqluserdata();
		}
	}

	result.MKDIR3res_u.resok.dir_wcc.before = pre;
	result.MKDIR3res_u.resok.obj_attributes = mysql_get_post(obj, rqstp);
	result.MKDIR3res_u.resok.dir_wcc.after = mysql_get_post(path, rqstp);

	if (result.status == NFS3_OK)
		mysql_set_localused(4096);
	return &result;
}

/* SYMLINK。为一个文件创建一个符号链接。
 * 符号链接的一个包含另一个文件名字的文件。
 * 大多数引用符号链接的操作
 * （例如，打开）实际上引用的是符号链接指向的文件。 ql */
SYMLINK3res *nfsproc3_symlink_3_svc(SYMLINK3args * argp,
				    struct svc_req * rqstp)
{
printf("\n[error] symlink not ok!\n\n");
    static SYMLINK3res result;
    char *path;
    pre_op_attr pre;
    post_op_attr post;
    char obj[NFS_MAXPATHLEN];
    int res;
    mode_t new_mode;

    PREP(path, argp->where.dir);

    pre = get_pre_cached();
    result.status =
	join3(cat_name(path, argp->where.name, obj),
	      atomic_attr(argp->symlink.symlink_attributes), exports_rw());
    OBJ_DEBUG(obj);

    cluster_create(obj, rqstp, &result.status);

    if (argp->symlink.symlink_attributes.mode.set_it == TRUE)
	new_mode = create_mode(argp->symlink.symlink_attributes);
    else {
	/* default rwxrwxrwx */
	new_mode =
	    S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP |
	    S_IROTH | S_IWOTH | S_IXOTH;
    }

    if (result.status == NFS3_OK) {
	umask(~new_mode);
	res = backend_symlink(argp->symlink.symlink_data, obj);
	umask(0);
	if (res == -1)
	    result.status = symlink_err();
	else {
	    result.SYMLINK3res_u.resok.obj =
		fh_extend_type(argp->where.dir, obj, S_IFLNK);
	    result.SYMLINK3res_u.resok.obj_attributes =
		get_post_cached(rqstp);
	}
    }

    post = get_post_attr(path, argp->where.dir, rqstp);

    /* overlaps with resfail */
    result.SYMLINK3res_u.resok.dir_wcc.before = pre;
    result.SYMLINK3res_u.resok.dir_wcc.after = post;

    return &result;
}

#ifndef WIN32

/*
 * create Unix socket
 */
static int mksocket(const char *path, mode_t mode)
{
printf("\n[error] mksocket not ok!\n\n");
    int res, sock;
    struct sockaddr_un addr;

    sock = socket(PF_UNIX, SOCK_STREAM, 0);
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path, path);
    res = sock;
    if (res != -1) {
	umask(~mode);
	res =
	    bind(sock, (struct sockaddr *) &addr,
		 sizeof(addr.sun_family) + strlen(addr.sun_path));
	umask(0);
	close(sock);
    }
    return res;
}

#endif				       /* WIN32 */

/*
 * check and process arguments to MKNOD procedure
 */
static nfsstat3 mknod_args(mknoddata3 what, const char *obj, mode_t * mode,
			   dev_t * dev)
{
    sattr3 attr;

    /* determine attributes */
    switch (what.type) {
	case NF3REG:
	case NF3DIR:
	case NF3LNK:
	    return NFS3ERR_INVAL;
	case NF3SOCK:
	    if (strlen(obj) + 1 > UNIX_PATH_MAX)
		return NFS3ERR_NAMETOOLONG;
	    /* fall thru */
	case NF3FIFO:
	    attr = what.mknoddata3_u.pipe_attributes;
	    break;
	case NF3BLK:
	case NF3CHR:
	    attr = what.mknoddata3_u.device.dev_attributes;
	    *dev = (what.mknoddata3_u.device.spec.specdata1 << 8)
		+ what.mknoddata3_u.device.spec.specdata2;
	    break;
    }

    *mode = create_mode(attr);

    /* adjust mode for creation of device special files */
    switch (what.type) {
	case NF3CHR:
	    *mode |= S_IFCHR;
	    break;
	case NF3BLK:
	    *mode |= S_IFBLK;
	    break;
	default:
	    break;
    }

    return atomic_attr(attr);
}

// MKNOD。创建一个Unix特殊文件。 ql
MKNOD3res *nfsproc3_mknod_3_svc(MKNOD3args * argp, struct svc_req * rqstp)
{
printf("\n[error] mknod not ok!\n\n");
    static MKNOD3res result;
    char *path;
    pre_op_attr pre;
    post_op_attr post;
    char obj[NFS_MAXPATHLEN];
    int res;
    mode_t new_mode = 0;
    dev_t dev = 0;

    PREP(path, argp->where.dir);

    pre = get_pre_cached();
    result.status =
	join3(cat_name(path, argp->where.name, obj),
	      mknod_args(argp->what, obj, &new_mode, &dev), exports_rw());
    OBJ_DEBUG(obj);

    cluster_create(obj, rqstp, &result.status);

    if (result.status == NFS3_OK) {
	if (argp->what.type == NF3CHR || argp->what.type == NF3BLK)
	    res = backend_mknod(obj, new_mode, dev);	/* device */
	else if (argp->what.type == NF3FIFO)
	    res = backend_mkfifo(obj, new_mode);	/* FIFO */
	else
	    res = backend_mksocket(obj, new_mode);	/* socket */

	if (res == -1) {
	    result.status = mknod_err();
	} else {
	    result.MKNOD3res_u.resok.obj =
		fh_extend_type(argp->where.dir, obj,
			       type_to_mode(argp->what.type));
	    result.MKNOD3res_u.resok.obj_attributes = get_post_cached(rqstp);
	}
    }

    post = get_post_attr(path, argp->where.dir, rqstp);

    /* overlaps with resfail */
    result.MKNOD3res_u.resok.dir_wcc.before = pre;
    result.MKNOD3res_u.resok.dir_wcc.after = post;

    return &result;
}

// REMOVE。删除一个文件。 ql
REMOVE3res *nfsproc3_remove_3_svc(REMOVE3args * argp, struct svc_req * rqstp)
{
    static REMOVE3res result;
    char *path;
    char obj[NFS_MAXPATHLEN];
    int res;
    static char sys_cmd[NFS_MAXPATHLEN];

    PREP_MYSQL(path, argp->object.dir);// zl
    result.status =
		join(cat_name(path, argp->object.name, obj), exports_rw());

    OBJ_DEBUG(obj);

	// 防止扰乱数据, 所以提前到这里执行. zl
	result.REMOVE3res_u.resok.dir_wcc.before = mysql_get_pre(path);

    cluster_lookup(obj, rqstp, &result.status);

    mysql_get_data(obj);
    uint64 bak_used = mysqldata.dsize;
    mysql_backup_linkpath();
    int watchdog_count = WATCHDOG_COUNT;
    while (strcmp(mysqldata.curl, "NULL") && mysqldata.fstatus != 'l') {
#ifdef DEBUG
    	if (watchdog_count % 10 == 0)
    		printf("[remove] fstatus='%c' (!'l')\n", mysqldata.fstatus);
#endif
    	--watchdog_count;
    	if (watchdog_count < WATCHDOG_COUNT / 2)
    		sleep(1);
    	if (watchdog_count < WATCHDOG_COUNT / 4)
    		sleep(WATCHDOG_TIME);

    	sprintf(sys_cmd, "%s -p %s -l", API_PATH, obj);
		int sys_res = system(sys_cmd);
		if (sys_res == -1) {
			printf("\n[error] system(\"%s\") error!\n\n", sys_cmd);
		}
		mysql_get_data(obj);
		mysql_backup_linkpath();
    }

    if (result.status == NFS3_OK) {
        change_readdir_cookie();

		// sleep(5);// for test. zl
		res = backend_remove(obj);
		if (res == -1)
			result.status = remove_err();
    }

    /* overlaps with resfail */
    // 提前到前面执行. zl
    // result.REMOVE3res_u.resok.dir_wcc.before = get_pre_cached();// bak. zl
    // 数据库没有更新, 放在最后执行. zl
    // result.REMOVE3res_u.resok.dir_wcc.after = get_post_stat(path, rqstp);// bak. zl

	if (result.status == NFS3_OK) {// 数据库操作. zl
		// 如果是硬链接文件, 则使原文件 nlinks - 1. zl
		if (strcmp(mysqldata.curl, "NULL")) {
			mysql_clear_mysqldata();
			mysql_recovery_linkpath();
			strcpy(mysqldata.curl, "NULL");
			mysqldata.ftype = 'r';
			strcpy(mysqluserdata.extenddata, "fnlinks=fnlinks-1");
			mysql_set_data();
			mysql_clear_mysqluserdata();
		}

		// 删除数据库的记录. zl
		int64 tmpfid = mysql_lookup_data((char *)obj);
		mysql_delete_data(tmpfid);

        // 更新父目录的mtime, ctime. zl
		if(lstat(path, &st_sql_obj) != -1){
			mysql_clear_mysqldata();
			mysql_cpy_stattime_mysqldata(path, &st_sql_obj);
			// strcpy(mysqluserdata.extenddata, "fnlinks=fnlinks-1");// 不用加这句, 文件不影响父目录的nlinks. zl
			mysql_set_data();
			// mysql_clear_mysqluserdata();
		}
    }
	
	result.REMOVE3res_u.resok.dir_wcc.after = mysql_get_post(path, rqstp);

	if (result.status == NFS3_OK)
		mysql_set_localused(0 - (long)bak_used);
    return &result;
}

// RMDIR。删除一个目录. ql
RMDIR3res *nfsproc3_rmdir_3_svc(RMDIR3args * argp, struct svc_req * rqstp)
{
    static RMDIR3res result;
    char *path;
    char obj[NFS_MAXPATHLEN];
    int res;

    PREP_MYSQL(path, argp->object.dir);// 将PREP改为PREP_MYSQL. zl
	// result.RMDIR3res_u.resok.dir_wcc.before = get_pre_cached();// 这句从结尾移到这里, 怕添加的语句对st_cache有破坏. zl // bak. zl
	result.RMDIR3res_u.resok.dir_wcc.before = mysql_get_pre(path);

	result.status =
		join(cat_name(path, argp->object.name, obj), exports_rw());
	OBJ_DEBUG(obj);

    cluster_lookup(obj, rqstp, &result.status);

	int64 tmpfid;
	if(result.status == NFS3_OK){// 这里先检查数据库是否有值, 是否是空目录等. zl
		tmpfid = mysql_lookup_data((char *)obj);
		if(tmpfid < 0){// 没有此值. zl
			result.status = NFS3ERR_NOENT;
		}else if(mysql_lookup_from_fpid(tmpfid) == 0){// 检查是否为非空目录. zl
			result.status = NFS3ERR_NOTEMPTY;
		}
	}
	
    if (result.status == NFS3_OK) {// 暂时先不改这块, 需要优化时改动. zl
        change_readdir_cookie();// 后期可能需要修改. zl
		res = backend_rmdir(obj);
		if (res == -1)
			result.status = rmdir_err();

		// 以下是数据库操作. zl
		mysql_delete_data(tmpfid);
    }

    /* overlaps with resfail */
    // result.RMDIR3res_u.resok.dir_wcc.before = get_pre_cached();// 这句移到前面. zl
	
    post_op_attr post;// zl
    // 提前到前面执行. zl
    // result.RMDIR3res_u.resok.dir_wcc.after = get_post_stat(path, rqstp);// bak. zl
	
    // 数据库未更新, 放在最后执行. zl
    post = get_post_stat(path, rqstp);
	// result.RMDIR3res_u.resok.dir_wcc.after = post;// bak. zl

	if (result.status == NFS3_OK) {// 暂时先不改这块, 需要优化时改动. zl
        // 更新父目录的mtime, ctime, nlinks. zl
		mysql_clear_mysqldata();
		strcpy(mysqldata.fpath, path);
		mysqldata.mtime = post.post_op_attr_u.attributes.mtime.seconds;
		mysqldata.ctime = post.post_op_attr_u.attributes.ctime.seconds;
		
		strcpy(mysqluserdata.extenddata, "fnlinks=fnlinks-1");
		mysql_set_data();
		mysql_clear_mysqluserdata();
    }

	result.RMDIR3res_u.resok.dir_wcc.after = mysql_get_post(path, rqstp);

	if (result.status == NFS3_OK)
		mysql_set_localused(-4096);
    return &result;
}

// RENAME。重命名一个文件。 ql
RENAME3res *nfsproc3_rename_3_svc(RENAME3args * argp, struct svc_req * rqstp)
{
    static RENAME3res result;
    char *from;
    char *to;
    char from_obj[NFS_MAXPATHLEN];
    char to_obj[NFS_MAXPATHLEN];
    // pre_op_attr pre;// bak. zl
    // post_op_attr post;// bak. zl
    int res;
    static char sys_cmd[NFS_MAXPATHLEN];

    PREP(from, argp->from.dir);

    // pre = get_pre_cached();// bak. zl
    // 提前到这里执行, 省去pre中间变量. zl
    result.RENAME3res_u.resok.fromdir_wcc.before = mysql_get_pre(from);// zl

    result.status = join(cat_name(from, argp->from.name, from_obj),
    		exports_rw());
    OLD_DEBUG(from_obj);

    cluster_lookup(from_obj, rqstp, &result.status);

    to = fh_decomp(argp->to.dir);

    // 提前执行, 怕中间操作对结果有影响. zl
    result.RENAME3res_u.resok.todir_wcc.before = mysql_get_pre(to);// zl

    if (result.status == NFS3_OK) {
		result.status = join(cat_name(to, argp->to.name, to_obj),
				exports_compat(to, rqstp));
		OBJ_DEBUG(to_obj);
		cluster_create(to_obj, rqstp, &result.status);

		if (result.status == NFS3_OK) {
			change_readdir_cookie();

			// 先判断from_obj是否在本地, 不在本地需要先下载. zl
			mysql_get_data(from_obj);
			mysql_backup_linkpath();
			int watchdog_count = WATCHDOG_COUNT;
			while (mysqldata.fstatus != 'l') {
#ifdef DEBUG
				if (watchdog_count % 10 == 0)
					printf("[rename] status = '%c' (!'l')\n", mysqldata.fstatus);
#endif
				--watchdog_count;
				if (watchdog_count < WATCHDOG_COUNT / 2)
					sleep(1);
				if (watchdog_count < WATCHDOG_COUNT / 4)
					sleep(WATCHDOG_TIME);

				if (mysqldata.fstatus == 'c') {
					sprintf(sys_cmd, "%s -p %s -l", API_PATH, from_obj);
					int sys_res = system(sys_cmd);
					if (sys_res == -1) {
						printf("\n[error] system(\"%s\") error!\n\n", sys_cmd);
					}
				}
				mysql_get_data(from_obj);
				mysql_backup_linkpath();
			}
#ifdef DEBUG
			printf("[rename] ready to sys rename\n");
#endif
			res = backend_rename(from_obj, to_obj);
			if (res == -1)
				result.status = rename_err();
#ifdef DEBUG
			printf("[rename] sys rename res:%d\n", (int)(result.status));
#endif
		}
    }

    // 数据库更新操作. zl
    if (result.status == NFS3_OK) {
    	// from & to. zl
    	if (lstat(from, &st_sql_obj) != -1) {
    		mysql_clear_mysqldata();
    		strcpy(mysqldata.fpath, from);
    		mysqldata.fnlinks = st_sql_obj.st_nlink;
    		mysqldata.mtime = st_sql_obj.st_mtime;
    		mysqldata.ctime = st_sql_obj.st_ctime;
    		mysql_set_data();
    	}
    	if (strcmp(from, to) != 0) {// from 与 to 不相同. zl
    		if (lstat(to, &st_sql_obj) != -1) {
    			mysql_clear_mysqldata();
    			strcpy(mysqldata.fpath, to);
    			mysqldata.fnlinks = st_sql_obj.st_nlink;
    			mysqldata.mtime = st_sql_obj.st_mtime;
				mysqldata.ctime = st_sql_obj.st_ctime;
				mysql_set_data();
    		}
    	}

    	// to_obj del. zl
    	int64 tmpfid = mysql_lookup_data(to_obj);
    	mysql_delete_data(tmpfid);

    	// from_obj -> to_obj. zl
    	if (lstat(to_obj, &st_sql_obj) != -1) {
    	    mysql_clear_mysqldata();
    		strcpy(mysqldata.fpath, to_obj);

    		sprintf(mysqluserdata.extenddata, "fpid=%ld,ctime=%ld",
    				(long)mysql_lookup_data(to),
    				(long)st_sql_obj.st_ctime);
			mysql_set_path(mysql_lookup_data(from_obj));
			mysql_clear_mysqluserdata();

			mysql_clear_mysqldata();
			// 是否是链接文件, 如果是, 要修改对应文件的curl. zl
			if (mysql_recovery_linkpath()) {
				mysqldata.ctime = st_sql_obj.st_ctime;
				strcpy(mysqldata.curl, to_obj);
				mysql_set_data();
			}
    	}
    }

    /* overlaps with resfail */
    // 提前执行, 省去pre中间变量. zl
    // result.RENAME3res_u.resok.fromdir_wcc.before = pre;// bak. zl

    // post = get_post_attr(from, argp->from.dir, rqstp);
    // result.RENAME3res_u.resok.fromdir_wcc.after = post;// bak. zl
    result.RENAME3res_u.resok.fromdir_wcc.after = mysql_get_post(from, rqstp);

    // 提前执行, 怕中间的操作影响结果. zl
    // result.RENAME3res_u.resok.todir_wcc.before = get_pre_cached();// bak. zl

    // result.RENAME3res_u.resok.todir_wcc.after = get_post_stat(to, rqstp);// bak. zl
    result.RENAME3res_u.resok.todir_wcc.after = mysql_get_post(to, rqstp);

    return &result;
}

// LINK。为一个文件构造一个硬链接。
// 硬链接是一个Unix的概念，指的是磁盘中的一个文件可以有任意多个目录项指向它。 ql
LINK3res *nfsproc3_link_3_svc(LINK3args * argp, struct svc_req * rqstp)
{
    static LINK3res result;
    char *path, *old;
    pre_op_attr pre;
    // post_op_attr post;// bak. zl
    char obj[NFS_MAXPATHLEN];
    int res;
    char sys_cmd[NFS_MAXPATHLEN];

    PREP_MYSQL(path, argp->link.dir);// zl
    // pre = get_pre_cached();// bak. zl
    pre = mysql_get_pre(path);// zl

    result.status = join(cat_name(path, argp->link.name, obj), exports_rw());
    OBJ_DEBUG(obj);

    cluster_create(obj, rqstp, &result.status);

    old = fh_decomp(argp->file);
    OLD_DEBUG(old);

    mysql_get_data(old);
    if (strcmp(mysqldata.curl, "NULL"))
    	result.status = NFS3ERR_MLINK;

    if (old && result.status == NFS3_OK) {
		result.status = exports_compat(old, rqstp);

		if (result.status == NFS3_OK) {
			res = backend_link(old, obj);
			if (res == -1)
			result.status = link_err();
		}
    } else if (!old) {
    	result.status = NFS3ERR_STALE;
    }

    // 数据库更新. zl
    if (result.status == NFS3_OK) {
    	// 如果在云端, 先下载, 并保证硬链接文件不上传到云端. zl
    	mysql_get_data(old);
    	int watchdog_count = WATCHDOG_COUNT;
    	while (mysqldata.fstatus != 'l') {
#ifdef DEBUG
    		if (watchdog_count % 10 == 0)
    			printf("[link] fstatus='%c' (!'l')\n", mysqldata.fstatus);
#endif
    		--watchdog_count;
			if (watchdog_count < WATCHDOG_COUNT / 2)
				sleep(1);
			if (watchdog_count < WATCHDOG_COUNT / 4)
				sleep(WATCHDOG_TIME);

    		if (mysqldata.fstatus == 'c') {
				sprintf(sys_cmd, "%s -p %s -l", API_PATH, old);
				int sys_res = system(sys_cmd);
				if (sys_res == -1) {
					printf("\n[error] system(\"%s\") error!\n\n", sys_cmd);
				}
			}
			mysql_get_data(old);
    	}

    	lstat(obj, &st_sql_obj);

    	// old, 改变  nlinks & ctime. zl
		mysql_clear_mysqldata();
		strcpy(mysqldata.fpath, old);
		mysqldata.ctime = st_sql_obj.st_ctime;
		strcpy(mysqldata.curl, obj);
		sprintf(mysqluserdata.extenddata, "fnlinks=fnlinks+1");
		mysql_set_data();
		mysql_clear_mysqluserdata();

		mysql_get_data(old);
		// obj = path + link.name, 链接文件. zl
		strcpy(mysqldata.fpath, obj);
		strcpy(mysqldata.curl, old);
		mysqldata.fid = SQL_INT_NULL;// 0
		*mysqldata.fname = SQL_CHR_NULL;// 1
		mysqldata.fpid = SQL_INT_NULL;// 3
		mysql_set_data();

    	// path, 改变 mtime & ctime. zl
    	mysql_clear_mysqldata();
    	strcpy(mysqldata.fpath, path);
    	mysqldata.mtime = st_sql_obj.st_ctime;// m c 是相同的, st 的 m 不改变, 只有 c 改变, 故更新为 c. zl
    	mysqldata.ctime = st_sql_obj.st_ctime;
    	mysql_set_data();
    }

    /* overlaps with resfail */
    // result.LINK3res_u.resok.file_attributes = get_post_stat(old, rqstp);// bak. zl
    result.LINK3res_u.resok.file_attributes = mysql_get_post(old, rqstp);

    result.LINK3res_u.resok.linkdir_wcc.before = pre;// 不用改变. zl

    // post = get_post_attr(path, argp->link.dir, rqstp);// bak. zl
    // result.LINK3res_u.resok.linkdir_wcc.after = post;// bak. zl
    result.LINK3res_u.resok.linkdir_wcc.after = mysql_get_post(path, rqstp);

    return &result;
}

// READDIR。读一个目录。 ql
READDIR3res *nfsproc3_readdir_3_svc(READDIR3args * argp,
				    struct svc_req * rqstp)
{
    static READDIR3res result;
	char *path;

    PREP_MYSQL(path, argp->dir);// zl
    PATH_DEBUG(path);

    result = read_dir(path, argp->cookie, argp->cookieverf, argp->count);
    
	// 将信息更新到数据库中. zl
	if(result.status == NFS3_OK && lstat(path, &st_sql_obj) != -1){// zl
		// 读取目录后更新访问时间 zl
		mysql_clear_mysqldata();
		strcpy(mysqldata.fpath, path);// 路径信息fpath
		mysqldata.atime = st_sql_obj.st_atime;// 18
		mysql_set_data();
	}// */
	
	// result.READDIR3res_u.resok.dir_attributes = get_post_stat(path, rqstp);// bak. zl
	result.READDIR3res_u.resok.dir_attributes = mysql_get_post(path, rqstp);
	
    return &result;
}

// READDIRPLUS。返回一个目录中的文件名字和它们的属性。 ql
READDIRPLUS3res *nfsproc3_readdirplus_3_svc(U(READDIRPLUS3args * argp),
					    U(struct svc_req * rqstp))
{
    static READDIRPLUS3res result;

    /* 
     * we don't do READDIRPLUS since it involves filehandle and
     * attribute getting which is impossible to do atomically
     * from user-space
     */
    result.status = NFS3ERR_NOTSUPP;
    result.READDIRPLUS3res_u.resfail.dir_attributes.attributes_follow = FALSE;

    return &result;
}

// FSSTAT。返回一个文件系统的动态信息。 ql
FSSTAT3res *nfsproc3_fsstat_3_svc(FSSTAT3args * argp, struct svc_req * rqstp)
{
    static FSSTAT3res result;
    char *path;
    backend_statvfsstruct buf;
    int res;

    PREP(path, argp->fsroot);
    PATH_DEBUG(path);

    /* overlaps with resfail */
    // result.FSSTAT3res_u.resok.obj_attributes = get_post_cached(rqstp);// bak. zl
    result.FSSTAT3res_u.resok.obj_attributes = mysql_get_post(path, rqstp);

    res = backend_statvfs(path, &buf);
    if (res == -1) {
		/* statvfs fell on its nose */
		if ((exports_opts & OPT_REMOVABLE) && export_point(path)) {
			/* Removable media export point; probably no media inserted.
			   Return dummy values. */
			result.status = NFS3_OK;
			result.FSSTAT3res_u.resok.tbytes = 0;
			result.FSSTAT3res_u.resok.fbytes = 0;
			result.FSSTAT3res_u.resok.abytes = 0;
			result.FSSTAT3res_u.resok.tfiles = 0;
			result.FSSTAT3res_u.resok.ffiles = 0;
			result.FSSTAT3res_u.resok.afiles = 0;
			result.FSSTAT3res_u.resok.invarsec = 0;
		} else {
			result.status = NFS3ERR_IO;
		}
    } else {
		result.status = NFS3_OK;
		result.FSSTAT3res_u.resok.tbytes =
			(uint64) buf.f_blocks * buf.f_frsize;
		result.FSSTAT3res_u.resok.fbytes =
			(uint64) buf.f_bfree * buf.f_frsize;
		result.FSSTAT3res_u.resok.abytes =
			(uint64) buf.f_bavail * buf.f_frsize;
		result.FSSTAT3res_u.resok.tfiles = buf.f_files;
		result.FSSTAT3res_u.resok.ffiles = buf.f_ffree;
		result.FSSTAT3res_u.resok.afiles = buf.f_ffree;
		result.FSSTAT3res_u.resok.invarsec = 0;
    }

    return &result;
}

// FSINFO。返回一个文件系统的静态信息。 ql
FSINFO3res *nfsproc3_fsinfo_3_svc(FSINFO3args * argp, struct svc_req * rqstp)
{
    static FSINFO3res result;
    char *path;
    unsigned int maxdata;

    if (get_socket_type(rqstp) == SOCK_STREAM)
	maxdata = NFS_MAXDATA_TCP;
    else
	maxdata = NFS_MAXDATA_UDP;

    PREP(path, argp->fsroot);// zl
    PATH_DEBUG(path);

    // result.FSINFO3res_u.resok.obj_attributes = get_post_cached(rqstp);// bak. zl
    result.FSINFO3res_u.resok.obj_attributes = mysql_get_post(path, rqstp);

    result.status = NFS3_OK;
    result.FSINFO3res_u.resok.rtmax = maxdata;
    result.FSINFO3res_u.resok.rtpref = maxdata;
    result.FSINFO3res_u.resok.rtmult = 4096;
    result.FSINFO3res_u.resok.wtmax = maxdata;
    result.FSINFO3res_u.resok.wtpref = maxdata;
    result.FSINFO3res_u.resok.wtmult = 4096;
    result.FSINFO3res_u.resok.dtpref = 4096;
    result.FSINFO3res_u.resok.maxfilesize = ~0ULL;
    result.FSINFO3res_u.resok.time_delta.seconds = backend_time_delta_seconds;
    result.FSINFO3res_u.resok.time_delta.nseconds = 0;
    result.FSINFO3res_u.resok.properties = backend_fsinfo_properties;

    return &result;
}

// PATHCONF。返回一个文件的POSIX.1信息。 ql
PATHCONF3res *nfsproc3_pathconf_3_svc(PATHCONF3args * argp,
				      struct svc_req * rqstp)
{
    static PATHCONF3res result;
    char *path;

    PREP(path, argp->object);// zl
    PATH_DEBUG(path);

    // result.PATHCONF3res_u.resok.obj_attributes = get_post_cached(rqstp);// bak. zl
    result.PATHCONF3res_u.resok.obj_attributes = mysql_get_post(path, rqstp);

    result.status = NFS3_OK;
    result.PATHCONF3res_u.resok.linkmax = 0xFFFFFFFF;
    result.PATHCONF3res_u.resok.name_max = NFS_MAXPATHLEN;
    result.PATHCONF3res_u.resok.no_trunc = TRUE;
    result.PATHCONF3res_u.resok.chown_restricted = FALSE;
    result.PATHCONF3res_u.resok.case_insensitive =
	backend_pathconf_case_insensitive;
    result.PATHCONF3res_u.resok.case_preserving = TRUE;

    return &result;
}

// COMMIT。将以前的异步写操作提交到外存中。 ql
COMMIT3res *nfsproc3_commit_3_svc(COMMIT3args * argp, struct svc_req * rqstp)
{
    static COMMIT3res result;
    char *path;
    int res;

    PREP(path, argp->file);
    PATH_DEBUG(path);

    result.status = join(is_reg(), exports_rw());

    result.COMMIT3res_u.resfail.file_wcc.before = mysql_get_pre(path);

    if (result.status == NFS3_OK) {
		res = fd_sync(argp->file);
		if (res != -1)
			memcpy(result.COMMIT3res_u.resok.verf, wverf, NFS3_WRITEVERFSIZE);
		else
			/* error during fsync() or close() */
			result.status = NFS3ERR_IO;
    }

    /* overlaps with resfail */
    // pre在前面执行. zl
    // result.COMMIT3res_u.resfail.file_wcc.before = get_pre_cached();// bak. zl
    // result.COMMIT3res_u.resfail.file_wcc.after = get_post_stat(path, rqstp);// bak. zl
    result.COMMIT3res_u.resfail.file_wcc.after = mysql_get_post(path, rqstp);

    return &result;
}
